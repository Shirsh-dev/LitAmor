
import { Match, MatchStatus, HOURS_FOR_MATCH_EXPIRY, HOURS_FOR_VOICE_UNLOCK_AFTER_PIN, DAYS_FOR_PROFILE_UNLOCK, MAX_GAP_HOURS_FOR_CONTINUOUS_CHAT, COOLDOWN_HOURS } from "@/types/loneTown";

// ============================================
// MATCH LIFECYCLE MANAGEMENT
// ============================================

export function createNewMatch(userId1: string, userId2: string, compatibilityScore: number): Match {
  const now = new Date().toISOString();
  const expiresAt = new Date(Date.now() + HOURS_FOR_MATCH_EXPIRY * 60 * 60 * 1000).toISOString();

  return {
    id: generateMatchId(),
    users: [userId1, userId2],
    compatibilityScore,
    matchCreatedAt: now,
    matchExpiresAt: expiresAt,
    status: "active",
    messageCount: 0,
    conversationDays: 0,
    maxGapHours: MAX_GAP_HOURS_FOR_CONTINUOUS_CHAT,
    createdAt: now,
    updatedAt: now
  };
}

export function checkMatchExpiry(match: Match): { expired: boolean; shouldExpire: boolean } {
  const now = Date.now();
  const expiresAt = new Date(match.matchExpiresAt).getTime();
  
  if (match.status === "pinned") {
    return { expired: false, shouldExpire: false };
  }
  
  if (match.status === "active" && now > expiresAt) {
    return { expired: false, shouldExpire: true };
  }
  
  return { expired: match.status === "expired", shouldExpire: false };
}

export function pinMatch(match: Match, userId: string): Match {
  const now = new Date().toISOString();
  const voiceCallUnlocksAt = new Date(Date.now() + HOURS_FOR_VOICE_UNLOCK_AFTER_PIN * 60 * 60 * 1000).toISOString();

  return {
    ...match,
    status: "pinned",
    pinnedAt: now,
    pinnedBy: userId,
    voiceCallUnlockedAt: voiceCallUnlocksAt,
    updatedAt: now
  };
}

export function unpinMatch(match: Match, userId: string): Match {
  const now = new Date().toISOString();
  const cooldownEndsAt = new Date(Date.now() + COOLDOWN_HOURS * 60 * 60 * 1000).toISOString();

  return {
    ...match,
    status: "cooldown",
    unpinnedAt: now,
    unpinnedBy: userId,
    cooldownEndsAt,
    updatedAt: now
  };
}

export function unmatchUsers(match: Match, userId: string): Match {
  const now = new Date().toISOString();

  return {
    ...match,
    status: "unmatched",
    unmatchedAt: now,
    unmatchedBy: userId,
    updatedAt: now
  };
}

export function expireMatch(match: Match): Match {
  const now = new Date().toISOString();

  return {
    ...match,
    status: "expired",
    updatedAt: now
  };
}

// ============================================
// CONVERSATION TRACKING
// ============================================

export function recordMessage(match: Match): Match {
  const now = new Date().toISOString();
  
  return {
    ...match,
    lastMessageAt: now,
    messageCount: match.messageCount + 1,
    conversationStartedAt: match.conversationStartedAt || now,
    lastActivityTimestamp: now,
    firstMessageTimestamp: match.firstMessageTimestamp || now,
    updatedAt: now
  };
}

export function calculateContinuousDays(match: Match): number {
  if (!match.firstMessageTimestamp || !match.lastActivityTimestamp) {
    return 0;
  }

  const firstMessage = new Date(match.firstMessageTimestamp).getTime();
  const lastActivity = new Date(match.lastActivityTimestamp).getTime();
  const now = Date.now();

  const timeSinceLastActivity = (now - lastActivity) / (1000 * 60 * 60);
  
  if (timeSinceLastActivity > match.maxGapHours) {
    return 0;
  }

  const daysSinceStart = Math.floor((now - firstMessage) / (1000 * 60 * 60 * 24));
  
  return daysSinceStart;
}

export function checkProfileUnlock(match: Match): { unlocked: boolean; daysRemaining: number } {
  if (match.profileUnlockedAt) {
    return { unlocked: true, daysRemaining: 0 };
  }

  const continuousDays = calculateContinuousDays(match);
  
  if (continuousDays >= DAYS_FOR_PROFILE_UNLOCK) {
    return { unlocked: true, daysRemaining: 0 };
  }

  return {
    unlocked: false,
    daysRemaining: DAYS_FOR_PROFILE_UNLOCK - continuousDays
  };
}

export function unlockProfile(match: Match): Match {
  const now = new Date().toISOString();

  return {
    ...match,
    profileUnlockedAt: now,
    updatedAt: now
  };
}

export function checkVoiceCallUnlock(match: Match): boolean {
  if (!match.voiceCallUnlockedAt || match.status !== "pinned") {
    return false;
  }

  const now = Date.now();
  const unlockTime = new Date(match.voiceCallUnlockedAt).getTime();

  return now >= unlockTime;
}

// ============================================
// COOLDOWN MANAGEMENT
// ============================================

export function isInCooldown(cooldownEndsAt?: string): boolean {
  if (!cooldownEndsAt) return false;
  
  const now = Date.now();
  const endsAt = new Date(cooldownEndsAt).getTime();
  
  return now < endsAt;
}

export function getCooldownTimeRemaining(cooldownEndsAt?: string): number {
  if (!cooldownEndsAt) return 0;
  
  const now = Date.now();
  const endsAt = new Date(cooldownEndsAt).getTime();
  const remaining = endsAt - now;
  
  return Math.max(0, Math.ceil(remaining / (1000 * 60 * 60)));
}

// ============================================
// TIME FORMATTING UTILITIES
// ============================================

export function formatTimeRemaining(expiresAt: string): string {
  const now = Date.now();
  const expires = new Date(expiresAt).getTime();
  const remaining = expires - now;
  
  if (remaining <= 0) return "Expired";
  
  const hours = Math.floor(remaining / (1000 * 60 * 60));
  const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
  
  if (hours > 0) {
    return `${hours}h ${minutes}m remaining`;
  }
  
  return `${minutes}m remaining`;
}

export function formatRelativeTime(timestamp: string): string {
  const now = Date.now();
  const time = new Date(timestamp).getTime();
  const diff = now - time;
  
  const minutes = Math.floor(diff / (1000 * 60));
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  
  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (minutes > 0) return `${minutes}m ago`;
  return "Just now";
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function generateMatchId(): string {
  return `match_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export function getMatchStatus(match: Match): {
  status: MatchStatus;
  displayText: string;
  canChat: boolean;
  canPin: boolean;
  canUnpin: boolean;
  canUnmatch: boolean;
  voiceCallEnabled: boolean;
  profileUnlocked: boolean;
} {
  const profileUnlock = checkProfileUnlock(match);
  const voiceUnlock = checkVoiceCallUnlock(match);
  const expiry = checkMatchExpiry(match);

  let displayText = "";
  let canChat = false;
  let canPin = false;
  let canUnpin = false;
  let canUnmatch = true;

  switch (match.status) {
    case "active":
      displayText = `Active - ${formatTimeRemaining(match.matchExpiresAt)}`;
      canChat = true;
      canPin = true;
      break;
    case "pinned":
      displayText = "Pinned";
      canChat = true;
      canUnpin = true;
      break;
    case "expired":
      displayText = "Expired";
      break;
    case "cooldown":
      const hoursRemaining = getCooldownTimeRemaining(match.cooldownEndsAt);
      displayText = `Cooldown - ${hoursRemaining}h remaining`;
      break;
    case "unmatched":
      displayText = "Unmatched";
      canUnmatch = false;
      break;
  }

  return {
    status: match.status,
    displayText,
    canChat,
    canPin,
    canUnpin,
    canUnmatch,
    voiceCallEnabled: voiceUnlock,
    profileUnlocked: profileUnlock.unlocked
  };
}
