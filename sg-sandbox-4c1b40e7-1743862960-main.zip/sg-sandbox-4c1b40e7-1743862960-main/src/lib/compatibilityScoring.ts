
import { CompatibilityQuestionnaire, UserProfile, MatchCandidate } from "@/types/loneTown";

// ============================================
// COMPATIBILITY SCORING ALGORITHM (Phase 1: 50 points)
// ============================================

export function calculateCompatibilityScore(
  user1: CompatibilityQuestionnaire,
  user2: CompatibilityQuestionnaire
): number {
  let score = 0;

  // 1. Relationship Type Seeking - 10 points
  if (user1.relationshipTypeSeeking === user2.relationshipTypeSeeking) {
    score += 10;
  } else if (isRelationshipTypeCompatible(user1.relationshipTypeSeeking, user2.relationshipTypeSeeking)) {
    score += 7;
  }

  // 2. Smoking - 1 point
  if (user1.smoking === user2.smoking) {
    score += 1;
  } else if (isLifestyleCompatible(user1.smoking, user2.smoking)) {
    score += 0.5;
  }

  // 3. Drinking - 1 point
  if (user1.drinking === user2.drinking) {
    score += 1;
  } else if (isLifestyleCompatible(user1.drinking, user2.drinking)) {
    score += 0.5;
  }

  // 4. Religion & Ethnicity - 5 points
  const religionScore = calculateReligionScore(user1, user2);
  score += religionScore;

  // 5. First Language - 5 points
  if (user1.firstLanguage === user2.firstLanguage) {
    score += 5;
  } else if (areLanguagesCompatible(user1.firstLanguage, user2.firstLanguage)) {
    score += 3;
  }

  // 6. Diet - 2 points
  if (user1.diet === user2.diet) {
    score += 2;
  } else if (isDietCompatible(user1.diet, user2.diet)) {
    score += 1;
  }

  // 7. Profession - 5 points
  const professionScore = calculateProfessionScore(user1.profession, user2.profession);
  score += professionScore;

  // 8. Political Views - 3 points
  if (user1.politicalViews === user2.politicalViews) {
    score += 3;
  } else if (arePoliticalViewsCompatible(user1.politicalViews, user2.politicalViews)) {
    score += 1.5;
  }

  // 9. Priorities - 3 points
  const priorityScore = calculatePriorityScore(user1.priorities, user2.priorities);
  score += priorityScore;

  // 10. Sexual Attraction - 5 points
  if (areSexualOrientationsCompatible(user1.sexualAttraction, user2.sexualAttraction)) {
    score += 5;
  }

  // 11. Past Relationships - 3 points
  const relationshipHistoryScore = calculateRelationshipHistoryScore(
    user1.pastRelationships,
    user2.pastRelationships
  );
  score += relationshipHistoryScore;

  // 12. Personality Type - 2 points
  const personalityScore = calculatePersonalityScore(user1.personalityType, user2.personalityType);
  score += personalityScore;

  // 13. Love Language - 3 points
  if (user1.loveLanguage === user2.loveLanguage) {
    score += 3;
  } else if (areLoveLanguagesCompatible(user1.loveLanguage, user2.loveLanguage)) {
    score += 1.5;
  }

  // 14. Lifestyle - 2 points
  if (user1.lifestyle === user2.lifestyle) {
    score += 2;
  } else if (areLifestylesCompatible(user1.lifestyle, user2.lifestyle)) {
    score += 1;
  }

  return Math.min(50, Math.round(score * 10) / 10);
}

// Helper functions for compatibility logic

function isRelationshipTypeCompatible(type1: string, type2: string): boolean {
  const compatible = {
    "Long-term committed": ["Marriage-oriented", "Life partnership"],
    "Marriage-oriented": ["Long-term committed", "Life partnership"],
    "Open to possibilities": ["Taking it slow"],
    "Taking it slow": ["Open to possibilities"],
    "Life partnership": ["Long-term committed", "Marriage-oriented"]
  };
  return compatible[type1 as keyof typeof compatible]?.includes(type2) || false;
}

function isLifestyleCompatible(habit1: string, habit2: string): boolean {
  const compatible = {
    "Never": ["Socially", "Trying to quit"],
    "Socially": ["Never", "Occasionally"],
    "Occasionally": ["Socially", "Never"]
  };
  return compatible[habit1 as keyof typeof compatible]?.includes(habit2) || false;
}

function calculateReligionScore(user1: CompatibilityQuestionnaire, user2: CompatibilityQuestionnaire): number {
  if (user1.religion === user2.religion) {
    if (user1.ethnicity === user2.ethnicity) {
      return 5;
    }
    return 4;
  }
  
  const spirituallyCompatible = [
    "Spiritual but not religious",
    "Atheist/Agnostic"
  ];
  
  if (spirituallyCompatible.includes(user1.religion) && spirituallyCompatible.includes(user2.religion)) {
    return 3;
  }
  
  return 1;
}

function areLanguagesCompatible(lang1: string, lang2: string): boolean {
  const commonLanguages = ["English", "Hindi"];
  return commonLanguages.includes(lang1) && commonLanguages.includes(lang2);
}

function isDietCompatible(diet1: string, diet2: string): boolean {
  if (diet1 === "Flexible" || diet2 === "Flexible") return true;
  if (diet1 === "Vegan" && diet2 === "Vegetarian") return true;
  if (diet1 === "Vegetarian" && diet2 === "Vegan") return true;
  return false;
}

function calculateProfessionScore(prof1: string, prof2: string): number {
  const professionCategories: { [key: string]: string[] } = {
    "Tech": ["Software Engineer", "Developer", "IT", "Tech"],
    "Creative": ["Artist", "Designer", "Writer", "Content"],
    "Business": ["Entrepreneur", "Business", "Manager", "Consultant"],
    "Education": ["Teacher", "Professor", "Educator"],
    "Healthcare": ["Doctor", "Nurse", "Healthcare"]
  };

  for (const category in professionCategories) {
    const keywords = professionCategories[category];
    const prof1Match = keywords.some(keyword => prof1.toLowerCase().includes(keyword.toLowerCase()));
    const prof2Match = keywords.some(keyword => prof2.toLowerCase().includes(keyword.toLowerCase()));
    
    if (prof1Match && prof2Match) {
      return 5;
    }
  }
  
  return 2;
}

function arePoliticalViewsCompatible(view1: string, view2: string): boolean {
  const compatible = {
    "Progressive": ["Liberal"],
    "Liberal": ["Progressive", "Moderate"],
    "Moderate": ["Liberal", "Conservative"],
    "Conservative": ["Moderate"],
    "Apolitical": ["Apolitical", "Prefer not to say"]
  };
  return compatible[view1 as keyof typeof compatible]?.includes(view2) || false;
}

function calculatePriorityScore(priorities1: string[], priorities2: string[]): number {
  const commonPriorities = priorities1.filter(p => priorities2.includes(p));
  const maxScore = 3;
  const scorePerMatch = maxScore / 3;
  return Math.min(maxScore, commonPriorities.length * scorePerMatch);
}

function areSexualOrientationsCompatible(orientation1: string, orientation2: string): boolean {
  if (orientation1 === "Prefer not to say" || orientation2 === "Prefer not to say") {
    return true;
  }
  
  const compatibilityMap: { [key: string]: string[] } = {
    "Heterosexual": ["Heterosexual", "Bisexual", "Pansexual"],
    "Homosexual": ["Homosexual", "Bisexual", "Pansexual"],
    "Bisexual": ["Heterosexual", "Homosexual", "Bisexual", "Pansexual"],
    "Pansexual": ["Heterosexual", "Homosexual", "Bisexual", "Pansexual"],
    "Asexual": ["Asexual"]
  };
  
  return compatibilityMap[orientation1]?.includes(orientation2) || false;
}

function calculateRelationshipHistoryScore(history1: string, history2: string): number {
  if (history1 === history2) return 3;
  
  const compatible = {
    "Never been in a relationship": ["Few short-term relationships"],
    "Few short-term relationships": ["Never been in a relationship", "One long-term relationship"],
    "One long-term relationship": ["Few short-term relationships", "Multiple long-term relationships"],
    "Multiple long-term relationships": ["One long-term relationship", "Divorced/Separated"],
    "Divorced/Separated": ["Multiple long-term relationships"]
  };
  
  if (compatible[history1 as keyof typeof compatible]?.includes(history2)) {
    return 2;
  }
  
  return 1;
}

function calculatePersonalityScore(personality1: string, personality2: string): number {
  if (personality1 === personality2) return 2;
  
  const compatible = {
    "Introvert": ["Ambivert"],
    "Extrovert": ["Ambivert", "Social but selective"],
    "Ambivert": ["Introvert", "Extrovert", "Social but selective"],
    "Social but selective": ["Extrovert", "Ambivert"]
  };
  
  if (compatible[personality1 as keyof typeof compatible]?.includes(personality2)) {
    return 1;
  }
  
  return 0.5;
}

function areLoveLanguagesCompatible(lang1: string, lang2: string): boolean {
  const actionBased = ["Acts of Service", "Receiving Gifts"];
  const emotionalBased = ["Words of Affirmation", "Quality Time", "Physical Touch"];
  
  const lang1IsAction = actionBased.includes(lang1);
  const lang2IsAction = actionBased.includes(lang2);
  
  return lang1IsAction !== lang2IsAction;
}

function areLifestylesCompatible(lifestyle1: string, lifestyle2: string): boolean {
  const compatible = {
    "Outdoorsy & Active": ["Spontaneous & Adventurous", "Balanced mix"],
    "Homebody & Cozy": ["Balanced mix"],
    "Balanced mix": ["Outdoorsy & Active", "Homebody & Cozy", "Spontaneous & Adventurous"],
    "Spontaneous & Adventurous": ["Outdoorsy & Active", "Balanced mix"]
  };
  return compatible[lifestyle1 as keyof typeof compatible]?.includes(lifestyle2) || false;
}

// ============================================
// HEIGHT FILTER
// ============================================

export function passesHeightFilter(
  userHeight: number,
  preferenceMin: number,
  preferenceMax: number
): boolean {
  return userHeight >= preferenceMin && userHeight <= preferenceMax;
}

// ============================================
// DISTANCE CALCULATION
// ============================================

export function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  
  return Math.round(distance * 10) / 10;
}

function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

// ============================================
// MATCHMAKING LOGIC
// ============================================

export function findBestMatches(
  currentUser: UserProfile,
  potentialMatches: UserProfile[],
  limit: number = 1
): MatchCandidate[] {
  const candidates: MatchCandidate[] = [];

  for (const candidate of potentialMatches) {
    if (candidate.id === currentUser.id) continue;
    if (!candidate.matchVisibility) continue;

    const heightFilter = passesHeightFilter(
      candidate.height,
      currentUser.questionnaire.heightPreference.min,
      currentUser.questionnaire.heightPreference.max
    );

    if (!heightFilter) continue;

    const compatibilityScore = calculateCompatibilityScore(
      currentUser.questionnaire,
      candidate.questionnaire
    );

    const distance = calculateDistance(
      currentUser.location.lat,
      currentUser.location.lng,
      candidate.location.lat,
      candidate.location.lng
    );

    candidates.push({
      userId: candidate.id,
      profile: candidate,
      compatibilityScore,
      distance,
      passesHeightFilter: heightFilter
    });
  }

  candidates.sort((a, b) => {
    if (b.compatibilityScore !== a.compatibilityScore) {
      return b.compatibilityScore - a.compatibilityScore;
    }
    return a.distance - b.distance;
  });

  return candidates.slice(0, limit);
}
