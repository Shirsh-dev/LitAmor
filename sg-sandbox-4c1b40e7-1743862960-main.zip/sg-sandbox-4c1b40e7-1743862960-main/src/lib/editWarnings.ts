
import { EDIT_WARNING_THRESHOLD_DAYS, MAX_EDITS_PER_WEEK, EditWarning } from "@/types/loneTown";

export function checkEditWarning(
  lastEditedAt?: string,
  editCount: number = 0,
  lastWarningShownAt?: string
): EditWarning {
  if (!lastEditedAt) {
    return {
      show: false,
      message: "",
      lastEditDate: "",
      editCount: 0
    };
  }

  const now = Date.now();
  const lastEdit = new Date(lastEditedAt).getTime();
  const daysSinceLastEdit = (now - lastEdit) / (1000 * 60 * 60 * 24);

  if (daysSinceLastEdit >= EDIT_WARNING_THRESHOLD_DAYS) {
    return {
      show: false,
      message: "",
      lastEditDate: lastEditedAt,
      editCount: 0
    };
  }

  const shouldShowWarning = editCount >= MAX_EDITS_PER_WEEK;
  
  if (!shouldShowWarning) {
    return {
      show: false,
      message: "",
      lastEditDate: lastEditedAt,
      editCount
    };
  }

  const lastWarning = lastWarningShownAt ? new Date(lastWarningShownAt).getTime() : 0;
  const hoursSinceWarning = (now - lastWarning) / (1000 * 60 * 60);
  
  if (hoursSinceWarning < 24) {
    return {
      show: false,
      message: "",
      lastEditDate: lastEditedAt,
      editCount
    };
  }

  const daysRemaining = Math.ceil(EDIT_WARNING_THRESHOLD_DAYS - daysSinceLastEdit);

  return {
    show: true,
    message: `You've edited your compatibility preferences ${editCount} time(s) in the past week. Frequent changes may affect match quality. You can make another edit in ${daysRemaining} day(s).`,
    lastEditDate: lastEditedAt,
    editCount
  };
}

export function recordEdit(currentEditCount: number): {
  newEditCount: number;
  lastEditedAt: string;
  lastWarningShownAt: string;
} {
  return {
    newEditCount: currentEditCount + 1,
    lastEditedAt: new Date().toISOString(),
    lastWarningShownAt: new Date().toISOString()
  };
}
