
// AmorFly Matchmaking Logic

import {
  AmorFlyUser,
  AmorFlyMatch,
  AmorFlyMatchCandidate,
  AmorFlyMatchmakingQueue,
  MATCH_DURATION_HOURS,
  REMATCH_COOLDOWN_DAYS,
  LOCAL_MATCH_RADIUS_KM,
  REGIONAL_MATCH_RADIUS_KM
} from "@/types/amorFly";

// ============================================
// DISTANCE CALCULATION
// ============================================

export function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371; // Earth's radius in kilometers
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// ============================================
// MATCH ELIGIBILITY
// ============================================

export function isUserEligibleForMatching(user: AmorFlyUser): {
  eligible: boolean;
  reason?: string;
} {
  if (user.flyStatus !== "ON") {
    return { eligible: false, reason: "User has 'Ready to Fly' toggled OFF" };
  }

  if (!user.majorInterest) {
    return { eligible: false, reason: "User has not selected a major interest" };
  }

  if (user.minorInterests.length !== 4) {
    return { eligible: false, reason: "User has not selected 4 minor interests" };
  }

  // Check if user already has an active match
  if (user.currentMatchId && user.chatExpiryTime) {
    const expiryTime = new Date(user.chatExpiryTime).getTime();
    const now = Date.now();
    
    if (expiryTime > now) {
      return { eligible: false, reason: "User already has an active match" };
    }
  }

  // Check if last match was within 24 hours
  if (user.lastMatchTime) {
    const lastMatchTime = new Date(user.lastMatchTime).getTime();
    const now = Date.now();
    const hoursSinceLastMatch = (now - lastMatchTime) / (1000 * 60 * 60);
    
    if (hoursSinceLastMatch < MATCH_DURATION_HOURS) {
      return {
        eligible: false,
        reason: `User can receive new match in ${Math.ceil(MATCH_DURATION_HOURS - hoursSinceLastMatch)} hours`
      };
    }
  }

  return { eligible: true };
}

// ============================================
// MATCH CANDIDATE FILTERING
// ============================================

export function filterMatchCandidates(
  user: AmorFlyUser,
  allUsers: AmorFlyUser[]
): AmorFlyMatchCandidate[] {
  const candidates: AmorFlyMatchCandidate[] = [];

  // Get users matched in last 7 days
  const excludedUserIds = getRecentMatchedUserIds(user);

  if (!user.location) {
    // If the primary user has no location, we can't calculate distances.
    return [];
  }

  for (const candidate of allUsers) {
    // Skip self
    if (candidate.id === user.id) continue;

    // Skip if candidate has no location
    if (!candidate.location) continue;

    // Skip if not eligible
    const eligibility = isUserEligibleForMatching(candidate);
    if (!eligibility.eligible) continue;

    // Skip if matched in last 7 days
    if (excludedUserIds.includes(candidate.id)) continue;

    // Primary filter: Must share major interest
    if (candidate.majorInterest !== user.majorInterest) continue;

    // Calculate distance
    const distance = calculateDistance(
      user.location.lat,
      user.location.lng,
      candidate.location.lat,
      candidate.location.lng
    );

    // Find overlapping minor interests
    const overlappingMinorInterests = user.minorInterests.filter(interest =>
      candidate.minorInterests.includes(interest)
    );

    // Determine match scope
    let matchScope: "local" | "regional" | "global" = "global";
    if (distance <= LOCAL_MATCH_RADIUS_KM) {
      matchScope = "local";
    } else if (distance <= REGIONAL_MATCH_RADIUS_KM) {
      matchScope = "regional";
    }

    candidates.push({
      userId: candidate.id,
      user: candidate,
      sharedMajorInterest: user.majorInterest,
      overlappingMinorInterests,
      distance,
      matchScope
    });
  }

  return candidates;
}

// ============================================
// MATCH SCORING & PRIORITIZATION
// ============================================

export function scoreMatchCandidate(candidate: AmorFlyMatchCandidate): number {
  let score = 0;

  // Overlapping minor interests (10 points each)
  score += candidate.overlappingMinorInterests.length * 10;

  // Distance bonus (closer = better)
  if (candidate.matchScope === "local") {
    score += 50;
  } else if (candidate.matchScope === "regional") {
    score += 25;
  }

  // Inverse distance score (max 20 points)
  const distanceScore = Math.max(0, 20 - candidate.distance / 50);
  score += distanceScore;

  return score;
}

export function selectBestMatch(
  candidates: AmorFlyMatchCandidate[]
): AmorFlyMatchCandidate | null {
  if (candidates.length === 0) return null;

  // Score all candidates
  const scoredCandidates = candidates.map(candidate => ({
    candidate,
    score: scoreMatchCandidate(candidate)
  }));

  // Sort by score (highest first)
  scoredCandidates.sort((a, b) => b.score - a.score);

  return scoredCandidates[0].candidate;
}

// ============================================
// MATCH CREATION
// ============================================

export function createMatch(
  user1: AmorFlyUser,
  user2: AmorFlyUser,
  candidate: AmorFlyMatchCandidate
): AmorFlyMatch {
  const now = Date.now();
  const expiresAt = now + MATCH_DURATION_HOURS * 60 * 60 * 1000;

  return {
    id: generateMatchId(),
    user1Id: user1.id,
    user2Id: user2.id,
    sharedMajorInterest: candidate.sharedMajorInterest,
    overlappingMinorInterests: candidate.overlappingMinorInterests,
    matchCreatedAt: now,
    matchExpiresAt: expiresAt,
    status: "active",
    messageCount: 0,
    voiceCallActive: false,
    matchScope: candidate.matchScope,
    createdAt: now
  };
}

// ============================================
// MATCH EXPIRY
// ============================================

export function isMatchExpired(match: AmorFlyMatch): boolean {
  const now = Date.now();
  const expiryTime = match.matchExpiresAt;
  return now >= expiryTime;
}

export function getTimeUntilExpiry(match: AmorFlyMatch): {
  hours: number;
  minutes: number;
  expired: boolean;
} {
  const now = Date.now();
  const expiryTime = match.matchExpiresAt;
  const diff = expiryTime - now;

  if (diff <= 0) {
    return { hours: 0, minutes: 0, expired: true };
  }

  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

  return { hours, minutes, expired: false };
}

// ============================================
// RECENT MATCH TRACKING
// ============================================

export function getRecentMatchedUserIds(user: AmorFlyUser): string[] {
  if (!user.recentMatchUserIds) return [];

  // Filter matches from last 7 days
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - REMATCH_COOLDOWN_DAYS);

  return user.recentMatchUserIds;
}

export function addToRecentMatches(
  user: AmorFlyUser,
  matchedUserId: string
): string[] {
  const recentMatches = user.recentMatchUserIds || [];
  
  // Add new match
  const updated = [...recentMatches, matchedUserId];
  
  // Keep only unique entries
  return Array.from(new Set(updated));
}

export function cleanupOldMatches(
  recentMatchUserIds: string[],
  matchTimestamps: { [userId: string]: string }
): string[] {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - REMATCH_COOLDOWN_DAYS);
  const cutoffTime = cutoffDate.getTime();

  return recentMatchUserIds.filter(userId => {
    const matchTime = matchTimestamps[userId];
    if (!matchTime) return false;
    
    const matchDate = new Date(matchTime).getTime();
    return matchDate >= cutoffTime;
  });
}

// ============================================
// DAILY REFRESH
// ============================================

export function shouldTriggerDailyRefresh(lastRefreshTime?: string): boolean {
  if (!lastRefreshTime) return true;

  const lastRefresh = new Date(lastRefreshTime);
  const now = new Date();

  // Check if it's a new day (UTC)
  return lastRefresh.getUTCDate() !== now.getUTCDate();
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

export function generateMatchId(): string {
  return `match_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export function generateConversationId(): string {
  return `conv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export function getRandomChatPrompt(): string {
  const prompts = [
    "What inspired you to choose this interest?",
    "What's one thing you want to learn today?",
    "Tell me something fun or weird about this hobby.",
    "How do you practice this in daily life?",
    "What's the best thing you've discovered through this interest?",
    "If you could master one skill in this area, what would it be?"
  ];

  return prompts[Math.floor(Math.random() * prompts.length)];
}

// ============================================
// MAIN MATCH FINDER
// ============================================

export function findAmorFlyMatch(
  user: AmorFlyUser,
  allUsers: AmorFlyUser[]
): { match: AmorFlyMatch | null; matchedUser: AmorFlyUser | null } {
  const candidates = filterMatchCandidates(user, allUsers);
  if (candidates.length === 0) {
    return { match: null, matchedUser: null };
  }

  const bestCandidate = selectBestMatch(candidates);
  if (!bestCandidate) {
    return { match: null, matchedUser: null };
  }

  const match = createMatch(user, bestCandidate.user, bestCandidate);

  return { match, matchedUser: bestCandidate.user };
}

// ============================================
// BATCH MATCHMAKING
// ============================================

export function performBatchMatchmaking(
  users: AmorFlyUser[]
): Array<{
  user1: AmorFlyUser;
  user2: AmorFlyUser;
  match: AmorFlyMatch;
}> {
  const matches: Array<{
    user1: AmorFlyUser;
    user2: AmorFlyUser;
    match: AmorFlyMatch;
  }> = [];

  const matchedUserIds = new Set<string>();

  // Filter eligible users
  const eligibleUsers = users.filter(user => {
    const eligibility = isUserEligibleForMatching(user);
    return eligibility.eligible && !matchedUserIds.has(user.id);
  });

  // Group by major interest
  const usersByInterest = new Map<string, AmorFlyUser[]>();
  eligibleUsers.forEach(user => {
    const interest = user.majorInterest;
    if (!usersByInterest.has(interest)) {
      usersByInterest.set(interest, []);
    }
    usersByInterest.get(interest)!.push(user);
  });

  // Match within each interest group
  usersByInterest.forEach((interestUsers, interest) => {
    while (interestUsers.length >= 2) {
      const user1 = interestUsers[0];
      
      // Find best match for user1
      const candidates = filterMatchCandidates(user1, interestUsers.slice(1));
      const bestCandidate = selectBestMatch(candidates);

      if (!bestCandidate) {
        interestUsers.shift();
        continue;
      }

      // Create match
      const match = createMatch(user1, bestCandidate.user, bestCandidate);
      
      matches.push({
        user1,
        user2: bestCandidate.user,
        match
      });

      // Mark as matched
      matchedUserIds.add(user1.id);
      matchedUserIds.add(bestCandidate.user.id);

      // Remove from pool
      interestUsers.splice(0, 1);
      const user2Index = interestUsers.findIndex(u => u.id === bestCandidate.user.id);
      if (user2Index !== -1) {
        interestUsers.splice(user2Index, 1);
      }
    }
  });

  return matches;
}
