
import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Settings, Plus, RefreshCw, Star, Globe, Heart, Moon } from "lucide-react";
import Image from "next/image";
import { OrbitItem } from "@/components/planet/OrbitItem";
import { OrbitItemViewer } from "@/components/planet/OrbitItemViewer";
import { AddOrbitItemModal } from "@/components/planet/AddOrbitItemModal";
import { LitAmorLogo } from "@/components/LitAmorLogo";

interface OrbitItemType {
  id: string;
  type: "note" | "dream" | "mood" | "quote";
  content: string;
  icon: "Star" | "Heart" | "Moon" | "Globe";
  color: string;
  position: {
    angle: number;
    distance: number;
  };
  createdAt: string;
}

export function PlanetView() {
  const [selectedItem, setSelectedItem] = useState<OrbitItemType | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [stars, setStars] = useState<Array<{ id: number; style: React.CSSProperties }>>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Sample couple data
  const coupleData = {
    name: "Sarah & Michael",
    initials: "S&M",
    mood: "Feeling Grateful 💕",
    partner1: {
      name: "Sarah",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80"
    },
    partner2: {
      name: "Michael",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80"
    }
  };
  
  // Sample orbit items
  const sampleOrbitItems: OrbitItemType[] = [
    {
      id: "1",
      type: "dream",
      content: "Trip to Paris 🛫",
      icon: "Star",
      color: "#FFD700",
      position: {
        angle: 45,
        distance: 160
      },
      createdAt: "2025-04-10"
    },
    {
      id: "2",
      type: "note",
      content: "I love how we're growing together",
      icon: "Heart",
      color: "#FF6B81",
      position: {
        angle: 135,
        distance: 180
      },
      createdAt: "2025-04-12"
    },
    {
      id: "3",
      type: "mood",
      content: "Feeling Grateful 💕",
      icon: "Moon",
      color: "#9C88FF",
      position: {
        angle: 225,
        distance: 140
      },
      createdAt: "2025-04-15"
    },
    {
      id: "4",
      type: "quote",
      content: "Love is not just looking at each other, it's looking in the same direction.",
      icon: "Globe",
      color: "#4CD4B0",
      position: {
        angle: 315,
        distance: 200
      },
      createdAt: "2025-04-18"
    }
  ];
  
  // Generate stars for the background
  useEffect(() => {
    const generateStar = () => {
      const id = Date.now() + Math.random() * 1000;
      const left = Math.random() * 100;
      const top = Math.random() * 100;
      const size = 1 + Math.random() * 3;
      const opacity = 0.3 + Math.random() * 0.7;
      const animationDuration = 2 + Math.random() * 4;
      
      return {
        id,
        style: {
          left: `${left}%`,
          top: `${top}%`,
          width: `${size}px`,
          height: `${size}px`,
          opacity,
          animationDuration: `${animationDuration}s`
        }
      };
    };
    
    // Generate initial stars
    const initialStars = Array.from({ length: 100 }, generateStar);
    setStars(initialStars);
  }, []);
  
  const handleOpenItem = (item: OrbitItemType) => {
    setSelectedItem(item);
  };
  
  const handleCloseItem = () => {
    setSelectedItem(null);
  };
  
  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case "Star":
        return <Star className="h-full w-full" />;
      case "Heart":
        return <Heart className="h-full w-full" />;
      case "Moon":
        return <Moon className="h-full w-full" />;
      case "Globe":
        return <Globe className="h-full w-full" />;
      default:
        return <Star className="h-full w-full" />;
    }
  };
  
  return (
    <div className="min-h-screen cosmic-gradient flex flex-col">
      {/* Top Bar */}
      <header className="w-full py-4 px-6 flex items-center justify-between bg-indigo-950/30 backdrop-blur-sm border-b border-indigo-500/20">
        <Button variant="ghost" size="icon" className="rounded-full text-indigo-200">
          <Globe className="h-5 w-5" />
          <span className="sr-only">Explore Other Planets</span>
        </Button>
        
        <div className="flex flex-col items-center">
          <h1 className="text-2xl font-bold text-indigo-100 tracking-wide">Planet</h1>
          <div className="flex items-center gap-1">
            <LitAmorLogo size="small" />
            <span className="text-xs text-indigo-300">Lit Amor</span>
          </div>
        </div>
        
        <Button variant="ghost" size="icon" className="rounded-full text-indigo-200">
          <Settings className="h-5 w-5" />
          <span className="sr-only">Settings</span>
        </Button>
      </header>
      
      {/* Couple Info Bar */}
      <div className="w-full py-3 px-6 flex items-center justify-between bg-indigo-950/20 backdrop-blur-sm border-b border-indigo-500/20">
        <div className="flex items-center gap-3">
          <div className="flex items-center -space-x-2">
            <Avatar className="border-2 border-indigo-500/50 h-8 w-8">
              <AvatarFallback>{coupleData.partner1.name[0]}</AvatarFallback>
              <AvatarImage src={coupleData.partner1.avatar} alt={coupleData.partner1.name} />
            </Avatar>
            <Avatar className="border-2 border-indigo-500/50 h-8 w-8">
              <AvatarFallback>{coupleData.partner2.name[0]}</AvatarFallback>
              <AvatarImage src={coupleData.partner2.avatar} alt={coupleData.partner2.name} />
            </Avatar>
          </div>
          <span className="text-sm font-medium text-indigo-100">{coupleData.name}</span>
        </div>
        
        <div className="flex items-center gap-2">
          <div className="text-xs px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-200">
            {coupleData.mood}
          </div>
        </div>
      </div>
      
      {/* Planet View */}
      <div className="flex-1 relative overflow-hidden">
        {/* Stars background */}
        <div className="absolute inset-0 bg-gradient-to-b from-indigo-950 via-purple-900 to-indigo-900 overflow-hidden">
          {stars.map((star) => (
            <div
              key={star.id}
              className="absolute rounded-full bg-white animate-twinkle"
              style={star.style}
            />
          ))}
          
          {/* Nebula effects */}
          <div className="absolute top-[20%] left-[10%] w-64 h-64 rounded-full bg-pink-500/10 blur-3xl" />
          <div className="absolute bottom-[30%] right-[15%] w-80 h-80 rounded-full bg-indigo-500/10 blur-3xl" />
          <div className="absolute top-[60%] left-[30%] w-72 h-72 rounded-full bg-purple-500/10 blur-3xl" />
          
          {/* Floating clouds */}
          <motion.div
            className="absolute top-[15%] left-[25%] w-32 h-16 bg-indigo-300/10 rounded-full blur-xl"
            animate={{ x: [0, 20, 0], y: [0, -10, 0] }}
            transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div
            className="absolute bottom-[25%] right-[20%] w-40 h-20 bg-purple-300/10 rounded-full blur-xl"
            animate={{ x: [0, -30, 0], y: [0, 15, 0] }}
            transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
          />
        </div>
        
        {/* Planet and orbits */}
        <div className="absolute inset-0 flex items-center justify-center">
          {/* Orbit paths */}
          <div className="absolute w-[400px] h-[400px] rounded-full border border-indigo-500/10" />
          <div className="absolute w-[320px] h-[320px] rounded-full border border-indigo-500/10" />
          <div className="absolute w-[240px] h-[240px] rounded-full border border-indigo-500/10" />
          
          {/* Planet */}
          <motion.div
            className="relative w-32 h-32 rounded-full bg-gradient-to-br from-indigo-600 to-purple-700 shadow-[0_0_30px_rgba(79,70,229,0.4)]"
            animate={{ 
              scale: [1, 1.03, 1],
              rotate: [0, 5, 0, -5, 0]
            }}
            transition={{ 
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            {/* Planet surface details */}
            <div className="absolute inset-0 rounded-full overflow-hidden opacity-30">
              <div className="absolute top-[10%] left-[20%] w-10 h-10 rounded-full bg-indigo-300/40" />
              <div className="absolute bottom-[30%] right-[15%] w-12 h-12 rounded-full bg-purple-300/40" />
              <div className="absolute top-[60%] left-[10%] w-8 h-8 rounded-full bg-pink-300/40" />
            </div>
            
            {/* Couple initials */}
            <div className="absolute inset-0 flex items-center justify-center text-white font-bold text-xl">
              {coupleData.initials}
            </div>
            
            {/* Glow effect */}
            <div className="absolute -inset-4 rounded-full bg-indigo-500/20 blur-xl -z-10" />
          </motion.div>
          
          {/* Orbiting items */}
          {sampleOrbitItems.map((item) => (
            <OrbitItem
              key={item.id}
              item={item}
              onClick={() => handleOpenItem(item)}
              getIconComponent={getIconComponent}
            />
          ))}
        </div>
      </div>
      
      {/* Bottom Bar */}
      <div className="w-full py-4 px-6 flex items-center justify-between bg-indigo-950/30 backdrop-blur-sm border-t border-indigo-500/20">
        <Button variant="ghost" size="icon" className="rounded-full text-indigo-200">
          <RefreshCw className="h-5 w-5" />
          <span className="sr-only">Refresh</span>
        </Button>
        
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button 
            onClick={() => setShowAddModal(true)}
            className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-medium rounded-full px-6 py-6 flex items-center gap-2 shadow-lg shadow-indigo-500/30"
          >
            <Plus className="h-5 w-5" />
            <span>Add to Orbit</span>
          </Button>
        </motion.div>
        
        <div className="w-10 h-10" /> {/* Spacer to balance layout */}
      </div>
      
      {/* Orbit Item Viewer Modal */}
      <AnimatePresence>
        {selectedItem && (
          <OrbitItemViewer 
            item={selectedItem} 
            onClose={handleCloseItem} 
            getIconComponent={getIconComponent}
          />
        )}
      </AnimatePresence>
      
      {/* Add Orbit Item Modal */}
      <AnimatePresence>
        {showAddModal && (
          <AddOrbitItemModal onClose={() => setShowAddModal(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}
