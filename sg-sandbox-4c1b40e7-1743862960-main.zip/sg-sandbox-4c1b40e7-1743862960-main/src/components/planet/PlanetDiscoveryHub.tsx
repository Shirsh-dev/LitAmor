import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  Settings, 
  Shuffle, 
  Heart, 
  Navigation, 
  Bell,
  Calendar,
  MapPin,
  Gift,
  Target,
  User,
  Theater,
  Globe,
  MessageCircle,
  Package,
  Sparkles,
  Home,
  Bookmark,
  Compass,
  Users
} from "lucide-react";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import { DateverseView } from "@/components/planet/features/DateverseView";
import { HiddenSpotsView } from "@/components/planet/features/HiddenSpotsView";
import { GiftGalaxyView } from "@/components/planet/features/GiftGalaxyView";
import { CoupleQuestsView } from "@/components/planet/features/CoupleQuestsView";
import { SoloSparksView } from "@/components/planet/features/SoloSparksView";
import { MoodTrailsView } from "@/components/planet/features/MoodTrailsView";
import { PulseOfPlanetView } from "@/components/planet/features/PulseOfPlanetView";
import { EventHorizonView } from "@/components/planet/features/EventHorizonView";
import { ThoughtDropsView } from "@/components/planet/features/ThoughtDropsView";
import { MemoryCapsulesView } from "@/components/planet/features/MemoryCapsulesView";

interface GalaxyOrb {
  id: string;
  title: string;
  emoji: string;
  icon: React.ReactNode;
  description: string;
  color: string;
  glowColor: string;
  category: "couple" | "self" | "general";
}

interface PlanetDiscoveryHubProps {
  userType: "single" | "couple";
}

export function PlanetDiscoveryHub({ userType }: PlanetDiscoveryHubProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFeature, setSelectedFeature] = useState<string | null>(null);
  const [selectedCapsule, setSelectedCapsule] = useState<string | null>(null);
  const [stars, setStars] = useState<Array<{ id: number; style: React.CSSProperties }>>([]);
  const [savedItems, setSavedItems] = useState<string[]>([]);

  const galaxyOrbs: GalaxyOrb[] = [
    // Couple Capsule Cards
    {
      id: "dateverse",
      title: "Dateverse",
      emoji: "🌌",
      icon: <Calendar className="h-5 w-5" />,
      description: "Date ideas",
      color: "from-purple-400 to-pink-400",
      glowColor: "purple-400/40",
      category: "couple"
    },
    {
      id: "couple-quests",
      title: "Couple Quests",
      emoji: "🎯",
      icon: <Target className="h-5 w-5" />,
      description: "Fun bonding missions",
      color: "from-orange-400 to-red-400",
      glowColor: "orange-400/40",
      category: "couple"
    },
    {
      id: "pulse-of-planet",
      title: "Pulse of the Planet",
      emoji: "🌍",
      icon: <Globe className="h-5 w-5" />,
      description: "Global love trends",
      color: "from-blue-400 to-cyan-400",
      glowColor: "blue-400/40",
      category: "couple"
    },
    // Self Capsule Cards
    {
      id: "solo-sparks",
      title: "Solo Sparks",
      emoji: "🪞",
      icon: <User className="h-5 w-5" />,
      description: "Self-discovery for singles",
      color: "from-indigo-400 to-purple-400",
      glowColor: "indigo-400/40",
      category: "self"
    },
    {
      id: "mood-trails",
      title: "Mood Trails",
      emoji: "🎭",
      icon: <Theater className="h-5 w-5" />,
      description: "Emotion-based activity guides",
      color: "from-violet-400 to-purple-400",
      glowColor: "violet-400/40",
      category: "self"
    },
    {
      id: "thought-drops",
      title: "Thought Drops",
      emoji: "💭",
      icon: <MessageCircle className="h-5 w-5" />,
      description: "Expressive short thoughts",
      color: "from-sky-400 to-blue-400",
      glowColor: "sky-400/40",
      category: "self"
    },
    // General Cards (outside capsules)
    {
      id: "hidden-spots",
      title: "Hidden Spots",
      emoji: "🗺️",
      icon: <MapPin className="h-5 w-5" />,
      description: "Nearby exploration spots",
      color: "from-emerald-400 to-teal-400",
      glowColor: "emerald-400/40",
      category: "general"
    },
    {
      id: "gift-galaxy",
      title: "Gift Galaxy",
      emoji: "🎁",
      icon: <Gift className="h-5 w-5" />,
      description: "Personalized gift ideas",
      color: "from-rose-400 to-pink-400",
      glowColor: "rose-400/40",
      category: "general"
    },
    {
      id: "memory-capsules",
      title: "Memory Capsules",
      emoji: "📦",
      icon: <Package className="h-5 w-5" />,
      description: "Save couple moments",
      color: "from-pink-400 to-rose-400",
      glowColor: "pink-400/40",
      category: "general"
    },
    {
      id: "event-horizon",
      title: "Event Horizon",
      emoji: "📆",
      icon: <Calendar className="h-5 w-5" />,
      description: "Virtual/local events",
      color: "from-amber-400 to-yellow-400",
      glowColor: "amber-400/40",
      category: "general"
    }
  ];

  const coupleOrbs = galaxyOrbs.filter(orb => orb.category === "couple");
  const selfOrbs = galaxyOrbs.filter(orb => orb.category === "self");
  const generalOrbs = galaxyOrbs.filter(orb => orb.category === "general");

  // Generate stars for background
  useEffect(() => {
    const generateStar = () => {
      const id = Date.now() + Math.random() * 1000;
      const left = Math.random() * 100;
      const top = Math.random() * 100;
      const size = 1 + Math.random() * 3;
      const opacity = 0.2 + Math.random() * 0.6;
      const animationDuration = 4 + Math.random() * 8;
      
      return {
        id,
        style: {
          left: `${left}%`,
          top: `${top}%`,
          width: `${size}px`,
          height: `${size}px`,
          opacity,
          animationDuration: `${animationDuration}s`
        }
      };
    };
    
    const initialStars = Array.from({ length: 200 }, generateStar);
    setStars(initialStars);
  }, []);

  const handleOrbClick = (orbId: string) => {
    setSelectedFeature(orbId);
  };

  const handleCapsuleClick = (capsuleType: string) => {
    setSelectedCapsule(selectedCapsule === capsuleType ? null : capsuleType);
  };

  const handleBackToPlanet = () => {
    setSelectedFeature(null);
    setSelectedCapsule(null);
  };

  const handleSaveItem = (itemId: string) => {
    setSavedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const handleShuffle = () => {
    const availableOrbs = galaxyOrbs.filter(orb => orb.id !== selectedFeature);
    if (availableOrbs.length > 0) {
      const randomOrb = availableOrbs[Math.floor(Math.random() * availableOrbs.length)];
      setSelectedFeature(randomOrb.id);
    }
  };

  const renderFeatureView = () => {
    switch (selectedFeature) {
      case "dateverse":
        return <DateverseView onBack={handleBackToPlanet} onSave={handleSaveItem} />;
      case "hidden-spots":
        return <HiddenSpotsView onBack={handleBackToPlanet} onSave={handleSaveItem} />;
      case "gift-galaxy":
        return <GiftGalaxyView onBack={handleBackToPlanet} onSave={handleSaveItem} />;
      case "couple-quests":
        return <CoupleQuestsView onBack={handleBackToPlanet} onSave={handleSaveItem} />;
      case "solo-sparks":
        return <SoloSparksView onBack={handleBackToPlanet} onSave={handleSaveItem} />;
      case "mood-trails":
        return <MoodTrailsView onBack={handleBackToPlanet} onSave={handleSaveItem} />;
      case "pulse-of-planet":
        return <PulseOfPlanetView onBack={handleBackToPlanet} onSave={handleSaveItem} />;
      case "event-horizon":
        return <EventHorizonView onBack={handleBackToPlanet} onSave={handleSaveItem} />;
      case "thought-drops":
        return <ThoughtDropsView onBack={handleBackToPlanet} onSave={handleSaveItem} />;
      case "memory-capsules":
        return <MemoryCapsulesView onBack={handleBackToPlanet} onSave={handleSaveItem} />;
      default:
        return null;
    }
  };

  const renderCircularCard = (orb: GalaxyOrb, index: number) => (
    <motion.div
      key={orb.id}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      animate={{
        y: [0, -8, 0],
        rotate: [0, 3, 0, -3, 0]
      }}
      transition={{
        y: { duration: 4 + index * 0.5, repeat: Infinity, ease: "easeInOut" },
        rotate: { duration: 8 + index * 0.3, repeat: Infinity, ease: "easeInOut" }
      }}
      className="flex flex-col items-center"
    >
      <Button
        onClick={() => handleOrbClick(orb.id)}
        className={`w-20 h-20 md:w-24 md:h-24 rounded-full bg-gradient-to-br ${orb.color} hover:scale-110 transition-all duration-300 shadow-lg border-2 border-white/30 p-0 touch-friendly focus-ring animate-pulse-glow`}
      >
        <div className="flex flex-col items-center justify-center text-white">
          <span className="text-2xl md:text-3xl">{orb.emoji}</span>
        </div>
      </Button>
      <p className="text-xs md:text-sm text-white/80 font-medium text-center mt-2 max-w-20">
        {orb.title}
      </p>
    </motion.div>
  );

  if (selectedFeature) {
    return (
      <div className="min-h-screen relative">
        {renderFeatureView()}
        
        {/* Floating Action Buttons - Mobile Optimized */}
        <div className="fixed bottom-20 right-4 md:bottom-6 md:right-6 flex flex-col gap-3 z-50">
          <motion.div 
            whileHover={{ scale: 1.1 }} 
            whileTap={{ scale: 0.9 }}
            className="touch-friendly"
          >
            <Button
              onClick={handleShuffle}
              size="icon"
              className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-r from-purple-400 to-pink-400 hover:from-purple-500 hover:to-pink-500 text-white shadow-lg shadow-purple-400/30 border-0"
            >
              <Shuffle className="h-5 w-5 md:h-6 md:w-6" />
            </Button>
          </motion.div>
          
          <motion.div 
            whileHover={{ scale: 1.1 }} 
            whileTap={{ scale: 0.9 }}
            className="touch-friendly"
          >
            <Button
              size="icon"
              className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-r from-rose-400 to-pink-400 hover:from-rose-500 hover:to-pink-500 text-white shadow-lg shadow-rose-400/30 border-0"
            >
              <Heart className="h-5 w-5 md:h-6 md:w-6" />
            </Button>
          </motion.div>
          
          <motion.div 
            whileHover={{ scale: 1.1 }} 
            whileTap={{ scale: 0.9 }}
            className="touch-friendly"
          >
            <Button
              onClick={handleBackToPlanet}
              size="icon"
              className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-r from-indigo-400 to-purple-400 hover:from-indigo-500 hover:to-purple-500 text-white shadow-lg shadow-indigo-400/30 border-0"
            >
              <Navigation className="h-5 w-5 md:h-6 md:w-6" />
            </Button>
          </motion.div>
        </div>

        {/* Bottom Navigation Bar - Mobile */}
        <div className="fixed bottom-0 left-0 right-0 bg-white/10 backdrop-blur-lg border-t border-white/20 md:hidden z-40">
          <div className="flex items-center justify-around py-2 px-4">
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex flex-col items-center gap-1 text-white/70 hover:text-white touch-friendly"
              onClick={handleBackToPlanet}
            >
              <Home className="h-5 w-5" />
              <span className="text-xs">Planet</span>
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex flex-col items-center gap-1 text-white/70 hover:text-white touch-friendly"
            >
              <Bookmark className="h-5 w-5" />
              <span className="text-xs">My Universe</span>
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex flex-col items-center gap-1 text-white/70 hover:text-white touch-friendly"
            >
              <Compass className="h-5 w-5" />
              <span className="text-xs">Discover</span>
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex flex-col items-center gap-1 text-white/70 hover:text-white touch-friendly"
              onClick={handleShuffle}
            >
              <Sparkles className="h-5 w-5" />
              <span className="text-xs">Random</span>
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex flex-col items-center gap-1 text-white/70 hover:text-white touch-friendly"
            >
              <User className="h-5 w-5" />
              <span className="text-xs">Profile</span>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-950 via-purple-900 to-pink-900 relative overflow-hidden">
      {/* Enhanced Animated Stars Background */}
      <div className="absolute inset-0 overflow-hidden">
        {stars.map((star) => (
          <div
            key={star.id}
            className="absolute rounded-full bg-white animate-twinkle"
            style={star.style}
          />
        ))}
        
        {/* Enhanced Nebula effects with softer colors */}
        <div className="absolute top-[10%] left-[5%] w-96 h-96 rounded-full bg-purple-400/10 blur-3xl animate-pulse" />
        <div className="absolute bottom-[20%] right-[10%] w-80 h-80 rounded-full bg-pink-400/10 blur-3xl animate-pulse" />
        <div className="absolute top-[50%] left-[20%] w-72 h-72 rounded-full bg-indigo-400/10 blur-3xl animate-pulse" />
        <div className="absolute bottom-[40%] left-[60%] w-64 h-64 rounded-full bg-teal-400/10 blur-3xl animate-pulse" />
      </div>

      {/* Header - Mobile Optimized */}
      <header className="relative z-10 w-full py-4 md:py-6 px-4 md:px-6 mobile-padding">
        <div className="flex items-center justify-between mb-4 md:mb-6">
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white touch-friendly focus-ring"
          >
            <Settings className="h-5 w-5 md:h-6 md:w-6" />
          </Button>
          
          <div className="flex flex-col items-center">
            <LitAmorLogo size="default" />
            <span className="text-xs md:text-sm text-white/60 mt-1">Lit Amor</span>
          </div>
          
          <div className="w-10 h-10" />
        </div>

        <div className="text-center mb-6 md:mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-white mb-2 mobile-heading">
            Explore Your Universe of Emotions 💫
          </h1>
          <p className="text-white/70 text-base md:text-lg mobile-text">Welcome to Planet</p>
        </div>

        {/* Enhanced Search Bar */}
        <div className="relative max-w-md mx-auto mb-8">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/50 h-5 w-5" />
          <Input
            placeholder="Find a gift, a date idea, or a nearby vibe..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 bg-white/10 border-white/20 text-white placeholder:text-white/50 rounded-full py-3 md:py-6 glass-effect focus-ring"
          />
        </div>
      </header>

      {/* Main Content */}
      <div className="relative z-10 flex-1 px-4 md:px-6 pb-24 md:pb-20 mobile-padding">
        <div className="max-w-4xl mx-auto">
          
          {/* Capsules Section */}
          <div className="flex flex-col md:flex-row gap-6 mb-12">
            
            {/* Self Capsule */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex-1"
            >
              <div 
                className={`relative rounded-3xl p-6 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border-2 border-indigo-400/30 backdrop-blur-sm cursor-pointer transition-all duration-300 ${
                  selectedCapsule === "self" ? "ring-4 ring-indigo-400/50" : "hover:border-indigo-400/50"
                }`}
                onClick={() => handleCapsuleClick("self")}
              >
                <div className="text-center mb-6">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <User className="h-6 w-6 text-indigo-300" />
                    <h2 className="text-xl font-bold text-white">Self</h2>
                  </div>
                  <p className="text-indigo-200/80 text-sm">Personal growth</p>
                </div>
                
                {selectedCapsule === "self" ? (
                  <div className="grid grid-cols-2 gap-4">
                    {selfOrbs.map((orb, index) => renderCircularCard(orb, index))}
                  </div>
                ) : (
                  <div className="flex justify-center items-center gap-4">
                    {selfOrbs.map((orb, index) => (
                      <div key={orb.id} className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-400/50 to-purple-400/50 flex items-center justify-center">
                        <span className="text-lg">{orb.emoji}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </div>

          {/* General Cards - 2x2 Grid */}
          <div className="grid grid-cols-2 gap-6">
            {generalOrbs.map((orb, index) => (
              <motion.div
                key={orb.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex justify-center"
              >
                {renderCircularCard(orb, index)}
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Enhanced Spin the Planet Button */}
      <div className="fixed bottom-20 md:bottom-6 left-1/2 transform -translate-x-1/2 z-20">
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          animate={{ rotate: 360 }}
          transition={{ rotate: { duration: 20, repeat: Infinity, ease: "linear" } }}
        >
          <Button
            onClick={handleShuffle}
            className="bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-white font-bold rounded-full px-4 py-3 md:px-6 md:py-3 shadow-lg shadow-orange-400/40 flex items-center gap-2 pill-button touch-friendly focus-ring"
          >
            <Sparkles className="h-4 w-4 md:h-5 md:w-5" />
            <span className="text-sm md:text-base">Spin the Planet</span>
          </Button>
        </motion.div>
      </div>

      {/* Bottom Navigation Bar - Mobile */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/10 backdrop-blur-lg border-t border-white/20 md:hidden z-40">
        <div className="flex items-center justify-around py-2 px-4">
          <Button 
            variant="ghost" 
            size="sm" 
            className="flex flex-col items-center gap-1 text-white/70 hover:text-white touch-friendly focus-ring"
          >
            <Home className="h-5 w-5" />
            <span className="text-xs">Planet</span>
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="flex flex-col items-center gap-1 text-white/70 hover:text-white touch-friendly focus-ring"
          >
            <Bookmark className="h-5 w-5" />
            <span className="text-xs">My Universe</span>
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="flex flex-col items-center gap-1 text-white/70 hover:text-white touch-friendly focus-ring"
          >
            <Compass className="h-5 w-5" />
            <span className="text-xs">Discover</span>
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="flex flex-col items-center gap-1 text-white/70 hover:text-white touch-friendly focus-ring"
            onClick={handleShuffle}
          >
            <Sparkles className="h-5 w-5" />
            <span className="text-xs">Random</span>
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="flex flex-col items-center gap-1 text-white/70 hover:text-white touch-friendly focus-ring"
          >
            <User className="h-5 w-5" />
            <span className="text-xs">Profile</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
