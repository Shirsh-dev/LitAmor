
import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { X, Star, Heart, Moon, Globe } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

interface AddOrbitItemModalProps {
  onClose: () => void;
}

export function AddOrbitItemModal({ onClose }: AddOrbitItemModalProps) {
  const [itemType, setItemType] = useState<"note" | "dream" | "mood" | "quote">("note");
  const [content, setContent] = useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save the orbit item
    onClose();
  };
  
  const getPlaceholder = () => {
    switch (itemType) {
      case "note":
        return "Write a note about your feelings or thoughts...";
      case "dream":
        return "Share a dream or goal you both have...";
      case "mood":
        return "Express your current mood or emotion...";
      case "quote":
        return "Share an inspiring quote or meaningful words...";
      default:
        return "Write something...";
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div 
        className="bg-gradient-to-b from-indigo-950 to-purple-950 rounded-2xl w-full max-w-md mx-4 overflow-hidden shadow-xl border border-indigo-500/30"
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        transition={{ duration: 0.3 }}
      >
        <div className="p-4 border-b border-indigo-500/30 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-indigo-100">Add to Orbit</h2>
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full text-indigo-300 hover:text-indigo-100 hover:bg-indigo-800/50"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <Tabs defaultValue="note" onValueChange={(value) => setItemType(value as any)}>
            <TabsList className="grid grid-cols-4 bg-indigo-900/50">
              <TabsTrigger value="note" className="data-[state=active]:bg-indigo-700">
                <div className="flex flex-col items-center gap-1">
                  <Heart className="h-4 w-4" />
                  <span className="text-xs">Note</span>
                </div>
              </TabsTrigger>
              <TabsTrigger value="dream" className="data-[state=active]:bg-indigo-700">
                <div className="flex flex-col items-center gap-1">
                  <Star className="h-4 w-4" />
                  <span className="text-xs">Dream</span>
                </div>
              </TabsTrigger>
              <TabsTrigger value="mood" className="data-[state=active]:bg-indigo-700">
                <div className="flex flex-col items-center gap-1">
                  <Moon className="h-4 w-4" />
                  <span className="text-xs">Mood</span>
                </div>
              </TabsTrigger>
              <TabsTrigger value="quote" className="data-[state=active]:bg-indigo-700">
                <div className="flex flex-col items-center gap-1">
                  <Globe className="h-4 w-4" />
                  <span className="text-xs">Quote</span>
                </div>
              </TabsTrigger>
            </TabsList>
            
            <div className="mt-6">
              <Textarea 
                placeholder={getPlaceholder()}
                className="resize-none h-32 bg-indigo-900/30 border-indigo-500/30 text-indigo-100 placeholder:text-indigo-400"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />
            </div>
          </Tabs>
          
          <div className="pt-4 flex justify-end gap-3">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose} 
              className="rounded-full border-indigo-500/50 text-indigo-300 hover:text-indigo-100 hover:bg-indigo-800/50"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white rounded-full"
              disabled={!content.trim()}
            >
              Add to Orbit
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
