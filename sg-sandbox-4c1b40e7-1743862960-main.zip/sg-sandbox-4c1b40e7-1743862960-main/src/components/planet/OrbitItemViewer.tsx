
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { X, Calendar } from "lucide-react";
import { formatDate } from "@/lib/utils";

interface OrbitItemType {
  id: string;
  type: "note" | "dream" | "mood" | "quote";
  content: string;
  icon: string;
  color: string;
  position: {
    angle: number;
    distance: number;
  };
  createdAt: string;
}

interface OrbitItemViewerProps {
  item: OrbitItemType;
  onClose: () => void;
  getIconComponent: (iconName: string) => JSX.Element;
}

export function OrbitItemViewer({ item, onClose, getIconComponent }: OrbitItemViewerProps) {
  const formattedDate = formatDate(item.createdAt);
  
  const getTypeLabel = (type: string) => {
    switch (type) {
      case "note":
        return "Note";
      case "dream":
        return "Dream";
      case "mood":
        return "Mood";
      case "quote":
        return "Quote";
      default:
        return "Item";
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div 
        className="bg-gradient-to-b from-indigo-950 to-purple-950 rounded-2xl w-full max-w-md mx-4 overflow-hidden shadow-xl border border-indigo-500/30"
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        transition={{ duration: 0.3 }}
      >
        <div className="p-4 border-b border-indigo-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: item.color }}>
              <div className="w-4 h-4 text-white">
                {getIconComponent(item.icon)}
              </div>
            </div>
            <h2 className="text-xl font-semibold text-indigo-100">{getTypeLabel(item.type)}</h2>
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full text-indigo-300 hover:text-indigo-100 hover:bg-indigo-800/50"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="p-6 space-y-6">
          <div className="flex items-center gap-2 text-indigo-400">
            <Calendar className="h-4 w-4" />
            <span className="text-sm">{formattedDate}</span>
          </div>
          
          <div className="bg-indigo-900/30 rounded-xl p-5 border border-indigo-500/20">
            <p className="text-indigo-100 text-lg leading-relaxed">{item.content}</p>
          </div>
          
          <div className="pt-4 flex justify-end">
            <Button 
              onClick={onClose}
              className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white rounded-full px-6"
            >
              Close
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
