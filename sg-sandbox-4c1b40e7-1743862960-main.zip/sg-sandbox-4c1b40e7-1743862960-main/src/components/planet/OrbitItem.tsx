
import { motion } from "framer-motion";

interface OrbitItemProps {
  item: {
    id: string;
    type: "note" | "dream" | "mood" | "quote";
    content: string;
    icon: string;
    color: string;
    position: {
      angle: number;
      distance: number;
    };
  };
  onClick: () => void;
  getIconComponent: (iconName: string) => JSX.Element;
}

export function OrbitItem({ item, onClick, getIconComponent }: OrbitItemProps) {
  // Calculate position based on angle and distance
  const x = Math.cos(item.position.angle * (Math.PI / 180)) * item.position.distance;
  const y = Math.sin(item.position.angle * (Math.PI / 180)) * item.position.distance;
  
  return (
    <motion.div
      className="absolute cursor-pointer"
      style={{ 
        left: "50%",
        top: "50%",
        marginLeft: `${x}px`,
        marginTop: `${y}px`,
      }}
      animate={{
        rotate: [0, 10, 0, -10, 0],
      }}
      transition={{
        duration: 5 + Math.random() * 3,
        repeat: Infinity,
        ease: "easeInOut"
      }}
      whileHover={{ scale: 1.2 }}
      onClick={onClick}
    >
      <motion.div 
        className="relative flex items-center justify-center w-12 h-12 rounded-full shadow-lg"
        style={{ 
          backgroundColor: item.color,
          boxShadow: `0 0 15px ${item.color}80`
        }}
        initial={{ scale: 0 }}
        animate={{ 
          scale: 1,
          boxShadow: [
            `0 0 10px ${item.color}80`,
            `0 0 20px ${item.color}80`,
            `0 0 10px ${item.color}80`
          ]
        }}
        transition={{
          scale: { duration: 0.5 },
          boxShadow: { 
            duration: 2,
            repeat: Infinity,
            repeatType: "reverse"
          }
        }}
      >
        <div className="w-6 h-6 text-white">
          {getIconComponent(item.icon)}
        </div>
        
        {/* Glow effect */}
        <div className="absolute -inset-1 rounded-full opacity-50" style={{ backgroundColor: item.color, filter: 'blur(8px)' }} />
      </motion.div>
    </motion.div>
  );
}
