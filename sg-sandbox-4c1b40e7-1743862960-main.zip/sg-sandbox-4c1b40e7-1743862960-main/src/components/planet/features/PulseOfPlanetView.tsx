import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Heart, Globe, TrendingUp, MessageCircle, Share } from "lucide-react";

interface PulseOfPlanetProps {
  onBack: () => void;
  onSave: (itemId: string) => void;
}

interface TrendPost {
  id: string;
  title: string;
  emoji: string;
  category: string;
  location: string;
  description: string;
  likes: number;
  comments: number;
  trending: boolean;
}

export function PulseOfPlanetView({ onBack, onSave }: PulseOfPlanetProps) {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const trendPosts: TrendPost[] = [
    {
      id: "tokyo-love",
      title: "Tokyo's Love Lock Bridge",
      emoji: "🔒",
      category: "Traditions",
      location: "Tokyo, Japan",
      description: "Couples in Tokyo are creating a new tradition of love locks on the Rainbow Bridge, symbolizing unbreakable bonds.",
      likes: 2847,
      comments: 156,
      trending: true
    },
    {
      id: "digital-dates",
      title: "Virtual Reality Dates Rising",
      emoji: "🥽",
      category: "Technology",
      location: "Global",
      description: "VR dating experiences are becoming the new normal, allowing couples to 'travel' together from anywhere in the world.",
      likes: 1923,
      comments: 89,
      trending: true
    },
    {
      id: "plant-parents",
      title: "Plant Parenting Together",
      emoji: "🌱",
      category: "Lifestyle",
      location: "Worldwide",
      description: "Couples are bonding over caring for plants together, with 'plant parent' dates becoming increasingly popular.",
      likes: 3156,
      comments: 234,
      trending: false
    },
    {
      id: "sunset-proposals",
      title: "Golden Hour Proposals",
      emoji: "💍",
      category: "Romance",
      location: "Santorini, Greece",
      description: "Santorini sees a 300% increase in sunset proposals this season, making it the world's most romantic proposal destination.",
      likes: 4521,
      comments: 312,
      trending: true
    },
    {
      id: "cooking-classes",
      title: "Couple Cooking Classes Boom",
      emoji: "👨‍🍳",
      category: "Activities",
      location: "Paris, France",
      description: "Parisian cooking schools report that couple classes are booked solid, with pasta-making being the most requested.",
      likes: 1876,
      comments: 98,
      trending: false
    },
    {
      id: "digital-detox",
      title: "Phone-Free Date Nights",
      emoji: "📵",
      category: "Wellness",
      location: "Global",
      description: "Restaurants worldwide are offering 'phone-free' dining experiences, with couples rediscovering face-to-face connection.",
      likes: 2634,
      comments: 187,
      trending: true
    }
  ];

  const categories = ["Traditions", "Technology", "Lifestyle", "Romance", "Activities", "Wellness"];

  const filteredPosts = trendPosts.filter(post => {
    if (selectedCategory && post.category !== selectedCategory) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 via-cyan-800 to-teal-900 relative overflow-hidden">
      <header className="relative z-10 w-full py-6 px-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold text-white">🌍 Pulse of the Planet</h1>
            <p className="text-white/70">Global love trends</p>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-full text-white/80 hover:text-white">
            <TrendingUp className="h-6 w-6" />
          </Button>
        </div>

        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category}
              onClick={() => setSelectedCategory(selectedCategory === category ? null : category)}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              className={`rounded-full whitespace-nowrap ${
                selectedCategory === category 
                  ? "bg-white text-blue-900" 
                  : "bg-white/10 text-white border-white/20 hover:bg-white/20"
              }`}
            >
              {category}
            </Button>
          ))}
        </div>
      </header>

      <div className="relative z-10 px-6 pb-20">
        <div className="grid gap-4 max-w-4xl mx-auto">
          {filteredPosts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{post.emoji}</span>
                      <div>
                        <div className="flex items-center gap-2">
                          <CardTitle className="text-white text-lg">{post.title}</CardTitle>
                          {post.trending && (
                            <Badge className="bg-red-500/20 text-red-300 text-xs">
                              🔥 Trending
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-4 mt-1 text-sm text-white/70">
                          <span>{post.location}</span>
                          <Badge variant="secondary" className="bg-blue-500/20 text-blue-300">
                            {post.category}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => onSave(post.id)}
                      variant="ghost"
                      size="icon"
                      className="text-white/70 hover:text-white"
                    >
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80 mb-4">{post.description}</p>
                  
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4 text-sm text-white/70">
                      <div className="flex items-center gap-1">
                        <Heart className="h-4 w-4" />
                        {post.likes.toLocaleString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <MessageCircle className="h-4 w-4" />
                        {post.comments}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white">
                      <Heart className="h-4 w-4 mr-2" />
                      Heart This
                    </Button>
                    <Button 
                      variant="outline" 
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      <Share className="h-4 w-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}