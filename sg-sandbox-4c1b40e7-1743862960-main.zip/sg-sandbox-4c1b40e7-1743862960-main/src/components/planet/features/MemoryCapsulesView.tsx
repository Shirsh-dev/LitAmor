import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Heart, Package, Lock, Calendar, Camera, Mic, Plus } from "lucide-react";

interface MemoryCapsulesProps {
  onBack: () => void;
  onSave: (itemId: string) => void;
}

interface MemoryCapsule {
  id: string;
  title: string;
  emoji: string;
  createdDate: string;
  unlockDate: string;
  isLocked: boolean;
  type: "text" | "photo" | "voice" | "mixed";
  preview: string;
  tags: string[];
}

export function MemoryCapsulesView({ onBack, onSave }: MemoryCapsulesProps) {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newCapsule, setNewCapsule] = useState({
    title: "",
    content: "",
    unlockDate: "",
    type: "text" as const
  });

  const memoryCapsules: MemoryCapsule[] = [
    {
      id: "capsule-1",
      title: "Our First Anniversary",
      emoji: "💕",
      createdDate: "June 1, 2024",
      unlockDate: "June 1, 2025",
      isLocked: true,
      type: "mixed",
      preview: "A collection of photos and voice notes from our first year together...",
      tags: ["anniversary", "milestone", "love"]
    },
    {
      id: "capsule-2",
      title: "Summer Road Trip Dreams",
      emoji: "🚗",
      createdDate: "March 15, 2024",
      unlockDate: "June 15, 2024",
      isLocked: false,
      type: "photo",
      preview: "All the places we want to visit this summer, with photos of our dream destinations.",
      tags: ["travel", "dreams", "adventure"]
    },
    {
      id: "capsule-3",
      title: "Love Letters to Future Us",
      emoji: "💌",
      createdDate: "February 14, 2024",
      unlockDate: "February 14, 2025",
      isLocked: true,
      type: "text",
      preview: "Heartfelt letters we wrote to ourselves one year in the future...",
      tags: ["letters", "future", "romantic"]
    },
    {
      id: "capsule-4",
      title: "Quarantine Memories",
      emoji: "🏠",
      createdDate: "January 1, 2024",
      unlockDate: "January 1, 2025",
      isLocked: true,
      type: "voice",
      preview: "Voice recordings of how we spent our time together during lockdown...",
      tags: ["memories", "together", "growth"]
    },
    {
      id: "capsule-5",
      title: "New Year Resolutions",
      emoji: "✨",
      createdDate: "December 31, 2023",
      unlockDate: "December 31, 2024",
      isLocked: false,
      type: "text",
      preview: "Our hopes and dreams for the year ahead, written with so much optimism...",
      tags: ["resolutions", "goals", "hope"]
    }
  ];

  const handleCreateCapsule = () => {
    if (newCapsule.title && newCapsule.content && newCapsule.unlockDate) {
      // Here you would typically submit to backend
      setNewCapsule({ title: "", content: "", unlockDate: "", type: "text" });
      setShowCreateForm(false);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "photo": return <Camera className="h-4 w-4" />;
      case "voice": return <Mic className="h-4 w-4" />;
      case "mixed": return <Package className="h-4 w-4" />;
      default: return <Package className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-900 via-rose-800 to-purple-900 relative overflow-hidden">
      <header className="relative z-10 w-full py-6 px-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold text-white">📦 Memory Capsules</h1>
            <p className="text-white/70">Save moments for the future</p>
          </div>
          
          <Button 
            onClick={() => setShowCreateForm(!showCreateForm)}
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white"
          >
            <Plus className="h-6 w-6" />
          </Button>
        </div>

        {/* Create New Capsule Form */}
        {showCreateForm && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Create New Memory Capsule</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Capsule title..."
                  value={newCapsule.title}
                  onChange={(e) => setNewCapsule({...newCapsule, title: e.target.value})}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                />
                <Textarea
                  placeholder="What memories do you want to preserve?"
                  value={newCapsule.content}
                  onChange={(e) => setNewCapsule({...newCapsule, content: e.target.value})}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                  rows={3}
                />
                <div className="flex gap-4">
                  <Input
                    type="date"
                    value={newCapsule.unlockDate}
                    onChange={(e) => setNewCapsule({...newCapsule, unlockDate: e.target.value})}
                    className="bg-white/10 border-white/20 text-white"
                  />
                  <Button 
                    onClick={handleCreateCapsule}
                    className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white"
                  >
                    <Lock className="h-4 w-4 mr-2" />
                    Lock Capsule
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </header>

      <div className="relative z-10 px-6 pb-20">
        <div className="grid gap-4 max-w-4xl mx-auto">
          {memoryCapsules.map((capsule, index) => (
            <motion.div
              key={capsule.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className={`border-white/20 backdrop-blur-sm ${
                capsule.isLocked 
                  ? 'bg-white/5 border-yellow-500/30' 
                  : 'bg-white/10'
              }`}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{capsule.emoji}</span>
                      <div>
                        <div className="flex items-center gap-2">
                          <CardTitle className="text-white text-lg">{capsule.title}</CardTitle>
                          {capsule.isLocked && (
                            <Lock className="h-4 w-4 text-yellow-400" />
                          )}
                        </div>
                        <div className="flex items-center gap-4 mt-1 text-sm text-white/70">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            Created: {capsule.createdDate}
                          </div>
                          <div className="flex items-center gap-1">
                            {getTypeIcon(capsule.type)}
                            {capsule.type}
                          </div>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => onSave(capsule.id)}
                      variant="ghost"
                      size="icon"
                      className="text-white/70 hover:text-white"
                    >
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80 mb-4">{capsule.preview}</p>
                  
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex flex-wrap gap-2">
                      {capsule.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="bg-white/20 text-white">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <Badge 
                      variant="outline" 
                      className={`border-white/20 ${
                        capsule.isLocked ? 'text-yellow-300' : 'text-green-300'
                      }`}
                    >
                      {capsule.isLocked ? `Unlocks: ${capsule.unlockDate}` : 'Unlocked'}
                    </Badge>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      disabled={capsule.isLocked}
                      className={`flex-1 ${
                        capsule.isLocked 
                          ? 'bg-gray-500/50 cursor-not-allowed' 
                          : 'bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600'
                      } text-white`}
                    >
                      <Package className="h-4 w-4 mr-2" />
                      {capsule.isLocked ? 'Locked' : 'Open Capsule'}
                    </Button>
                    <Button 
                      variant="outline" 
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      Share
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}