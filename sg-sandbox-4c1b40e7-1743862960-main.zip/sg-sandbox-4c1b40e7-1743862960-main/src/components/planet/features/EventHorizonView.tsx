import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Heart, Calendar, Clock, MapPin, Users, Bell } from "lucide-react";

interface EventHorizonProps {
  onBack: () => void;
  onSave: (itemId: string) => void;
}

interface Event {
  id: string;
  title: string;
  emoji: string;
  type: string;
  date: string;
  time: string;
  location: string;
  description: string;
  attendees: number;
  maxAttendees: number;
  tags: string[];
  isVirtual: boolean;
}

export function EventHorizonView({ onBack, onSave }: EventHorizonProps) {
  const [selectedType, setSelectedType] = useState<string | null>(null);

  const events: Event[] = [
    {
      id: "speed-dating",
      title: "Virtual Speed Dating Night",
      emoji: "💕",
      type: "Dating",
      date: "June 15",
      time: "7:00 PM",
      location: "Online",
      description: "Meet new people in a fun, low-pressure environment. 5-minute conversations with potential matches.",
      attendees: 24,
      maxAttendees: 30,
      tags: ["virtual", "singles", "fun"],
      isVirtual: true
    },
    {
      id: "cooking-class",
      title: "Couples Cooking Workshop",
      emoji: "👨‍🍳",
      type: "Workshop",
      date: "June 18",
      time: "6:30 PM",
      location: "Downtown Culinary Center",
      description: "Learn to make pasta from scratch with your partner. All ingredients and wine included!",
      attendees: 8,
      maxAttendees: 12,
      tags: ["couples", "hands-on", "food"],
      isVirtual: false
    },
    {
      id: "meditation",
      title: "Mindful Dating Meditation",
      emoji: "🧘‍♀️",
      type: "Wellness",
      date: "June 20",
      time: "11:00 AM",
      location: "Zen Garden Park",
      description: "A guided meditation session focused on self-love and opening your heart to new connections.",
      attendees: 15,
      maxAttendees: 20,
      tags: ["mindfulness", "self-care", "outdoor"],
      isVirtual: false
    },
    {
      id: "game-night",
      title: "Board Game Mixer",
      emoji: "🎲",
      type: "Social",
      date: "June 22",
      time: "7:30 PM",
      location: "The Game Lounge",
      description: "Meet fellow game enthusiasts while playing modern board games. Perfect for breaking the ice!",
      attendees: 18,
      maxAttendees: 24,
      tags: ["games", "social", "casual"],
      isVirtual: false
    },
    {
      id: "art-walk",
      title: "Gallery Walk & Wine",
      emoji: "🎨",
      type: "Cultural",
      date: "June 25",
      time: "6:00 PM",
      location: "Arts District",
      description: "Explore local galleries with other art lovers, followed by wine and conversation at a cozy bistro.",
      attendees: 12,
      maxAttendees: 16,
      tags: ["art", "culture", "wine"],
      isVirtual: false
    },
    {
      id: "book-club",
      title: "Love Stories Book Discussion",
      emoji: "📚",
      type: "Literary",
      date: "June 28",
      time: "2:00 PM",
      location: "Online",
      description: "Discuss this month's romance novel and share your thoughts on love and relationships.",
      attendees: 9,
      maxAttendees: 15,
      tags: ["books", "discussion", "virtual"],
      isVirtual: true
    }
  ];

  const eventTypes = ["Dating", "Workshop", "Wellness", "Social", "Cultural", "Literary"];

  const filteredEvents = events.filter(event => {
    if (selectedType && event.type !== selectedType) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-900 via-yellow-800 to-orange-900 relative overflow-hidden">
      <header className="relative z-10 w-full py-6 px-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold text-white">📆 Event Horizon</h1>
            <p className="text-white/70">Virtual & local events</p>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-full text-white/80 hover:text-white">
            <Bell className="h-6 w-6" />
          </Button>
        </div>

        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {eventTypes.map((type) => (
            <Button
              key={type}
              onClick={() => setSelectedType(selectedType === type ? null : type)}
              variant={selectedType === type ? "default" : "outline"}
              size="sm"
              className={`rounded-full whitespace-nowrap ${
                selectedType === type 
                  ? "bg-white text-amber-900" 
                  : "bg-white/10 text-white border-white/20 hover:bg-white/20"
              }`}
            >
              {type}
            </Button>
          ))}
        </div>
      </header>

      <div className="relative z-10 px-6 pb-20">
        <div className="grid gap-4 max-w-4xl mx-auto">
          {filteredEvents.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{event.emoji}</span>
                      <div>
                        <CardTitle className="text-white text-lg">{event.title}</CardTitle>
                        <div className="flex items-center gap-4 mt-1 text-sm text-white/70">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {event.date}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {event.time}
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            {event.location}
                          </div>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => onSave(event.id)}
                      variant="ghost"
                      size="icon"
                      className="text-white/70 hover:text-white"
                    >
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80 mb-4">{event.description}</p>
                  
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2 text-sm text-white/70">
                      <Users className="h-4 w-4" />
                      <span>{event.attendees}/{event.maxAttendees} attending</span>
                    </div>
                    <Badge 
                      variant="secondary" 
                      className={`${event.isVirtual ? 'bg-blue-500/20 text-blue-300' : 'bg-green-500/20 text-green-300'}`}
                    >
                      {event.isVirtual ? 'Virtual' : 'In-Person'}
                    </Badge>
                  </div>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {event.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="bg-white/20 text-white">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-white">
                      <Calendar className="h-4 w-4 mr-2" />
                      RSVP
                    </Button>
                    <Button 
                      variant="outline" 
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      <Bell className="h-4 w-4 mr-2" />
                      Remind Me
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}