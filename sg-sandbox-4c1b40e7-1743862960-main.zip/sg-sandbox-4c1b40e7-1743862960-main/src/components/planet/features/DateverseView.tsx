import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Heart, Filter, Calendar, Clock, DollarSign, MapPin } from "lucide-react";

interface DateIdeaProps {
  onBack: () => void;
  onSave: (itemId: string) => void;
}

interface DateIdea {
  id: string;
  title: string;
  emoji: string;
  mood: string;
  budget: string;
  duration: string;
  location: string;
  description: string;
  tags: string[];
}

export function DateverseView({ onBack, onSave }: DateIdeaProps) {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [selectedBudget, setSelectedBudget] = useState<string | null>(null);

  const dateIdeas: DateIdea[] = [
    {
      id: "stargazing",
      title: "Stargazing Picnic",
      emoji: "🌟",
      mood: "Romantic",
      budget: "Low",
      duration: "3-4 hours",
      location: "Outdoor",
      description: "Pack a cozy blanket, some snacks, and find a quiet spot away from city lights to watch the stars together.",
      tags: ["romantic", "peaceful", "outdoor"]
    },
    {
      id: "cooking",
      title: "Cook Together",
      emoji: "👨‍🍳",
      mood: "Playful",
      budget: "Medium",
      duration: "2-3 hours",
      location: "Home",
      description: "Pick a new recipe, shop for ingredients together, and create a delicious meal while laughing and bonding.",
      tags: ["creative", "intimate", "fun"]
    },
    {
      id: "museum",
      title: "Art Museum Adventure",
      emoji: "🎨",
      mood: "Cultural",
      budget: "Medium",
      duration: "2-4 hours",
      location: "Indoor",
      description: "Explore local art galleries or museums, discuss your favorite pieces, and grab coffee afterward.",
      tags: ["cultural", "intellectual", "inspiring"]
    },
    {
      id: "hiking",
      title: "Sunrise Hike",
      emoji: "🥾",
      mood: "Adventurous",
      budget: "Low",
      duration: "4-5 hours",
      location: "Outdoor",
      description: "Wake up early to catch a beautiful sunrise from a scenic hiking trail, followed by a hearty breakfast.",
      tags: ["active", "nature", "energizing"]
    },
    {
      id: "bookstore",
      title: "Bookstore Date",
      emoji: "📚",
      mood: "Cozy",
      budget: "Low",
      duration: "2-3 hours",
      location: "Indoor",
      description: "Browse books together, read to each other, and discover new stories over coffee in a cozy bookstore cafe.",
      tags: ["intellectual", "cozy", "relaxed"]
    },
    {
      id: "dancing",
      title: "Dance Class",
      emoji: "💃",
      mood: "Energetic",
      budget: "Medium",
      duration: "1-2 hours",
      location: "Indoor",
      description: "Take a beginner's dance class together - salsa, swing, or ballroom. Laugh at your mistakes and celebrate your moves!",
      tags: ["active", "fun", "learning"]
    }
  ];

  const moods = ["Romantic", "Playful", "Cultural", "Adventurous", "Cozy", "Energetic"];
  const budgets = ["Low", "Medium", "High"];

  const filteredIdeas = dateIdeas.filter(idea => {
    if (selectedMood && idea.mood !== selectedMood) return false;
    if (selectedBudget && idea.budget !== selectedBudget) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-pink-800 to-rose-900 relative overflow-hidden">
      {/* Header */}
      <header className="relative z-10 w-full py-6 px-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold text-white">🌌 Dateverse</h1>
            <p className="text-white/70">Infinite date possibilities</p>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-full text-white/80 hover:text-white">
            <Filter className="h-6 w-6" />
          </Button>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap gap-2 mb-4">
          <div className="flex gap-2 overflow-x-auto pb-2">
            {moods.map((mood) => (
              <Button
                key={mood}
                onClick={() => setSelectedMood(selectedMood === mood ? null : mood)}
                variant={selectedMood === mood ? "default" : "outline"}
                size="sm"
                className={`rounded-full whitespace-nowrap ${
                  selectedMood === mood 
                    ? "bg-white text-purple-900" 
                    : "bg-white/10 text-white border-white/20 hover:bg-white/20"
                }`}
              >
                {mood}
              </Button>
            ))}
          </div>
        </div>

        <div className="flex gap-2 mb-6">
          {budgets.map((budget) => (
            <Button
              key={budget}
              onClick={() => setSelectedBudget(selectedBudget === budget ? null : budget)}
              variant={selectedBudget === budget ? "default" : "outline"}
              size="sm"
              className={`rounded-full ${
                selectedBudget === budget 
                  ? "bg-white text-purple-900" 
                  : "bg-white/10 text-white border-white/20 hover:bg-white/20"
              }`}
            >
              <DollarSign className="h-4 w-4 mr-1" />
              {budget}
            </Button>
          ))}
        </div>
      </header>

      {/* Date Ideas Grid */}
      <div className="relative z-10 px-6 pb-20">
        <div className="grid gap-4 max-w-4xl mx-auto">
          {filteredIdeas.map((idea, index) => (
            <motion.div
              key={idea.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{idea.emoji}</span>
                      <div>
                        <CardTitle className="text-white text-lg">{idea.title}</CardTitle>
                        <div className="flex items-center gap-4 mt-1 text-sm text-white/70">
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {idea.duration}
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            {idea.location}
                          </div>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => onSave(idea.id)}
                      variant="ghost"
                      size="icon"
                      className="text-white/70 hover:text-white"
                    >
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80 mb-4">{idea.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {idea.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="bg-white/20 text-white">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white">
                      Try This Date
                    </Button>
                    <Button 
                      variant="outline" 
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      <Calendar className="h-4 w-4 mr-2" />
                      Schedule
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}