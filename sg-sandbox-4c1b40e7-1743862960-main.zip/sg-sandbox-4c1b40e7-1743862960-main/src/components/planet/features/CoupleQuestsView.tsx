import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Heart, Target, Trophy, Clock, Users } from "lucide-react";

interface CoupleQuestsProps {
  onBack: () => void;
  onSave: (itemId: string) => void;
}

interface Quest {
  id: string;
  title: string;
  emoji: string;
  difficulty: string;
  duration: string;
  points: number;
  description: string;
  tags: string[];
  badge: string;
}

export function CoupleQuestsView({ onBack, onSave }: CoupleQuestsProps) {
  const [selectedDifficulty, setSelectedDifficulty] = useState<string | null>(null);

  const quests: Quest[] = [
    {
      id: "photo-challenge",
      title: "Photo Adventure Quest",
      emoji: "📸",
      difficulty: "Easy",
      duration: "2-3 hours",
      points: 50,
      description: "Take photos recreating your first date, then create a before-and-after collage to see how you've grown together.",
      tags: ["creative", "nostalgic", "fun"],
      badge: "Memory Keeper"
    },
    {
      id: "cooking-challenge",
      title: "Mystery Recipe Challenge",
      emoji: "👨‍🍳",
      difficulty: "Medium",
      duration: "1-2 hours",
      points: 75,
      description: "Each person picks 3 random ingredients. Work together to create a delicious meal using all 6 ingredients!",
      tags: ["teamwork", "creative", "tasty"],
      badge: "Kitchen Champions"
    },
    {
      id: "love-letters",
      title: "Future Love Letters",
      emoji: "💌",
      difficulty: "Easy",
      duration: "30 minutes",
      points: 40,
      description: "Write love letters to each other to be opened on your next anniversary. Seal them and hide them somewhere special.",
      tags: ["romantic", "meaningful", "future"],
      badge: "Time Travelers"
    },
    {
      id: "bucket-list",
      title: "Dream Together Quest",
      emoji: "🌟",
      difficulty: "Medium",
      duration: "1 hour",
      points: 60,
      description: "Create a shared bucket list of 20 things you want to do together. Pick one to plan for this month!",
      tags: ["planning", "dreams", "goals"],
      badge: "Dream Weavers"
    },
    {
      id: "dance-off",
      title: "Living Room Dance Battle",
      emoji: "💃",
      difficulty: "Easy",
      duration: "45 minutes",
      points: 45,
      description: "Create playlists for each other and have a dance-off in your living room. Bonus points for silly moves!",
      tags: ["active", "silly", "music"],
      badge: "Dance Floor Legends"
    },
    {
      id: "scavenger-hunt",
      title: "Love Scavenger Hunt",
      emoji: "🔍",
      difficulty: "Hard",
      duration: "3-4 hours",
      points: 100,
      description: "Create clues leading to places that are meaningful in your relationship. End with a special surprise!",
      tags: ["adventure", "meaningful", "surprise"],
      badge: "Love Detectives"
    }
  ];

  const difficulties = ["Easy", "Medium", "Hard"];

  const filteredQuests = quests.filter(quest => {
    if (selectedDifficulty && quest.difficulty !== selectedDifficulty) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-900 via-red-800 to-pink-900 relative overflow-hidden">
      <header className="relative z-10 w-full py-6 px-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold text-white">🎯 Couple Quests</h1>
            <p className="text-white/70">Fun bonding missions</p>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-full text-white/80 hover:text-white">
            <Trophy className="h-6 w-6" />
          </Button>
        </div>

        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {difficulties.map((difficulty) => (
            <Button
              key={difficulty}
              onClick={() => setSelectedDifficulty(selectedDifficulty === difficulty ? null : difficulty)}
              variant={selectedDifficulty === difficulty ? "default" : "outline"}
              size="sm"
              className={`rounded-full whitespace-nowrap ${
                selectedDifficulty === difficulty 
                  ? "bg-white text-orange-900" 
                  : "bg-white/10 text-white border-white/20 hover:bg-white/20"
              }`}
            >
              {difficulty}
            </Button>
          ))}
        </div>
      </header>

      <div className="relative z-10 px-6 pb-20">
        <div className="grid gap-4 max-w-4xl mx-auto">
          {filteredQuests.map((quest, index) => (
            <motion.div
              key={quest.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{quest.emoji}</span>
                      <div>
                        <CardTitle className="text-white text-lg">{quest.title}</CardTitle>
                        <div className="flex items-center gap-4 mt-1 text-sm text-white/70">
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {quest.duration}
                          </div>
                          <div className="flex items-center gap-1">
                            <Trophy className="h-4 w-4" />
                            {quest.points} pts
                          </div>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => onSave(quest.id)}
                      variant="ghost"
                      size="icon"
                      className="text-white/70 hover:text-white"
                    >
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80 mb-4">{quest.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {quest.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="bg-white/20 text-white">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between mb-4">
                    <Badge className="bg-yellow-500/20 text-yellow-300">
                      🏆 {quest.badge}
                    </Badge>
                    <Badge variant="outline" className="border-white/20 text-white">
                      {quest.difficulty}
                    </Badge>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white">
                      <Target className="h-4 w-4 mr-2" />
                      Start Quest
                    </Button>
                    <Button 
                      variant="outline" 
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      <Users className="h-4 w-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}