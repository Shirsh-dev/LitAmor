import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Heart, Theater, Smile, Frown, Meh, Zap } from "lucide-react";

interface MoodTrailsProps {
  onBack: () => void;
  onSave: (itemId: string) => void;
}

interface MoodActivity {
  id: string;
  title: string;
  emoji: string;
  mood: string;
  type: string;
  description: string;
  tags: string[];
}

export function MoodTrailsView({ onBack, onSave }: MoodTrailsProps) {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);

  const moodActivities: MoodActivity[] = [
    {
      id: "calm-meditation",
      title: "Sunset Meditation",
      emoji: "🧘‍♀️",
      mood: "Calm",
      type: "Mindfulness",
      description: "A guided 10-minute meditation to center yourself and find inner peace.",
      tags: ["peaceful", "grounding", "solo"]
    },
    {
      id: "spicy-salsa",
      title: "Spicy Salsa Night",
      emoji: "💃",
      mood: "Spicy",
      type: "Activity",
      description: "Turn up the heat with passionate Latin dancing and fiery music.",
      tags: ["passionate", "energetic", "couple"]
    },
    {
      id: "healing-bath",
      title: "Healing Bath Ritual",
      emoji: "🛁",
      mood: "Healing",
      type: "Self-Care",
      description: "Create a spa experience at home with essential oils, candles, and soothing music.",
      tags: ["nurturing", "relaxing", "solo"]
    },
    {
      id: "fun-karaoke",
      title: "Living Room Karaoke",
      emoji: "🎤",
      mood: "Fun",
      type: "Entertainment",
      description: "Belt out your favorite songs and have a laugh with silly performances.",
      tags: ["joyful", "silly", "couple"]
    },
    {
      id: "calm-nature",
      title: "Forest Bathing",
      emoji: "🌲",
      mood: "Calm",
      type: "Nature",
      description: "Immerse yourself mindfully in nature, focusing on all your senses.",
      tags: ["peaceful", "nature", "grounding"]
    },
    {
      id: "spicy-cooking",
      title: "Aphrodisiac Cooking",
      emoji: "🌶️",
      mood: "Spicy",
      type: "Culinary",
      description: "Cook a sensual meal together using ingredients known for their romantic properties.",
      tags: ["romantic", "culinary", "couple"]
    },
    {
      id: "healing-journal",
      title: "Emotional Release Writing",
      emoji: "📝",
      mood: "Healing",
      type: "Reflection",
      description: "Write freely about your feelings without judgment, then safely release or keep your words.",
      tags: ["therapeutic", "introspective", "solo"]
    },
    {
      id: "fun-adventure",
      title: "Spontaneous Mini Adventure",
      emoji: "🗺️",
      mood: "Fun",
      type: "Adventure",
      description: "Pick a random direction and explore somewhere new within 30 minutes of home.",
      tags: ["spontaneous", "exploration", "adventure"]
    }
  ];

  const moods = [
    { name: "Calm", icon: <Smile className="h-4 w-4" />, color: "blue" },
    { name: "Spicy", icon: <Zap className="h-4 w-4" />, color: "red" },
    { name: "Healing", icon: <Heart className="h-4 w-4" />, color: "green" },
    { name: "Fun", icon: <Smile className="h-4 w-4" />, color: "yellow" }
  ];

  const filteredActivities = moodActivities.filter(activity => {
    if (selectedMood && activity.mood !== selectedMood) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-violet-900 via-purple-800 to-indigo-900 relative overflow-hidden">
      <header className="relative z-10 w-full py-6 px-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold text-white">🎭 Mood Trails</h1>
            <p className="text-white/70">Emotion-based activity guides</p>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-full text-white/80 hover:text-white">
            <Theater className="h-6 w-6" />
          </Button>
        </div>

        <div className="text-center mb-6">
          <p className="text-white/80 mb-4">How are you feeling right now?</p>
          <div className="flex gap-3 justify-center flex-wrap">
            {moods.map((mood) => (
              <Button
                key={mood.name}
                onClick={() => setSelectedMood(selectedMood === mood.name ? null : mood.name)}
                variant={selectedMood === mood.name ? "default" : "outline"}
                size="sm"
                className={`rounded-full ${
                  selectedMood === mood.name 
                    ? "bg-white text-violet-900" 
                    : "bg-white/10 text-white border-white/20 hover:bg-white/20"
                }`}
              >
                {mood.icon}
                <span className="ml-2">{mood.name}</span>
              </Button>
            ))}
          </div>
        </div>
      </header>

      <div className="relative z-10 px-6 pb-20">
        <div className="grid gap-4 max-w-4xl mx-auto">
          {filteredActivities.map((activity, index) => (
            <motion.div
              key={activity.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{activity.emoji}</span>
                      <div>
                        <CardTitle className="text-white text-lg">{activity.title}</CardTitle>
                        <div className="flex items-center gap-4 mt-1 text-sm text-white/70">
                          <Badge variant="secondary" className={`bg-${activity.mood.toLowerCase()}-500/20 text-${activity.mood.toLowerCase()}-300`}>
                            {activity.mood}
                          </Badge>
                          <span>{activity.type}</span>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => onSave(activity.id)}
                      variant="ghost"
                      size="icon"
                      className="text-white/70 hover:text-white"
                    >
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80 mb-4">{activity.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {activity.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="bg-white/20 text-white">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-gradient-to-r from-violet-500 to-purple-500 hover:from-violet-600 hover:to-purple-600 text-white">
                      <Theater className="h-4 w-4 mr-2" />
                      Follow This Trail
                    </Button>
                    <Button 
                      variant="outline" 
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      Save for Later
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
