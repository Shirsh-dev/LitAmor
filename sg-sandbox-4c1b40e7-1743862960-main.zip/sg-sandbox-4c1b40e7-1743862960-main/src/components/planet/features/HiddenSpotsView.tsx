import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Heart, MapPin, Star, Navigation, Camera } from "lucide-react";

interface HiddenSpotsProps {
  onBack: () => void;
  onSave: (itemId: string) => void;
}

interface HiddenSpot {
  id: string;
  name: string;
  emoji: string;
  category: string;
  distance: string;
  rating: number;
  description: string;
  tags: string[];
  image: string;
}

export function HiddenSpotsView({ onBack, onSave }: HiddenSpotsProps) {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const hiddenSpots: HiddenSpot[] = [
    {
      id: "secret-garden",
      name: "Secret Garden Cafe",
      emoji: "🌸",
      category: "Food",
      distance: "0.8 miles",
      rating: 4.8,
      description: "A hidden courtyard cafe with fairy lights, blooming flowers, and the most amazing lavender lattes.",
      tags: ["romantic", "quiet", "instagram-worthy"],
      image: "https://images.unsplash.com/photo-1554118811-1e0d58224f24"
    },
    {
      id: "rooftop-view",
      name: "Sunset Rooftop",
      emoji: "🌅",
      category: "Nature",
      distance: "1.2 miles",
      rating: 4.9,
      description: "An unmarked rooftop with panoramic city views. Perfect for watching sunsets and deep conversations.",
      tags: ["scenic", "peaceful", "sunset"],
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4"
    },
    {
      id: "art-alley",
      name: "Graffiti Alley",
      emoji: "🎨",
      category: "Arts",
      distance: "0.5 miles",
      rating: 4.6,
      description: "A vibrant alley filled with ever-changing street art. Local artists often work here in the evenings.",
      tags: ["artistic", "colorful", "unique"],
      image: "https://images.unsplash.com/photo-1541961017774-22349e4a1262"
    },
    {
      id: "bookstore-cat",
      name: "The Cat & Book",
      emoji: "📚",
      category: "Arts",
      distance: "0.3 miles",
      rating: 4.7,
      description: "A tiny bookstore with resident cats, cozy reading nooks, and the best hot chocolate in town.",
      tags: ["cozy", "quiet", "cats"],
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d"
    },
    {
      id: "hidden-trail",
      name: "Whispering Woods",
      emoji: "🌲",
      category: "Nature",
      distance: "2.1 miles",
      rating: 4.5,
      description: "A lesser-known trail that leads to a small waterfall. Bring a picnic and enjoy nature's soundtrack.",
      tags: ["hiking", "waterfall", "peaceful"],
      image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e"
    },
    {
      id: "vintage-arcade",
      name: "Retro Game Den",
      emoji: "🕹️",
      category: "Fun",
      distance: "0.7 miles",
      rating: 4.4,
      description: "A basement arcade with vintage games, neon lights, and craft sodas. Compete in classic games!",
      tags: ["retro", "games", "fun"],
      image: "https://images.unsplash.com/photo-1511512578047-dfb367046420"
    }
  ];

  const categories = ["Nature", "Food", "Arts", "Fun"];

  const filteredSpots = hiddenSpots.filter(spot => {
    if (selectedCategory && spot.category !== selectedCategory) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-900 via-teal-800 to-cyan-900 relative overflow-hidden">
      {/* Header */}
      <header className="relative z-10 w-full py-6 px-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold text-white">🗺️ Hidden Spots</h1>
            <p className="text-white/70">Discover secret places nearby</p>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-full text-white/80 hover:text-white">
            <Navigation className="h-6 w-6" />
          </Button>
        </div>

        {/* Category Filter */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category}
              onClick={() => setSelectedCategory(selectedCategory === category ? null : category)}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              className={`rounded-full whitespace-nowrap ${
                selectedCategory === category 
                  ? "bg-white text-emerald-900" 
                  : "bg-white/10 text-white border-white/20 hover:bg-white/20"
              }`}
            >
              {category}
            </Button>
          ))}
        </div>
      </header>

      {/* Hidden Spots Grid */}
      <div className="relative z-10 px-6 pb-20">
        <div className="grid gap-4 max-w-4xl mx-auto">
          {filteredSpots.map((spot, index) => (
            <motion.div
              key={spot.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm overflow-hidden">
                <div className="relative h-48">
                  <img 
                    src={spot.image} 
                    alt={spot.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4">
                    <Button
                      onClick={() => onSave(spot.id)}
                      variant="ghost"
                      size="icon"
                      className="bg-black/20 backdrop-blur-sm text-white hover:bg-black/40"
                    >
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <Badge className="bg-black/40 text-white">
                      {spot.category}
                    </Badge>
                  </div>
                </div>
                
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{spot.emoji}</span>
                      <div>
                        <CardTitle className="text-white text-lg">{spot.name}</CardTitle>
                        <div className="flex items-center gap-4 mt-1 text-sm text-white/70">
                          <div className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            {spot.distance}
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            {spot.rating}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <p className="text-white/80 mb-4">{spot.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {spot.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="bg-white/20 text-white">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white">
                      <Navigation className="h-4 w-4 mr-2" />
                      Get Directions
                    </Button>
                    <Button 
                      variant="outline" 
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      <Camera className="h-4 w-4 mr-2" />
                      Visit
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}