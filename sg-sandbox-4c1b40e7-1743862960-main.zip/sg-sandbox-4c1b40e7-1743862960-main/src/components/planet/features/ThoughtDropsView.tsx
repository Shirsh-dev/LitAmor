import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Heart, MessageCircle, Share, Plus, Flame, Smile, Frown } from "lucide-react";

interface ThoughtDropsProps {
  onBack: () => void;
  onSave: (itemId: string) => void;
}

interface ThoughtDrop {
  id: string;
  content: string;
  emoji: string;
  author: string;
  isAnonymous: boolean;
  timestamp: string;
  reactions: {
    heart: number;
    fire: number;
    smile: number;
    sad: number;
  };
  replies: number;
  tags: string[];
}

export function ThoughtDropsView({ onBack, onSave }: ThoughtDropsProps) {
  const [newThought, setNewThought] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(false);

  const thoughtDrops: ThoughtDrop[] = [
    {
      id: "thought-1",
      content: "Sometimes I wonder if the person I'm meant to be with is also looking at the same stars tonight, thinking about finding love...",
      emoji: "⭐",
      author: "StarGazer",
      isAnonymous: true,
      timestamp: "2 hours ago",
      reactions: { heart: 24, fire: 3, smile: 8, sad: 2 },
      replies: 5,
      tags: ["romantic", "wondering"]
    },
    {
      id: "thought-2",
      content: "Had the most amazing first date today. We talked for 4 hours and it felt like 10 minutes. When you know, you know! ✨",
      emoji: "💫",
      author: "HappyHeart",
      isAnonymous: false,
      timestamp: "4 hours ago",
      reactions: { heart: 67, fire: 12, smile: 23, sad: 0 },
      replies: 12,
      tags: ["first-date", "happiness"]
    },
    {
      id: "thought-3",
      content: "Learning to love myself has been the hardest but most rewarding journey. Today I took myself on a solo museum date and felt so content.",
      emoji: "🌱",
      author: "SelfLoveJourney",
      isAnonymous: false,
      timestamp: "6 hours ago",
      reactions: { heart: 45, fire: 8, smile: 19, sad: 3 },
      replies: 8,
      tags: ["self-love", "growth"]
    },
    {
      id: "thought-4",
      content: "Missing the way they used to leave little notes in my coffee mug. It's the small gestures that stay with you the longest.",
      emoji: "☕",
      author: "Anonymous",
      isAnonymous: true,
      timestamp: "8 hours ago",
      reactions: { heart: 31, fire: 2, smile: 5, sad: 18 },
      replies: 7,
      tags: ["memories", "missing"]
    },
    {
      id: "thought-5",
      content: "Realized today that I've been so focused on finding 'the one' that I forgot to enjoy being 'the one' for myself first.",
      emoji: "🪞",
      author: "ReflectiveSoul",
      isAnonymous: false,
      timestamp: "12 hours ago",
      reactions: { heart: 89, fire: 15, smile: 34, sad: 4 },
      replies: 23,
      tags: ["self-reflection", "wisdom"]
    }
  ];

  const handleSubmitThought = () => {
    if (newThought.trim()) {
      // Here you would typically submit to backend
      setNewThought("");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-900 via-blue-800 to-indigo-900 relative overflow-hidden">
      <header className="relative z-10 w-full py-6 px-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold text-white">💭 Thought Drops</h1>
            <p className="text-white/70">Share your heart anonymously</p>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-full text-white/80 hover:text-white">
            <Plus className="h-6 w-6" />
          </Button>
        </div>

        {/* New Thought Input */}
        <Card className="bg-white/10 border-white/20 backdrop-blur-sm mb-6">
          <CardContent className="pt-6">
            <Textarea
              placeholder="What's on your heart today? Share your thoughts..."
              value={newThought}
              onChange={(e) => setNewThought(e.target.value)}
              className="bg-white/10 border-white/20 text-white placeholder:text-white/50 resize-none"
              rows={3}
            />
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="anonymous"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="rounded"
                />
                <label htmlFor="anonymous" className="text-white/80 text-sm">
                  Post anonymously
                </label>
              </div>
              <Button 
                onClick={handleSubmitThought}
                disabled={!newThought.trim()}
                className="bg-gradient-to-r from-sky-500 to-blue-500 hover:from-sky-600 hover:to-blue-600 text-white"
              >
                Drop Thought
              </Button>
            </div>
          </CardContent>
        </Card>
      </header>

      <div className="relative z-10 px-6 pb-20">
        <div className="grid gap-4 max-w-4xl mx-auto">
          {thoughtDrops.map((drop, index) => (
            <motion.div
              key={drop.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{drop.emoji}</span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-white/80 font-medium">
                            {drop.isAnonymous ? "Anonymous" : drop.author}
                          </span>
                          <span className="text-white/50 text-sm">{drop.timestamp}</span>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => onSave(drop.id)}
                      variant="ghost"
                      size="icon"
                      className="text-white/70 hover:text-white"
                    >
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/90 mb-4 leading-relaxed">{drop.content}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {drop.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="bg-white/20 text-white">
                        #{tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <Button variant="ghost" size="sm" className="text-white/70 hover:text-red-400">
                        <Heart className="h-4 w-4 mr-1" />
                        {drop.reactions.heart}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-white/70 hover:text-orange-400">
                        <Flame className="h-4 w-4 mr-1" />
                        {drop.reactions.fire}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-white/70 hover:text-yellow-400">
                        <Smile className="h-4 w-4 mr-1" />
                        {drop.reactions.smile}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-white/70 hover:text-blue-400">
                        <Frown className="h-4 w-4 mr-1" />
                        {drop.reactions.sad}
                      </Button>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="sm" className="text-white/70 hover:text-white">
                        <MessageCircle className="h-4 w-4 mr-1" />
                        {drop.replies}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-white/70 hover:text-white">
                        <Share className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}