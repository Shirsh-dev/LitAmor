import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Heart, Gift, DollarSign, ShoppingCart, Wrench } from "lucide-react";

interface GiftGalaxyProps {
  onBack: () => void;
  onSave: (itemId: string) => void;
}

interface GiftIdea {
  id: string;
  name: string;
  emoji: string;
  occasion: string;
  budget: string;
  type: "buy" | "diy";
  price: string;
  description: string;
  tags: string[];
}

export function GiftGalaxyView({ onBack, onSave }: GiftGalaxyProps) {
  const [selectedOccasion, setSelectedOccasion] = useState<string | null>(null);
  const [selectedBudget, setSelectedBudget] = useState<string | null>(null);

  const giftIdeas: GiftIdea[] = [
    {
      id: "memory-jar",
      name: "Memory Jar",
      emoji: "🫙",
      occasion: "Anniversary",
      budget: "Low",
      type: "diy",
      price: "$5-10",
      description: "Fill a beautiful jar with handwritten notes of your favorite memories together. Add new ones throughout the year.",
      tags: ["sentimental", "personal", "ongoing"]
    },
    {
      id: "star-map",
      name: "Custom Star Map",
      emoji: "⭐",
      occasion: "Anniversary",
      budget: "Medium",
      type: "buy",
      price: "$25-40",
      description: "A personalized map showing how the stars aligned on the night you first met or another special date.",
      tags: ["romantic", "personalized", "meaningful"]
    },
    {
      id: "playlist-vinyl",
      name: "Playlist on Vinyl",
      emoji: "🎵",
      occasion: "Just Because",
      budget: "Medium",
      type: "buy",
      price: "$30-50",
      description: "Create a custom vinyl record with songs that tell your love story or represent your relationship.",
      tags: ["music", "unique", "nostalgic"]
    },
    {
      id: "photo-book",
      name: "Adventure Photo Book",
      emoji: "📸",
      occasion: "Birthday",
      budget: "Medium",
      type: "diy",
      price: "$15-25",
      description: "Compile photos from your adventures together into a beautiful photo book with captions and memories.",
      tags: ["memories", "creative", "personal"]
    },
    {
      id: "plant-together",
      name: "Plant to Grow Together",
      emoji: "🌱",
      occasion: "Just Because",
      budget: "Low",
      type: "buy",
      price: "$10-20",
      description: "A beautiful plant you can nurture together, symbolizing your growing relationship.",
      tags: ["symbolic", "ongoing", "nature"]
    },
    {
      id: "experience-box",
      name: "Date Night Box",
      emoji: "📦",
      occasion: "Birthday",
      budget: "Medium",
      type: "diy",
      price: "$20-35",
      description: "Create a box filled with everything needed for the perfect date night at home - snacks, games, movies.",
      tags: ["experience", "thoughtful", "fun"]
    },
    {
      id: "jewelry",
      name: "Personalized Jewelry",
      emoji: "💎",
      occasion: "Anniversary",
      budget: "High",
      type: "buy",
      price: "$50-200",
      description: "A piece of jewelry engraved with coordinates of where you met, initials, or a special date.",
      tags: ["elegant", "lasting", "personalized"]
    },
    {
      id: "love-coupons",
      name: "Love Coupon Book",
      emoji: "🎟️",
      occasion: "Just Because",
      budget: "Low",
      type: "diy",
      price: "$2-5",
      description: "Handmade coupons for massages, favorite meals, movie nights, and other thoughtful gestures.",
      tags: ["playful", "ongoing", "thoughtful"]
    }
  ];

  const occasions = ["Anniversary", "Birthday", "Just Because"];
  const budgets = ["Low", "Medium", "High"];

  const filteredGifts = giftIdeas.filter(gift => {
    if (selectedOccasion && gift.occasion !== selectedOccasion) return false;
    if (selectedBudget && gift.budget !== selectedBudget) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-rose-900 via-pink-800 to-purple-900 relative overflow-hidden">
      {/* Header */}
      <header className="relative z-10 w-full py-6 px-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold text-white">🎁 Gift Galaxy</h1>
            <p className="text-white/70">Thoughtful gifts from the heart</p>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-full text-white/80 hover:text-white">
            <Gift className="h-6 w-6" />
          </Button>
        </div>

        {/* Filter Pills */}
        <div className="space-y-3 mb-6">
          <div className="flex gap-2 overflow-x-auto pb-2">
            {occasions.map((occasion) => (
              <Button
                key={occasion}
                onClick={() => setSelectedOccasion(selectedOccasion === occasion ? null : occasion)}
                variant={selectedOccasion === occasion ? "default" : "outline"}
                size="sm"
                className={`rounded-full whitespace-nowrap ${
                  selectedOccasion === occasion 
                    ? "bg-white text-rose-900" 
                    : "bg-white/10 text-white border-white/20 hover:bg-white/20"
                }`}
              >
                {occasion}
              </Button>
            ))}
          </div>
          
          <div className="flex gap-2">
            {budgets.map((budget) => (
              <Button
                key={budget}
                onClick={() => setSelectedBudget(selectedBudget === budget ? null : budget)}
                variant={selectedBudget === budget ? "default" : "outline"}
                size="sm"
                className={`rounded-full ${
                  selectedBudget === budget 
                    ? "bg-white text-rose-900" 
                    : "bg-white/10 text-white border-white/20 hover:bg-white/20"
                }`}
              >
                <DollarSign className="h-4 w-4 mr-1" />
                {budget}
              </Button>
            ))}
          </div>
        </div>
      </header>

      {/* Gift Ideas Grid */}
      <div className="relative z-10 px-6 pb-20">
        <div className="grid gap-4 max-w-4xl mx-auto">
          {filteredGifts.map((gift, index) => (
            <motion.div
              key={gift.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{gift.emoji}</span>
                      <div>
                        <CardTitle className="text-white text-lg">{gift.name}</CardTitle>
                        <div className="flex items-center gap-4 mt-1 text-sm text-white/70">
                          <span>{gift.price}</span>
                          <Badge 
                            variant="secondary" 
                            className={`${gift.type === 'diy' ? 'bg-green-500/20 text-green-300' : 'bg-blue-500/20 text-blue-300'}`}
                          >
                            {gift.type === 'diy' ? 'DIY' : 'Buy'}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => onSave(gift.id)}
                      variant="ghost"
                      size="icon"
                      className="text-white/70 hover:text-white"
                    >
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80 mb-4">{gift.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {gift.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="bg-white/20 text-white">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2">
                    {gift.type === 'buy' ? (
                      <Button className="flex-1 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white">
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Find & Order
                      </Button>
                    ) : (
                      <Button className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white">
                        <Wrench className="h-4 w-4 mr-2" />
                        DIY Guide
                      </Button>
                    )}
                    <Button 
                      variant="outline" 
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      Save Idea
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}