import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Heart, User, BookOpen, Coffee, Sparkles } from "lucide-react";

interface SoloSparksProps {
  onBack: () => void;
  onSave: (itemId: string) => void;
}

interface SelfCareActivity {
  id: string;
  title: string;
  emoji: string;
  category: string;
  duration: string;
  description: string;
  tags: string[];
  xpPoints: number;
}

export function SoloSparksView({ onBack, onSave }: SoloSparksProps) {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const activities: SelfCareActivity[] = [
    {
      id: "morning-ritual",
      title: "Sacred Morning Ritual",
      emoji: "🌅",
      category: "Mindfulness",
      duration: "30 minutes",
      description: "Create a morning routine that centers you: meditation, journaling, or simply enjoying coffee in silence.",
      tags: ["peaceful", "grounding", "routine"],
      xpPoints: 25
    },
    {
      id: "solo-date",
      title: "Perfect Solo Date",
      emoji: "☕",
      category: "Adventure",
      duration: "2-3 hours",
      description: "Take yourself on a date! Visit a museum, try a new cafe, or explore a neighborhood you've never been to.",
      tags: ["exploration", "independence", "fun"],
      xpPoints: 40
    },
    {
      id: "letter-to-self",
      title: "Letter to Future You",
      emoji: "💌",
      category: "Reflection",
      duration: "45 minutes",
      description: "Write a heartfelt letter to yourself one year from now. Share your dreams, fears, and current joys.",
      tags: ["introspective", "meaningful", "future"],
      xpPoints: 30
    },
    {
      id: "skill-spark",
      title: "Learn Something New",
      emoji: "🎨",
      category: "Growth",
      duration: "1-2 hours",
      description: "Pick up a new skill or hobby you've always wanted to try. YouTube tutorials count!",
      tags: ["learning", "creative", "achievement"],
      xpPoints: 35
    },
    {
      id: "gratitude-walk",
      title: "Gratitude Nature Walk",
      emoji: "🌿",
      category: "Mindfulness",
      duration: "45 minutes",
      description: "Take a mindful walk in nature, focusing on three things you're grateful for with each step.",
      tags: ["nature", "gratitude", "peaceful"],
      xpPoints: 20
    },
    {
      id: "comfort-zone",
      title: "Comfort Zone Challenge",
      emoji: "🚀",
      category: "Growth",
      duration: "Variable",
      description: "Do one small thing that scares you today. Call an old friend, try a new food, or speak up in a meeting.",
      tags: ["brave", "growth", "confidence"],
      xpPoints: 50
    },
    {
      id: "digital-detox",
      title: "Digital Sunset",
      emoji: "📱",
      category: "Wellness",
      duration: "Evening",
      description: "Put away all devices 2 hours before bed. Read, stretch, or just enjoy the quiet.",
      tags: ["wellness", "peaceful", "healthy"],
      xpPoints: 25
    },
    {
      id: "vision-board",
      title: "Dream Vision Board",
      emoji: "✨",
      category: "Reflection",
      duration: "1-2 hours",
      description: "Create a visual representation of your dreams and goals. Use magazines, photos, or digital tools.",
      tags: ["creative", "goals", "inspiring"],
      xpPoints: 40
    }
  ];

  const categories = ["Mindfulness", "Adventure", "Reflection", "Growth", "Wellness"];

  const filteredActivities = activities.filter(activity => {
    if (selectedCategory && activity.category !== selectedCategory) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-900 via-purple-800 to-pink-900 relative overflow-hidden">
      <header className="relative z-10 w-full py-6 px-6">
        <div className="flex items-center justify-between mb-6">
          <Button 
            onClick={onBack}
            variant="ghost" 
            size="icon" 
            className="rounded-full text-white/80 hover:text-white"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold text-white">🪞 Solo Sparks</h1>
            <p className="text-white/70">Self-discovery for singles</p>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-full text-white/80 hover:text-white">
            <Sparkles className="h-6 w-6" />
          </Button>
        </div>

        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category}
              onClick={() => setSelectedCategory(selectedCategory === category ? null : category)}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              className={`rounded-full whitespace-nowrap ${
                selectedCategory === category 
                  ? "bg-white text-indigo-900" 
                  : "bg-white/10 text-white border-white/20 hover:bg-white/20"
              }`}
            >
              {category}
            </Button>
          ))}
        </div>
      </header>

      <div className="relative z-10 px-6 pb-20">
        <div className="grid gap-4 max-w-4xl mx-auto">
          {filteredActivities.map((activity, index) => (
            <motion.div
              key={activity.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{activity.emoji}</span>
                      <div>
                        <CardTitle className="text-white text-lg">{activity.title}</CardTitle>
                        <div className="flex items-center gap-4 mt-1 text-sm text-white/70">
                          <span>{activity.duration}</span>
                          <Badge variant="secondary" className="bg-purple-500/20 text-purple-300">
                            +{activity.xpPoints} Solo XP
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => onSave(activity.id)}
                      variant="ghost"
                      size="icon"
                      className="text-white/70 hover:text-white"
                    >
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80 mb-4">{activity.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {activity.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="bg-white/20 text-white">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white">
                      <User className="h-4 w-4 mr-2" />
                      Start Journey
                    </Button>
                    <Button 
                      variant="outline" 
                      className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                    >
                      <BookOpen className="h-4 w-4 mr-2" />
                      Learn More
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
