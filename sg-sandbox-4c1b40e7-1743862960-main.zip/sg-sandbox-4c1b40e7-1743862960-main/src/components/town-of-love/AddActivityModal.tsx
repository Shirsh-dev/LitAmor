import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { X, Calendar, Puzzle } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Building {
  id: string;
  name: string;
  icon: JSX.Element;
  description: string;
  entries: number;
  position: {
    x: number;
    y: number;
  };
  unlocked: boolean;
  unlockLevel?: number;
}

interface AddActivityModalProps {
  onClose: () => void;
  buildings: Building[];
}

export function AddActivityModal({ onClose, buildings }: AddActivityModalProps) {
  const [selectedBuilding, setSelectedBuilding] = useState<string>("");
  const [activityTitle, setActivityTitle] = useState("");
  const [activityDescription, setActivityDescription] = useState("");
  const [activityDate, setActivityDate] = useState(new Date().toISOString().split('T')[0]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save the activity
    onClose();
  };
  
  // Get placeholder text based on selected building
  const getPlaceholder = () => {
    const building = buildings.find(b => b.id === selectedBuilding);
    switch (building?.id) {
      case "cafe":
        return "Describe your date at this cafe...";
      case "puzzle-park":
        return "Share details about the challenge you completed...";
      case "movie-bench":
        return "What did you think about the movie?";
      case "memory-gallery":
        return "Write something about this memory...";
      default:
        return "Describe your activity...";
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div 
        className="bg-white rounded-2xl w-full max-w-md mx-4 overflow-hidden shadow-xl"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.2 }}
      >
        <div className="p-4 border-b border-pink-100 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-foreground">Add New Activity</h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full">
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Location</label>
            <Select value={selectedBuilding} onValueChange={setSelectedBuilding}>
              <SelectTrigger className="rounded-lg">
                <SelectValue placeholder="Select a location" />
              </SelectTrigger>
              <SelectContent>
                {buildings.map(building => (
                  <SelectItem key={building.id} value={building.id}>
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 text-primary">
                        {building.icon}
                      </div>
                      <span>{building.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Title</label>
            <Input 
              placeholder="Give your activity a name"
              value={activityTitle}
              onChange={(e) => setActivityTitle(e.target.value)}
              className="rounded-lg"
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Date</label>
            <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2 border border-gray-200">
              <Calendar className="h-4 w-4 text-gray-500" />
              <Input 
                type="date" 
                value={activityDate}
                onChange={(e) => setActivityDate(e.target.value)}
                className="border-0 p-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Description</label>
            <Textarea 
              placeholder={getPlaceholder()}
              className="resize-none h-24 rounded-lg"
              value={activityDescription}
              onChange={(e) => setActivityDescription(e.target.value)}
            />
          </div>
          
          <div className="pt-4 flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onClose} className="rounded-full">
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-primary hover:bg-primary/90 text-white rounded-full"
              disabled={!selectedBuilding || !activityTitle.trim()}
            >
              Add Activity
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}