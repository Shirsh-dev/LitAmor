import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import { MessageSquare, ShoppingBag, Settings, Plus, Lock, Coffee, Film, Puzzle, Image as ImageIcon, Heart } from "lucide-react";
import { BuildingDetails } from "@/components/town-of-love/BuildingDetails";
import { AddActivityModal } from "@/components/town-of-love/AddActivityModal";

interface Building {
  id: string;
  name: string;
  icon: JSX.Element;
  description: string;
  entries: number;
  position: {
    x: number;
    y: number;
  };
  unlocked: boolean;
  unlockLevel?: number;
}

export function TownOfLove() {
  const [selectedBuilding, setSelectedBuilding] = useState<Building | null>(null);
  const [showAddActivityModal, setShowAddActivityModal] = useState(false);
  
  // Sample data
  const coupleData = {
    partner1: {
      name: "Sarah",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80"
    },
    partner2: {
      name: "Michael",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80"
    },
    level: 2,
    levelName: "Budding Romance",
    xp: 85,
    maxXp: 100,
    nextUnlock: "Love Garden"
  };
  
  const buildings: Building[] = [
    {
      id: "cafe",
      name: "Café of Memories",
      icon: <Coffee className="h-5 w-5" />,
      description: "A cozy place to save your favorite dates and romantic moments together.",
      entries: 2,
      position: { x: -120, y: 20 },
      unlocked: true
    },
    {
      id: "puzzle-park",
      name: "Puzzle Park",
      icon: <Puzzle className="h-5 w-5" />,
      description: "Complete couple challenges together to strengthen your bond.",
      entries: 1,
      position: { x: 80, y: -40 },
      unlocked: true
    },
    {
      id: "movie-bench",
      name: "Movie Bench",
      icon: <Film className="h-5 w-5" />,
      description: "Keep track of movies you've watched together.",
      entries: 3,
      position: { x: -60, y: -80 },
      unlocked: true
    },
    {
      id: "memory-gallery",
      name: "Memory Gallery",
      icon: <ImageIcon className="h-5 w-5" />,
      description: "A beautiful gallery to store your shared photos and memories.",
      entries: 3,
      position: { x: 140, y: 30 },
      unlocked: true
    },
    {
      id: "love-garden",
      name: "Love Garden",
      icon: <Heart className="h-5 w-5" />,
      description: "A peaceful garden to plant seeds of affection and watch them grow.",
      entries: 0,
      position: { x: 0, y: 100 },
      unlocked: false,
      unlockLevel: 3
    }
  ];
  
  const handleOpenBuilding = (building: Building) => {
    if (building.unlocked) {
      setSelectedBuilding(building);
    }
  };
  
  const handleCloseBuilding = () => {
    setSelectedBuilding(null);
  };
  
  return (
    <div className="min-h-screen romantic-gradient flex flex-col">
      {/* Top Bar */}
      <header className="w-full py-4 px-6 flex items-center justify-between bg-white/80 backdrop-blur-sm border-b border-pink-100">
        <Button variant="ghost" size="icon" className="rounded-full text-muted-foreground">
          <MessageSquare className="h-5 w-5" />
          <span className="sr-only">Chat</span>
        </Button>
        
        <div className="flex flex-col items-center">
          <h1 className="text-2xl font-bold text-foreground tracking-wide">Town of Love</h1>
          <div className="flex items-center gap-1">
            <LitAmorLogo size="small" />
            <span className="text-xs text-muted-foreground">Lit Amor</span>
          </div>
        </div>
        
        <Button variant="ghost" size="icon" className="rounded-full text-muted-foreground opacity-50">
          <ShoppingBag className="h-5 w-5" />
          <span className="sr-only">Store</span>
        </Button>
      </header>
      
      {/* Progress Bar */}
      <div className="w-full py-3 px-6 flex flex-col items-center bg-white/50 backdrop-blur-sm border-b border-pink-100">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm font-medium">Level {coupleData.level}: {coupleData.levelName}</span>
        </div>
        <div className="w-full max-w-xs flex items-center gap-2">
          <Progress value={coupleData.xp} max={coupleData.maxXp} className="h-2.5 bg-pink-100" indicatorClassName="bg-gradient-to-r from-pink-400 to-purple-400" />
          <span className="text-xs text-muted-foreground whitespace-nowrap">{coupleData.xp}/{coupleData.maxXp} ❤️</span>
        </div>
        <div className="mt-1">
          <span className="text-xs text-muted-foreground">Next unlock: {coupleData.nextUnlock}</span>
        </div>
      </div>
      
      {/* Town Map */}
      <div className="flex-1 relative overflow-hidden">
        {/* Town Background */}
        <div className="absolute inset-0 bg-gradient-to-b from-blue-100 to-blue-200">
          {/* Decorative elements */}
          <motion.div 
            className="absolute top-10 left-[10%] text-yellow-300/70"
            animate={{ 
              y: [0, 10, 0],
              rotate: [0, 5, 0]
            }}
            transition={{ 
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
              <circle cx="12" cy="12" r="6" />
              <path d="M12 2 L12 4 M12 20 L12 22 M2 12 L4 12 M20 12 L22 12 M4.93 4.93 L6.34 6.34 M17.66 17.66 L19.07 19.07 M4.93 19.07 L6.34 17.66 M17.66 6.34 L19.07 4.93" stroke="currentColor" strokeWidth="2" />
            </svg>
          </motion.div>
          
          {/* Clouds */}
          <motion.div 
            className="absolute top-[15%] right-[20%] w-32 h-12 bg-white/80 rounded-full blur-md"
            animate={{ x: [0, -30, 0] }}
            transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div 
            className="absolute top-[8%] left-[30%] w-24 h-10 bg-white/80 rounded-full blur-md"
            animate={{ x: [0, 20, 0] }}
            transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
          />
          
          {/* Ground */}
          <div className="absolute bottom-0 left-0 right-0 h-[60%] bg-gradient-to-t from-green-200 to-green-100 rounded-t-[50%] overflow-hidden">
            {/* Path */}
            <div className="absolute top-[10%] left-[10%] right-[10%] bottom-0 bg-amber-100/50 rounded-t-full" />
          </div>
        </div>
        
        {/* Buildings */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="relative w-full h-full">
            {buildings.map((building) => (
              <motion.div
                key={building.id}
                className={`absolute cursor-pointer ${!building.unlocked && 'opacity-50'}`}
                style={{ 
                  left: `calc(50% + ${building.position.x}px)`, 
                  top: `calc(50% + ${building.position.y}px)` 
                }}
                whileHover={{ scale: building.unlocked ? 1.05 : 1 }}
                onClick={() => handleOpenBuilding(building)}
              >
                <div className={`relative w-20 h-24 flex flex-col items-center ${building.unlocked ? '' : 'grayscale'}`}>
                  {/* Building */}
                  {building.id === "cafe" && (
                    <div className="w-16 h-16 bg-pink-200 rounded-lg flex flex-col overflow-hidden border-2 border-pink-300 shadow-lg">
                      <div className="h-1/3 bg-pink-300 w-full flex justify-center items-center">
                        <span className="text-white text-xs font-bold">CAFÉ</span>
                      </div>
                      <div className="flex-1 flex justify-center items-center">
                        <Coffee className="h-6 w-6 text-pink-500" />
                      </div>
                    </div>
                  )}
                  
                  {building.id === "puzzle-park" && (
                    <div className="w-16 h-16 bg-blue-200 rounded-lg flex flex-col overflow-hidden border-2 border-blue-300 shadow-lg">
                      <div className="h-1/3 bg-blue-300 w-full flex justify-center items-center">
                        <span className="text-white text-xs font-bold">PARK</span>
                      </div>
                      <div className="flex-1 flex justify-center items-center">
                        <Puzzle className="h-6 w-6 text-blue-500" />
                      </div>
                    </div>
                  )}
                  
                  {building.id === "movie-bench" && (
                    <div className="w-16 h-16 bg-purple-200 rounded-lg flex flex-col overflow-hidden border-2 border-purple-300 shadow-lg">
                      <div className="h-1/3 bg-purple-300 w-full flex justify-center items-center">
                        <span className="text-white text-xs font-bold">MOVIES</span>
                      </div>
                      <div className="flex-1 flex justify-center items-center">
                        <Film className="h-6 w-6 text-purple-500" />
                      </div>
                    </div>
                  )}
                  
                  {building.id === "memory-gallery" && (
                    <div className="w-16 h-16 bg-amber-200 rounded-lg flex flex-col overflow-hidden border-2 border-amber-300 shadow-lg">
                      <div className="h-1/3 bg-amber-300 w-full flex justify-center items-center">
                        <span className="text-white text-xs font-bold">GALLERY</span>
                      </div>
                      <div className="flex-1 flex justify-center items-center">
                        <ImageIcon className="h-6 w-6 text-amber-500" />
                      </div>
                    </div>
                  )}
                  
                  {building.id === "love-garden" && (
                    <div className="w-16 h-16 bg-green-200 rounded-lg flex flex-col overflow-hidden border-2 border-green-300 shadow-lg">
                      <div className="h-1/3 bg-green-300 w-full flex justify-center items-center">
                        <span className="text-white text-xs font-bold">GARDEN</span>
                      </div>
                      <div className="flex-1 flex justify-center items-center">
                        <Heart className="h-6 w-6 text-green-500" />
                      </div>
                    </div>
                  )}
                  
                  {/* Building Name */}
                  <span className="mt-1 text-xs text-center font-medium text-gray-700 max-w-full truncate">
                    {building.name}
                  </span>
                  
                  {/* Lock icon for locked buildings */}
                  {!building.unlocked && (
                    <div className="absolute -top-2 -right-2 bg-gray-500 rounded-full p-1 shadow-md">
                      <Lock className="h-3 w-3 text-white" />
                      <span className="absolute top-full left-1/2 transform -translate-x-1/2 text-[10px] whitespace-nowrap bg-gray-500 text-white px-1 rounded mt-1">
                        Unlock at Level {building.unlockLevel}
                      </span>
                    </div>
                  )}
                  
                  {/* Entry count badge */}
                  {building.unlocked && building.entries > 0 && (
                    <div className="absolute -top-2 -right-2 bg-pink-500 rounded-full h-5 w-5 flex items-center justify-center shadow-md">
                      <span className="text-[10px] text-white font-bold">{building.entries}</span>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Character Avatars */}
        <div className="absolute bottom-8 left-8 flex items-end">
          <div className="relative">
            <Avatar className="border-2 border-white h-12 w-12 shadow-md">
              <AvatarFallback>{coupleData.partner1.name[0]}</AvatarFallback>
              <AvatarImage src={coupleData.partner1.avatar} alt={coupleData.partner1.name} />
            </Avatar>
            <motion.div
              className="absolute -bottom-1 left-1/2 transform -translate-x-1/2"
              animate={{ y: [0, -3, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <div className="w-10 h-3 bg-black/10 rounded-full blur-sm" />
            </motion.div>
          </div>
          <div className="relative -ml-2">
            <Avatar className="border-2 border-white h-12 w-12 shadow-md">
              <AvatarFallback>{coupleData.partner2.name[0]}</AvatarFallback>
              <AvatarImage src={coupleData.partner2.avatar} alt={coupleData.partner2.name} />
            </Avatar>
            <motion.div
              className="absolute -bottom-1 left-1/2 transform -translate-x-1/2"
              animate={{ y: [0, -3, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut", delay: 0.2 }}
            >
              <div className="w-10 h-3 bg-black/10 rounded-full blur-sm" />
            </motion.div>
          </div>
        </div>
      </div>
      
      {/* Bottom Bar */}
      <div className="w-full py-4 px-6 flex items-center justify-between bg-white/80 backdrop-blur-sm border-t border-pink-100">
        <Button variant="ghost" size="icon" className="rounded-full border-pink-200 h-10 w-10">
          <Settings className="h-5 w-5 text-muted-foreground" />
        </Button>
        
        <Button 
          onClick={() => setShowAddActivityModal(true)}
          className="bg-primary hover:bg-primary/90 text-white font-medium rounded-full px-6 py-6 flex items-center gap-2 shadow-lg"
        >
          <Plus className="h-5 w-5" />
          <span>Add Activity</span>
        </Button>
        
        <div className="w-10 h-10" /> {/* Spacer to balance layout */}
      </div>
      
      {/* Building Details Modal */}
      <AnimatePresence>
        {selectedBuilding && (
          <BuildingDetails building={selectedBuilding} onClose={handleCloseBuilding} />
        )}
      </AnimatePresence>
      
      {/* Add Activity Modal */}
      <AnimatePresence>
        {showAddActivityModal && (
          <AddActivityModal onClose={() => setShowAddActivityModal(false)} buildings={buildings.filter(b => b.unlocked)} />
        )}
      </AnimatePresence>
    </div>
  );
}