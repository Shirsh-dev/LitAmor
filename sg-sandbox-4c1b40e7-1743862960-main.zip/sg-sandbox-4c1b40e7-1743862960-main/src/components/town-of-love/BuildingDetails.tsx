
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { X, Calendar, Plus } from "lucide-react";

interface Building {
  id: string;
  name: string;
  icon: JSX.Element;
  description: string;
  entries: number;
  position: {
    x: number;
    y: number;
  };
  unlocked: boolean;
  unlockLevel?: number;
}

interface BuildingDetailsProps {
  building: Building;
  onClose: () => void;
}

export function BuildingDetails({ building, onClose }: BuildingDetailsProps) {
  // Mock entries based on building type
  const getEntries = () => {
    switch (building.id) {
      case "cafe":
        return [
          { id: "1", title: "First Coffee Date", date: "2025-01-15" },
          { id: "2", title: "Breakfast at Sunrise Cafe", date: "2025-02-20" }
        ];
      case "puzzle-park":
        return [
          { id: "1", title: "Completed: Couple Q&A Challenge", date: "2025-02-05" }
        ];
      case "movie-bench":
        return [
          { id: "1", title: "The Notebook", date: "2025-01-10" },
          { id: "2", title: "La La Land", date: "2025-01-25" },
          { id: "3", title: "Before Sunrise", date: "2025-02-14" }
        ];
      case "memory-gallery":
        return [
          { id: "1", title: "Beach Day", date: "2025-01-05" },
          { id: "2", title: "Hiking Adventure", date: "2025-01-30" },
          { id: "3", title: "Valentine's Dinner", date: "2025-02-14" }
        ];
      default:
        return [];
    }
  };
  
  const entries = getEntries();
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };
  
  // Get background color based on building id
  const getBgColor = () => {
    switch (building.id) {
      case "cafe":
        return "bg-pink-50";
      case "puzzle-park":
        return "bg-blue-50";
      case "movie-bench":
        return "bg-purple-50";
      case "memory-gallery":
        return "bg-amber-50";
      case "love-garden":
        return "bg-green-50";
      default:
        return "bg-white";
    }
  };
  
  // Get accent color based on building id
  const getAccentColor = () => {
    switch (building.id) {
      case "cafe":
        return "bg-pink-500";
      case "puzzle-park":
        return "bg-blue-500";
      case "movie-bench":
        return "bg-purple-500";
      case "memory-gallery":
        return "bg-amber-500";
      case "love-garden":
        return "bg-green-500";
      default:
        return "bg-primary";
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div 
        className={`${getBgColor()} rounded-2xl w-full max-w-md mx-4 overflow-hidden shadow-xl`}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.2 }}
      >
        <div className={`p-4 border-b border-gray-200 flex items-center justify-between`}>
          <div className="flex items-center gap-3">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getAccentColor()} text-white`}>
              {building.icon}
            </div>
            <h2 className="text-xl font-semibold text-gray-800">{building.name}</h2>
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-200/50"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="p-6 space-y-6">
          <p className="text-gray-600">{building.description}</p>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-700">Entries ({entries.length})</h3>
              <Button variant="ghost" size="sm" className="h-8 rounded-full text-primary">
                <Plus className="h-4 w-4 mr-1" />
                <span>Add New</span>
              </Button>
            </div>
            
            {entries.length > 0 ? (
              <div className="space-y-2">
                {entries.map(entry => (
                  <div key={entry.id} className="bg-white rounded-lg p-3 shadow-sm border border-gray-100">
                    <div className="flex justify-between items-start">
                      <span className="font-medium text-gray-800">{entry.title}</span>
                      <div className="flex items-center text-xs text-gray-500">
                        <Calendar className="h-3 w-3 mr-1" />
                        {formatDate(entry.date)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg p-4 text-center text-gray-500 border border-dashed border-gray-200">
                No entries yet. Add your first one!
              </div>
            )}
          </div>
          
          <div className="pt-4 flex justify-end">
            <Button 
              onClick={onClose}
              className={`text-white rounded-full px-6 ${getAccentColor()}`}
            >
              Close
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
