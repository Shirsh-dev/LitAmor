import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Clock, Calendar, Award, ChevronRight } from "lucide-react";
import { WeeklyEntry, MonthlyMilestone, HEART_TYPES, MILESTONE_LEVELS } from "@/types/litScore";
import { format } from "date-fns";

interface TimelineViewProps {
  isOpen: boolean;
  onClose: () => void;
  timeline: WeeklyEntry[];
  milestones: MonthlyMilestone[];
  currentUserName: string;
  partnerName: string;
}

export function TimelineView({
  isOpen,
  onClose,
  timeline,
  milestones,
  currentUserName,
  partnerName
}: TimelineViewProps) {
  const sortedTimeline = [...timeline].sort((a, b) => 
    b.weekStartDate.getTime() - a.weekStartDate.getTime()
  );

  const sortedMilestones = [...milestones].sort((a, b) => 
    b.startDate.getTime() - a.startDate.getTime()
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">LitScore Timeline</DialogTitle>
          <p className="text-gray-600">Your emotional growth journey together</p>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {sortedMilestones.length > 0 && (
            <div className="space-y-3">
              <h3 className="font-semibold text-lg flex items-center gap-2">
                <Award className="w-5 h-5" />
                Monthly Milestones
              </h3>
              <div className="grid gap-3">
                {sortedMilestones.map((milestone) => {
                  const levelInfo = MILESTONE_LEVELS[milestone.level];
                  return (
                    <Card key={`${milestone.month}-${milestone.year}`} className={`${levelInfo.bgColor} border-2`}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-3">
                            <span className="text-3xl">{levelInfo.icon}</span>
                            <div>
                              <div className="font-semibold text-lg">{levelInfo.title}</div>
                              <div className="text-sm text-gray-700 mb-2">{levelInfo.description}</div>
                              <div className="text-xs text-gray-600">
                                {format(milestone.startDate, "MMM d")} - {format(milestone.endDate, "MMM d, yyyy")}
                              </div>
                            </div>
                          </div>
                          {milestone.achieved && (
                            <Badge className={`${levelInfo.color} bg-white`}>
                              Level {milestone.level}
                            </Badge>
                          )}
                        </div>
                        <div className="mt-3 space-y-1">
                          {levelInfo.requirements.map((req, idx) => (
                            <div key={idx} className="text-xs text-gray-700 flex items-start gap-2">
                              <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
                              <span>{req}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          )}

          <Separator />

          <div className="space-y-3">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Weekly Reflections
            </h3>

            {sortedTimeline.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-gray-600">No reflections yet. Start your journey this Sunday!</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {sortedTimeline.map((entry) => (
                  <Card key={entry.weekNumber} className="border-2">
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <div className="font-semibold text-lg">Week {entry.weekNumber}</div>
                          <div className="text-sm text-gray-600 flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            {format(entry.weekStartDate, "MMM d")} - {format(entry.weekEndDate, "MMM d, yyyy")}
                          </div>
                        </div>
                        <Badge variant={entry.bothSubmitted ? "default" : "secondary"}>
                          {entry.bothSubmitted ? "Complete" : entry.status === "partial" ? "Pending Partner" : "Pending"}
                        </Badge>
                      </div>

                      {entry.bothSubmitted && entry.partnerA && entry.partnerB ? (
                        <div className="space-y-6">
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
                              <div className="flex items-center justify-between">
                                <span className="font-medium">{entry.partnerA.userName}</span>
                                <span className="text-2xl">
                                  {HEART_TYPES[entry.partnerA.heartRating].icon}
                                </span>
                              </div>
                              
                              <div className="space-y-2">
                                <div>
                                  <div className="text-xs font-semibold text-gray-700 uppercase mb-1">
                                    Performance Feedback
                                  </div>
                                  <p className="text-sm text-gray-800 leading-relaxed">
                                    {entry.partnerA.reflection.performance}
                                  </p>
                                </div>
                                
                                <div>
                                  <div className="text-xs font-semibold text-gray-700 uppercase mb-1">
                                    Suggested Solution
                                  </div>
                                  <p className="text-sm text-gray-800 leading-relaxed">
                                    {entry.partnerA.reflection.solution}
                                  </p>
                                </div>
                              </div>
                              
                              <div className="text-xs text-gray-500 flex items-center gap-1 pt-2 border-t">
                                <Clock className="w-3 h-3" />
                                {format(entry.partnerA.submittedAt, "MMM d, h:mm a")}
                              </div>
                            </div>

                            <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
                              <div className="flex items-center justify-between">
                                <span className="font-medium">{entry.partnerB.userName}</span>
                                <span className="text-2xl">
                                  {HEART_TYPES[entry.partnerB.heartRating].icon}
                                </span>
                              </div>
                              
                              <div className="space-y-2">
                                <div>
                                  <div className="text-xs font-semibold text-gray-700 uppercase mb-1">
                                    Performance Feedback
                                  </div>
                                  <p className="text-sm text-gray-800 leading-relaxed">
                                    {entry.partnerB.reflection.performance}
                                  </p>
                                </div>
                                
                                <div>
                                  <div className="text-xs font-semibold text-gray-700 uppercase mb-1">
                                    Suggested Solution
                                  </div>
                                  <p className="text-sm text-gray-800 leading-relaxed">
                                    {entry.partnerB.reflection.solution}
                                  </p>
                                </div>
                              </div>
                              
                              <div className="text-xs text-gray-500 flex items-center gap-1 pt-2 border-t">
                                <Clock className="w-3 h-3" />
                                {format(entry.partnerB.submittedAt, "MMM d, h:mm a")}
                              </div>
                            </div>
                          </div>

                          {entry.revealedAt && (
                            <div className="text-xs text-center text-gray-500 pt-2 border-t">
                              Unlocked on {format(entry.revealedAt, "MMMM d, yyyy 'at' h:mm a")}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="py-8 text-center">
                          <div className="text-gray-500 mb-2">
                            {entry.status === "partial" 
                              ? `Waiting for ${entry.partnerA ? partnerName : currentUserName} to submit`
                              : "Both partners need to submit their reflections"
                            }
                          </div>
                          <p className="text-sm text-gray-400">
                            Reflections will unlock once both partners submit
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t">
          <Button onClick={onClose}>Close</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}