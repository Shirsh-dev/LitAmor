import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Heart } from "lucide-react";
import { HeartRating, HEART_TYPES, WeeklyReflection } from "@/types/litScore";

interface SubmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (rating: HeartRating, reflection: WeeklyReflection) => void;
  partnerName: string;
  weekNumber: number;
  isSubmitting?: boolean;
}

export function SubmissionModal({
  isOpen,
  onClose,
  onSubmit,
  partnerName,
  weekNumber,
  isSubmitting = false
}: SubmissionModalProps) {
  const [selectedHeart, setSelectedHeart] = useState<HeartRating | null>(null);
  const [performance, setPerformance] = useState("");
  const [solution, setSolution] = useState("");
  const [errors, setErrors] = useState<{ performance?: string; solution?: string }>({});

  const validateAndSubmit = () => {
    const newErrors: { performance?: string; solution?: string } = {};

    if (!selectedHeart) {
      return;
    }

    if (performance.trim().length < 20) {
      newErrors.performance = "Please write at least 20 characters";
    }

    if (solution.trim().length < 20) {
      newErrors.solution = "Please write at least 20 characters";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    onSubmit(selectedHeart, {
      performance: performance.trim(),
      solution: solution.trim()
    });

    setSelectedHeart(null);
    setPerformance("");
    setSolution("");
    setErrors({});
  };

  const handleClose = () => {
    if (!isSubmitting) {
      setSelectedHeart(null);
      setPerformance("");
      setSolution("");
      setErrors({});
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Week {weekNumber} Reflection</DialogTitle>
          <DialogDescription className="text-base">
            How did this week feel with {partnerName}? Share your heart.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-3">
            <Label className="text-base font-medium">Select Your Heart</Label>
            <p className="text-sm text-gray-600">
              Choose the heart that best represents your feelings this week
            </p>
            
            <div className="grid gap-3">
              {Object.values(HEART_TYPES).map((heart) => (
                <button
                  key={heart.type}
                  onClick={() => setSelectedHeart(heart.type)}
                  className={`
                    p-4 rounded-lg border-2 text-left transition-all
                    ${selectedHeart === heart.type 
                      ? `${heart.bgColor} border-current ${heart.color}` 
                      : "border-gray-200 hover:border-gray-300"
                    }
                  `}
                >
                  <div className="flex items-start gap-3">
                    <span className="text-3xl">{heart.icon}</span>
                    <div className="flex-1">
                      <div className="font-semibold text-base mb-1">{heart.label}</div>
                      <div className="text-sm text-gray-700">{heart.meaning}</div>
                    </div>
                    {selectedHeart === heart.type && (
                      <Heart className="w-5 h-5 fill-current" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {selectedHeart && (
            <>
              <div className="space-y-2">
                <Label htmlFor="performance" className="text-base font-medium">
                  1. Performance Feedback
                </Label>
                <p className="text-sm text-gray-600">
                  What went well or felt difficult this week? Describe your partner&apos;s emotional effort.
                </p>
                <Textarea
                  id="performance"
                  value={performance}
                  onChange={(e) => {
                    setPerformance(e.target.value);
                    if (errors.performance) {
                      setErrors({ ...errors, performance: undefined });
                    }
                  }}
                  placeholder="This week, I noticed..."
                  className="min-h-[120px] resize-none"
                  maxLength={500}
                />
                {errors.performance && (
                  <p className="text-sm text-red-500">{errors.performance}</p>
                )}
                <p className="text-xs text-gray-500 text-right">
                  {performance.length}/500 characters
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="solution" className="text-base font-medium">
                  2. Suggested Solution
                </Label>
                <p className="text-sm text-gray-600">
                  What small thing can we do differently next week to feel more connected?
                </p>
                <Textarea
                  id="solution"
                  value={solution}
                  onChange={(e) => {
                    setSolution(e.target.value);
                    if (errors.solution) {
                      setErrors({ ...errors, solution: undefined });
                    }
                  }}
                  placeholder="Next week, let's try..."
                  className="min-h-[120px] resize-none"
                  maxLength={500}
                />
                {errors.solution && (
                  <p className="text-sm text-red-500">{errors.solution}</p>
                )}
                <p className="text-xs text-gray-500 text-right">
                  {solution.length}/500 characters
                </p>
              </div>
            </>
          )}
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            onClick={validateAndSubmit}
            disabled={!selectedHeart || isSubmitting}
            className="min-w-[120px]"
          >
            {isSubmitting ? "Submitting..." : "Submit Reflection"}
          </Button>
        </div>

        <div className="mt-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
          <p className="text-sm text-purple-900">
            <strong>Remember:</strong> Your reflection will be private until {partnerName} also submits. 
            Once both submit, your hearts and reflections will unlock for each other.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}