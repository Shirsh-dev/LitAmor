import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Heart, Calendar, TrendingUp, Lock, Award, Clock, Bell } from "lucide-react";
import { SubmissionModal } from "./RatingModal";
import { TimelineView } from "./ScoreHistoryModal";
import {
  LitScoreState,
  WeeklyEntry,
  HeartRating,
  WeeklyReflection,
  HEART_TYPES,
  getWeekNumber,
  getWeekStartDate,
  getWeekEndDate,
  isSunday,
  getDaysUntilSunday,
  hasThreeMonthsPassed,
  calculateMilestoneLevel,
  MonthlyMilestone
} from "@/types/litScore";

export function LitScoreMain() {
  const [showSubmissionModal, setShowSubmissionModal] = useState(false);
  const [showTimelineModal, setShowTimelineModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [litScoreState, setLitScoreState] = useState<LitScoreState>({
    couple: {
      coupleId: "couple_001",
      partnerA: { userId: "user_001", name: "Alex" },
      partnerB: { userId: "user_002", name: "Jordan" },
      activatedAt: new Date("2025-08-01"),
      premiumStatus: "free",
      currentStreak: 0,
      longestStreak: 0
    },
    currentWeek: {
      weekNumber: getWeekNumber(new Date()),
      weekStartDate: getWeekStartDate(new Date()),
      weekEndDate: getWeekEndDate(getWeekStartDate(new Date())),
      bothSubmitted: false,
      status: "pending"
    },
    timeline: [],
    milestones: [],
    canSubmit: true,
    needsReminder: false,
    isPremiumLocked: false
  });

  const currentUserId = "user_001";
  const currentUser = litScoreState.couple.partnerA.userId === currentUserId 
    ? litScoreState.couple.partnerA 
    : litScoreState.couple.partnerB;
  const partner = litScoreState.couple.partnerA.userId === currentUserId 
    ? litScoreState.couple.partnerB 
    : litScoreState.couple.partnerA;

  const hasCurrentUserSubmitted = litScoreState.currentWeek.partnerA?.userId === currentUserId || 
                                   litScoreState.currentWeek.partnerB?.userId === currentUserId;

  useEffect(() => {
    checkPremiumStatus();
    checkWeeklyReset();
  }, []);

  const checkPremiumStatus = () => {
    const threeMonthsPassed = hasThreeMonthsPassed(
      litScoreState.couple.activatedAt,
      new Date()
    );

    if (threeMonthsPassed && litScoreState.couple.premiumStatus === "free") {
      setLitScoreState(prev => ({
        ...prev,
        isPremiumLocked: true
      }));
    }
  };

  const checkWeeklyReset = () => {
    const now = new Date();
    const currentWeekNum = getWeekNumber(now);

    if (currentWeekNum !== litScoreState.currentWeek.weekNumber) {
      const newWeekStart = getWeekStartDate(now);
      setLitScoreState(prev => ({
        ...prev,
        currentWeek: {
          weekNumber: currentWeekNum,
          weekStartDate: newWeekStart,
          weekEndDate: getWeekEndDate(newWeekStart),
          bothSubmitted: false,
          status: "pending"
        },
        canSubmit: true
      }));
    }
  };

  const handleSubmitReflection = async (rating: HeartRating, reflection: WeeklyReflection) => {
    setIsSubmitting(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1500));

      const submission = {
        userId: currentUserId,
        userName: currentUser.name,
        heartRating: rating,
        reflection,
        submittedAt: new Date()
      };

      setLitScoreState(prev => {
        const updatedWeek = { ...prev.currentWeek };
        
        if (!updatedWeek.partnerA) {
          updatedWeek.partnerA = submission;
          updatedWeek.status = "partial";
        } else {
          updatedWeek.partnerB = submission;
          updatedWeek.bothSubmitted = true;
          updatedWeek.status = "complete";
          updatedWeek.revealedAt = new Date();
        }

        const updatedTimeline = prev.timeline.filter(
          e => e.weekNumber !== updatedWeek.weekNumber
        );
        updatedTimeline.push(updatedWeek);

        const milestones = calculateMonthlyMilestones(updatedTimeline);

        return {
          ...prev,
          currentWeek: updatedWeek,
          timeline: updatedTimeline,
          milestones,
          canSubmit: false
        };
      });

      setShowSubmissionModal(false);
    } catch (error) {
      console.error("Error submitting reflection:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const calculateMonthlyMilestones = (timeline: WeeklyEntry[]): MonthlyMilestone[] => {
    const milestones: MonthlyMilestone[] = [];
    const completedEntries = timeline.filter(e => e.bothSubmitted);

    if (completedEntries.length < 4) return milestones;

    const sortedEntries = [...completedEntries].sort(
      (a, b) => a.weekStartDate.getTime() - b.weekStartDate.getTime()
    );

    for (let i = 0; i <= sortedEntries.length - 4; i++) {
      const fourWeeks = sortedEntries.slice(i, i + 4);
      const firstWeek = fourWeeks[0];
      const lastWeek = fourWeeks[3];

      const milestone: MonthlyMilestone = {
        month: firstWeek.weekStartDate.getMonth() + 1,
        year: firstWeek.weekStartDate.getFullYear(),
        startDate: firstWeek.weekStartDate,
        endDate: lastWeek.weekEndDate,
        level: calculateMilestoneLevel(fourWeeks),
        achieved: true,
        achievedAt: lastWeek.revealedAt,
        weeklyEntries: fourWeeks
      };

      milestones.push(milestone);
    }

    return milestones;
  };

  const daysUntilSunday = getDaysUntilSunday(new Date());
  const isCurrentlySunday = isSunday(new Date());

  if (litScoreState.isPremiumLocked) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 p-6">
        <div className="max-w-2xl mx-auto">
          <Card className="border-2 border-purple-200">
            <CardContent className="p-8 text-center space-y-4">
              <Lock className="w-16 h-16 mx-auto text-purple-500" />
              <h2 className="text-2xl font-bold">Premium Feature</h2>
              <p className="text-gray-600">
                Your free 3-month trial has ended. Upgrade to Premium to continue your LitScore journey.
              </p>
              <div className="space-y-2 text-left bg-purple-50 p-4 rounded-lg">
                <p className="text-sm font-semibold">Premium Benefits:</p>
                <ul className="text-sm space-y-1 text-gray-700">
                  <li>✓ Continued weekly LitScore prompts</li>
                  <li>✓ Lifetime access to all past reflections</li>
                  <li>✓ Monthly milestone tracking</li>
                  <li>✓ Full emotional growth timeline</li>
                </ul>
              </div>
              <Button size="lg" className="w-full">
                Upgrade to Premium
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-gray-900 flex items-center justify-center gap-3">
            <Heart className="w-10 h-10 text-red-500 fill-red-500" />
            LitScore
          </h1>
          <p className="text-gray-600">Your weekly emotional check-in ritual</p>
        </div>

        {isCurrentlySunday && !hasCurrentUserSubmitted && (
          <Alert className="border-purple-200 bg-purple-50">
            <Bell className="w-5 h-5" />
            <AlertDescription className="text-base">
              <strong>Sunday Reflection Time!</strong> How did this week feel with {partner.name}? 
              Submit your LitScore now 💌
            </AlertDescription>
          </Alert>
        )}

        {!isCurrentlySunday && !hasCurrentUserSubmitted && (
          <Alert>
            <Clock className="w-5 h-5" />
            <AlertDescription>
              Next LitScore prompt arrives in <strong>{daysUntilSunday} days</strong> (Sunday)
            </AlertDescription>
          </Alert>
        )}

        <Card className="border-2">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Week {litScoreState.currentWeek.weekNumber}
              </span>
              <Badge variant={litScoreState.currentWeek.bothSubmitted ? "default" : "secondary"}>
                {litScoreState.currentWeek.bothSubmitted 
                  ? "Complete" 
                  : litScoreState.currentWeek.status === "partial"
                  ? "Waiting for Partner"
                  : "Pending"}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="space-y-1">
                <div className="text-sm text-gray-600">Your Status</div>
                <div className="font-semibold">
                  {hasCurrentUserSubmitted ? (
                    <span className="text-green-600">✓ Submitted</span>
                  ) : (
                    <span className="text-orange-600">Pending</span>
                  )}
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-sm text-gray-600">{partner.name}&apos;s Status</div>
                <div className="font-semibold">
                  {litScoreState.currentWeek.partnerA && litScoreState.currentWeek.partnerB ? (
                    <span className="text-green-600">✓ Submitted</span>
                  ) : hasCurrentUserSubmitted ? (
                    <span className="text-orange-600">Pending</span>
                  ) : (
                    <span className="text-gray-400">Waiting</span>
                  )}
                </div>
              </div>
            </div>

            {litScoreState.currentWeek.bothSubmitted && (
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-gradient-to-br from-red-50 to-pink-50 rounded-lg border-2 border-red-100">
                  <div className="text-center">
                    <div className="text-5xl mb-2">
                      {litScoreState.currentWeek.partnerA && 
                        HEART_TYPES[litScoreState.currentWeek.partnerA.heartRating].icon}
                    </div>
                    <div className="font-semibold">{litScoreState.currentWeek.partnerA?.userName}</div>
                    <div className="text-sm text-gray-600 mt-1">
                      {litScoreState.currentWeek.partnerA && 
                        HEART_TYPES[litScoreState.currentWeek.partnerA.heartRating].label}
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg border-2 border-green-100">
                  <div className="text-center">
                    <div className="text-5xl mb-2">
                      {litScoreState.currentWeek.partnerB && 
                        HEART_TYPES[litScoreState.currentWeek.partnerB.heartRating].icon}
                    </div>
                    <div className="font-semibold">{litScoreState.currentWeek.partnerB?.userName}</div>
                    <div className="text-sm text-gray-600 mt-1">
                      {litScoreState.currentWeek.partnerB && 
                        HEART_TYPES[litScoreState.currentWeek.partnerB.heartRating].label}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {!hasCurrentUserSubmitted && litScoreState.canSubmit && (
              <Button 
                onClick={() => setShowSubmissionModal(true)}
                className="w-full"
                size="lg"
              >
                <Heart className="w-5 h-5 mr-2" />
                Submit This Week&apos;s Reflection
              </Button>
            )}

            {hasCurrentUserSubmitted && !litScoreState.currentWeek.bothSubmitted && (
              <div className="text-center p-6 bg-purple-50 rounded-lg">
                <p className="text-purple-900 font-medium">
                  Your reflection is submitted! Waiting for {partner.name} to complete theirs.
                </p>
                <p className="text-sm text-purple-700 mt-2">
                  Once both of you submit, your hearts and reflections will unlock 💜
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <div className="text-2xl font-bold">{litScoreState.timeline.filter(e => e.bothSubmitted).length}</div>
              <div className="text-sm text-gray-600">Completed Weeks</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Award className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <div className="text-2xl font-bold">{litScoreState.milestones.length}</div>
              <div className="text-sm text-gray-600">Milestones Achieved</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Heart className="w-8 h-8 mx-auto mb-2 text-red-600" />
              <div className="text-2xl font-bold">{litScoreState.couple.currentStreak}</div>
              <div className="text-sm text-gray-600">Current Streak</div>
            </CardContent>
          </Card>
        </div>

        <Button
          onClick={() => setShowTimelineModal(true)}
          variant="outline"
          className="w-full"
          size="lg"
        >
          <Calendar className="w-5 h-5 mr-2" />
          View Full Timeline
        </Button>

        <div className="p-6 bg-white rounded-lg border-2 border-purple-100 space-y-3">
          <h3 className="font-semibold text-lg">How LitScore Works</h3>
          <div className="space-y-2 text-sm text-gray-700">
            <p>🗓️ Every Sunday, both partners receive a reflection prompt</p>
            <p>❤️ Rate your partner with one of three hearts (Red, Green, or Black)</p>
            <p>✍️ Write two short reflections: Performance + Solution</p>
            <p>🔒 Reflections stay private until both partners submit</p>
            <p>🏆 Unlock monthly milestones after 4 consecutive weeks</p>
          </div>
        </div>
      </div>

      <SubmissionModal
        isOpen={showSubmissionModal}
        onClose={() => setShowSubmissionModal(false)}
        onSubmit={handleSubmitReflection}
        partnerName={partner.name}
        weekNumber={litScoreState.currentWeek.weekNumber}
        isSubmitting={isSubmitting}
      />

      <TimelineView
        isOpen={showTimelineModal}
        onClose={() => setShowTimelineModal(false)}
        timeline={litScoreState.timeline}
        milestones={litScoreState.milestones}
        currentUserName={currentUser.name}
        partnerName={partner.name}
      />
    </div>
  );
}