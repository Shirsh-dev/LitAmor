
import { useState, useEffect } from "react";
import { Bell, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";

interface AmoreStreakNotificationProps {
  onClose?: () => void;
}

export function AmoreStreakNotification({ onClose }: AmoreStreakNotificationProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Show notification after a delay
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    if (onClose) {
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-20 left-4 right-4 z-50"
        >
          <div className="bg-gradient-to-r from-pink-500 to-orange-500 rounded-lg shadow-lg p-4 text-white">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white/20 rounded-full p-2">
                  <Bell className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-medium">Amore Streak Reminder</h3>
                  <p className="text-sm text-white/80">Don't forget to send today's Amore Streak ❤️</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="text-white p-1 h-auto" onClick={handleClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
