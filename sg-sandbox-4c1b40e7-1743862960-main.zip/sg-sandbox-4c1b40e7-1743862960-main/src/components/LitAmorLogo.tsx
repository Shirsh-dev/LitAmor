
import Link from "next/link";
import { useRouter } from "next/router";
import Image from "next/image";

interface LitAmorLogoProps {
  size?: "small" | "default" | "large";
  clickable?: boolean;
}

export function LitAmorLogo({ size = "default", clickable = true }: LitAmorLogoProps) {
  const router = useRouter();
  
  const getHomeRoute = () => {
    if (router.pathname.startsWith("/singles")) return "/singles/home";
    if (router.pathname.startsWith("/couple")) return "/couple/home";
    return "/";
  };

  const sizeClasses = {
    small: "w-8 h-8",
    default: "w-12 h-12",
    large: "w-16 h-16"
  };

  const LogoComponent = () => (
    <div className={`${sizeClasses[size]} relative flex items-center justify-center`}>
      <Image
        src="/chatgpt-image-may-2-2025-03-08-35-am-removebg-preview-mbdt1abg.png"
        alt="LIT AMOR Logo"
        width={size === "small" ? 32 : size === "large" ? 64 : 48}
        height={size === "small" ? 32 : size === "large" ? 64 : 48}
        className="object-contain"
        priority
      />
    </div>
  );

  if (!clickable) {
    return <LogoComponent />;
  }

  return (
    <Link 
      href={getHomeRoute()} 
      className="cursor-pointer hover:scale-110 transition-all duration-300 transform hover:drop-shadow-lg focus:outline-none focus:ring-2 focus:ring-pink-400 focus:ring-opacity-50 rounded-full"
      aria-label="Go to home page"
    >
      <LogoComponent />
    </Link>
  );
}
