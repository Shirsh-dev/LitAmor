
import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { X, Send } from "lucide-react";
import { Group } from "@/components/singles-planet/PlanetView";

interface RequestJoinModalProps {
  group: Group;
  onClose: () => void;
}

export function RequestJoinModal({ group, onClose }: RequestJoinModalProps) {
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      
      // Close modal after showing success message
      setTimeout(() => {
        onClose();
      }, 2000);
    }, 1500);
  };
  
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div 
        className="bg-gradient-to-b from-indigo-950 to-purple-950 rounded-2xl w-full max-w-md overflow-hidden shadow-xl border border-indigo-500/30"
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        transition={{ duration: 0.3 }}
      >
        <div className="p-4 border-b border-indigo-500/30 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-indigo-100">Request to Join</h2>
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full text-indigo-300 hover:text-indigo-100 hover:bg-indigo-800/50"
            onClick={onClose}
            disabled={isSubmitting}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="p-6">
          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <h3 className="text-sm font-medium text-indigo-200 mb-2">
                  Introduce yourself to "{group.name}"
                </h3>
                <Textarea 
                  placeholder="Share a bit about yourself and why you'd like to join this group..."
                  className="resize-none h-32 bg-indigo-900/30 border-indigo-500/30 text-indigo-100 placeholder:text-indigo-400"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  disabled={isSubmitting}
                />
              </div>
              
              <div className="bg-indigo-800/30 rounded-xl p-4 border border-indigo-500/20">
                <p className="text-xs text-indigo-300">
                  Your request will be reviewed by the group members. You'll receive a notification once your request is approved.
                </p>
              </div>
              
              <div className="pt-2 flex justify-end gap-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={onClose} 
                  className="rounded-full border-indigo-500/50 text-indigo-300 hover:text-indigo-100 hover:bg-indigo-800/50"
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white"
                  disabled={!message.trim() || isSubmitting}
                >
                  {isSubmitting ? (
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 rounded-full border-2 border-t-transparent border-white animate-spin"></div>
                      <span>Sending...</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Send className="h-4 w-4" />
                      <span>Send Request</span>
                    </div>
                  )}
                </Button>
              </div>
            </form>
          ) : (
            <div className="py-8 flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mb-4">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.3, type: "spring" }}
                >
                  <svg className="w-8 h-8 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </motion.div>
              </div>
              <h3 className="text-lg font-medium text-indigo-100 mb-2">Request Sent!</h3>
              <p className="text-sm text-indigo-300 text-center">
                Your request to join "{group.name}" has been sent. You'll be notified when it's approved.
              </p>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
