
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { X, Users, Calendar, MessageSquare, Lock } from "lucide-react";
import { Group } from "@/components/singles-planet/PlanetView";

interface GroupPreviewModalProps {
  group: Group;
  onClose: () => void;
  onRequestJoin: () => void;
}

export function GroupPreviewModal({ group, onClose, onRequestJoin }: GroupPreviewModalProps) {
  const maleCount = group.members.filter(m => m.gender === "M").length;
  const femaleCount = group.members.filter(m => m.gender === "F").length;
  const isBalanced = maleCount >= 4 && femaleCount >= 4;
  
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div 
        className="bg-gradient-to-b from-indigo-950 to-purple-950 rounded-2xl w-full max-w-md overflow-hidden shadow-xl border border-indigo-500/30"
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        transition={{ duration: 0.3 }}
      >
        <div className="p-4 border-b border-indigo-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold">
              {group.name.substring(0, 2)}
            </div>
            <h2 className="text-xl font-semibold text-indigo-100">{group.name}</h2>
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full text-indigo-300 hover:text-indigo-100 hover:bg-indigo-800/50"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="p-6 space-y-6">
          {/* Group description */}
          <div className="bg-indigo-900/30 rounded-xl p-4 border border-indigo-500/20">
            <p className="text-indigo-100">{group.description}</p>
          </div>
          
          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {group.tags.map(tag => (
              <Badge key={tag.id} variant="outline" className="bg-indigo-800/50 text-indigo-200 border-indigo-500/30">
                {tag.icon} {tag.name}
              </Badge>
            ))}
          </div>
          
          {/* Members */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-indigo-200 flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span>Members ({group.members.length}/{group.maxMembers})</span>
              </h3>
              
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <div className="h-2 w-2 rounded-full bg-blue-400"></div>
                  <span className="text-xs text-blue-300">{maleCount}</span>
                </div>
                
                <div className="flex items-center gap-1">
                  <div className="h-2 w-2 rounded-full bg-pink-400"></div>
                  <span className="text-xs text-pink-300">{femaleCount}</span>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-5 gap-2">
              {group.members.slice(0, 10).map((member) => (
                <div key={member.id} className="flex flex-col items-center">
                  <Avatar className="h-10 w-10 border border-indigo-500/30">
                    <AvatarFallback className={member.gender === "M" ? "bg-blue-900/50" : "bg-pink-900/50"}>
                      {member.name[0]}
                    </AvatarFallback>
                    {member.avatar && <AvatarImage src={member.avatar} alt={member.name} />}
                  </Avatar>
                  <span className="text-xs text-indigo-300 mt-1 truncate w-full text-center">{member.name}</span>
                </div>
              ))}
              
              {group.members.length > 10 && (
                <div className="flex flex-col items-center">
                  <div className="h-10 w-10 rounded-full bg-indigo-800/50 border border-indigo-500/30 flex items-center justify-center text-indigo-200 text-xs">
                    +{group.members.length - 10}
                  </div>
                  <span className="text-xs text-indigo-300 mt-1">More</span>
                </div>
              )}
              
              {/* Blurred placeholders for remaining slots */}
              {Array.from({ length: Math.min(5, group.maxMembers - group.members.length) }).map((_, i) => (
                <div key={`empty-${i}`} className="flex flex-col items-center">
                  <div className="h-10 w-10 rounded-full bg-indigo-800/20 border border-indigo-500/10 flex items-center justify-center text-indigo-400/30 backdrop-blur-sm">
                    ?
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Group rules */}
          <div className="bg-indigo-800/30 rounded-xl p-4 border border-indigo-500/20">
            <h3 className="text-sm font-medium text-indigo-200 mb-2">Group Rules</h3>
            <p className="text-xs text-indigo-300">Min 4F / 4M to unlock full access to events and group chat.</p>
            
            {!isBalanced && (
              <div className="mt-2 text-xs text-yellow-300 flex items-center gap-1">
                <Lock className="h-3 w-3" />
                <span>Some features are locked until gender balance is achieved.</span>
              </div>
            )}
          </div>
          
          {/* Action buttons */}
          <div className="grid grid-cols-3 gap-3">
            <Button 
              variant="outline" 
              className={`rounded-xl border-indigo-500/30 ${isBalanced ? "text-indigo-200" : "text-indigo-400/50"}`}
              disabled={!isBalanced}
            >
              <div className="flex flex-col items-center gap-1">
                <Calendar className="h-5 w-5" />
                <span className="text-xs">View Events</span>
              </div>
            </Button>
            
            <Button 
              variant="outline" 
              className={`rounded-xl border-indigo-500/30 ${isBalanced ? "text-indigo-200" : "text-indigo-400/50"}`}
              disabled={!isBalanced}
            >
              <div className="flex flex-col items-center gap-1">
                <MessageSquare className="h-5 w-5" />
                <span className="text-xs">Group Chat</span>
              </div>
            </Button>
            
            <Button 
              variant="outline" 
              className="rounded-xl border-indigo-500/30 text-indigo-400/50"
              disabled={true}
            >
              <div className="flex flex-col items-center gap-1">
                <Lock className="h-5 w-5" />
                <span className="text-xs">Explore Members</span>
              </div>
            </Button>
          </div>
          
          {/* Join button */}
          <div className="pt-2">
            <Button 
              className="w-full rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white py-6"
              onClick={onRequestJoin}
            >
              Request to Join
            </Button>
            
            {!isBalanced && (
              <p className="text-xs text-center text-indigo-300 mt-2">
                Group not full yet. Some features locked until group completes.
              </p>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
