
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Group } from "@/components/singles-planet/PlanetView";
import { Users, ChevronRight } from "lucide-react";

interface GroupCardProps {
  group: Group;
  viewMode: "grid" | "list";
  onView: () => void;
  onRequestJoin: () => void;
}

export function GroupCard({ group, viewMode, onView, onRequestJoin }: GroupCardProps) {
  const maleCount = group.members.filter(m => m.gender === "M").length;
  const femaleCount = group.members.filter(m => m.gender === "F").length;
  const otherCount = group.members.filter(m => m.gender === "O").length;
  
  const getCompletionStatus = () => {
    if (maleCount >= 4 && femaleCount >= 4) {
      return "Gender balance achieved";
    } else {
      const malesNeeded = Math.max(0, 4 - maleCount);
      const femalesNeeded = Math.max(0, 4 - femaleCount);
      
      if (malesNeeded > 0 && femalesNeeded > 0) {
        return `Needs ${femalesNeeded} more F & ${malesNeeded} more M`;
      } else if (malesNeeded > 0) {
        return `Needs ${malesNeeded} more M`;
      } else {
        return `Needs ${femalesNeeded} more F`;
      }
    }
  };
  
  if (viewMode === "list") {
    return (
      <motion.div
        className="bg-indigo-900/40 border border-indigo-500/30 rounded-xl overflow-hidden shadow-lg"
        whileHover={{ y: -5, boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.2)" }}
        transition={{ duration: 0.2 }}
      >
        <div className="p-4 flex items-center gap-4">
          <div className="flex-shrink-0">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold">
              {group.name.substring(0, 2)}
            </div>
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-start">
              <h3 className="text-lg font-semibold text-indigo-100 truncate">{group.name}</h3>
              <div className="flex items-center gap-1 text-xs text-indigo-300">
                <Users className="h-3 w-3" />
                <span>{group.members.length}/{group.maxMembers}</span>
              </div>
            </div>
            
            <div className="mt-1 flex flex-wrap gap-1">
              {group.tags.map(tag => (
                <Badge key={tag.id} variant="outline" className="bg-indigo-800/50 text-indigo-200 border-indigo-500/30 text-xs">
                  {tag.icon} {tag.name}
                </Badge>
              ))}
            </div>
            
            <div className="mt-2 flex items-center justify-between">
              <p className="text-xs text-indigo-300">{getCompletionStatus()}</p>
              
              <div className="flex gap-2">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 rounded-full text-indigo-200 hover:text-indigo-100 hover:bg-indigo-700/50"
                  onClick={onView}
                >
                  <span className="text-xs">View</span>
                  <ChevronRight className="h-3 w-3 ml-1" />
                </Button>
                
                <Button 
                  size="sm" 
                  className="h-8 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white"
                  onClick={onRequestJoin}
                >
                  <span className="text-xs">Request to Join</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }
  
  return (
    <motion.div
      className="bg-indigo-900/40 border border-indigo-500/30 rounded-xl overflow-hidden shadow-lg"
      whileHover={{ y: -5, boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.2)" }}
      transition={{ duration: 0.2 }}
    >
      <div className="p-5">
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold">
              {group.name.substring(0, 2)}
            </div>
            <h3 className="text-lg font-semibold text-indigo-100">{group.name}</h3>
          </div>
          
          <div className="flex items-center gap-1 text-xs text-indigo-300 bg-indigo-800/50 px-2 py-1 rounded-full">
            <Users className="h-3 w-3" />
            <span>{group.members.length}/{group.maxMembers}</span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mb-4">
          {group.tags.map(tag => (
            <Badge key={tag.id} variant="outline" className="bg-indigo-800/50 text-indigo-200 border-indigo-500/30">
              {tag.icon} {tag.name}
            </Badge>
          ))}
        </div>
        
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-1">
            <div className="h-2 w-2 rounded-full bg-blue-400"></div>
            <div className="text-xs text-blue-300">{maleCount} Males</div>
            
            <div className="h-2 w-2 rounded-full bg-pink-400 ml-2"></div>
            <div className="text-xs text-pink-300">{femaleCount} Females</div>
            
            {otherCount > 0 && (
              <>
                <div className="h-2 w-2 rounded-full bg-purple-400 ml-2"></div>
                <div className="text-xs text-purple-300">{otherCount} Others</div>
              </>
            )}
          </div>
          
          <div className="w-full h-2 bg-indigo-800/50 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-blue-500 to-pink-500" 
              style={{ width: `${(group.members.length / group.maxMembers) * 100}%` }}
            ></div>
          </div>
        </div>
        
        <p className="text-xs text-indigo-300 mb-4">{getCompletionStatus()}</p>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="flex-1 rounded-full border-indigo-500/50 text-indigo-200 hover:text-indigo-100 hover:bg-indigo-800/50"
            onClick={onView}
          >
            View Details
          </Button>
          
          <Button 
            className="flex-1 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white"
            onClick={onRequestJoin}
          >
            Request to Join
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
