import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Bell, Search, Calendar, MessageSquare, Heart, Globe, Filter } from "lucide-react";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import { GroupCard } from "@/components/singles-planet/GroupCard";
import { GroupPreviewModal } from "@/components/singles-planet/GroupPreviewModal";
import { RequestJoinModal } from "@/components/singles-planet/RequestJoinModal";
import Link from "next/link";

interface GroupMember {
  id: string;
  name: string;
  gender: "M" | "F" | "O";
  avatar?: string;
}

interface GroupTag {
  id: string;
  name: string;
  icon: string;
}

export interface Group {
  id: string;
  name: string;
  members: GroupMember[];
  maxMembers: number;
  tags: GroupTag[];
  location: string;
  description: string;
  isComplete: boolean;
}

export function PlanetView() {
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [stars, setStars] = useState<Array<{ id: number; style: React.CSSProperties }>>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Sample groups data
  const groups: Group[] = [
    {
      id: "1",
      name: "Creative Hearts",
      members: [
        { id: "1", name: "Sarah", gender: "F", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80" },
        { id: "2", name: "Michael", gender: "M", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80" },
        { id: "3", name: "Aanya", gender: "F" },
        { id: "4", name: "Raj", gender: "M" },
        { id: "5", name: "Emma", gender: "F" },
        { id: "6", name: "David", gender: "M" },
        { id: "7", name: "Sophia", gender: "F" },
        { id: "8", name: "James", gender: "M" },
        { id: "9", name: "Olivia", gender: "F" },
        { id: "10", name: "Daniel", gender: "M" },
        { id: "11", name: "Mia", gender: "F" },
        { id: "12", name: "Alex", gender: "M" }
      ],
      maxMembers: 20,
      tags: [
        { id: "1", name: "Art", icon: "🎨" },
        { id: "2", name: "Music", icon: "🎵" },
        { id: "3", name: "Mumbai", icon: "📍" }
      ],
      location: "Mumbai",
      description: "A group for creative souls who love art, music, and meaningful connections.",
      isComplete: false
    },
    {
      id: "2",
      name: "Movie Nights Mumbai",
      members: [
        { id: "1", name: "Priya", gender: "F" },
        { id: "2", name: "Arjun", gender: "M" },
        { id: "3", name: "Neha", gender: "F" },
        { id: "4", name: "Vikram", gender: "M" },
        { id: "5", name: "Ananya", gender: "F" },
        { id: "6", name: "Rohan", gender: "M" },
        { id: "7", name: "Ishita", gender: "F" },
        { id: "8", name: "Karan", gender: "M" },
        { id: "9", name: "Zara", gender: "F" },
        { id: "10", name: "Aditya", gender: "M" }
      ],
      maxMembers: 20,
      tags: [
        { id: "1", name: "Movies", icon: "🎬" },
        { id: "2", name: "Cinema", icon: "🍿" },
        { id: "3", name: "Mumbai", icon: "📍" }
      ],
      location: "Mumbai",
      description: "Join us for weekly movie nights and discussions about cinema.",
      isComplete: false
    },
    {
      id: "3",
      name: "Deep Talks Delhi",
      members: [
        { id: "1", name: "Aarav", gender: "M" },
        { id: "2", name: "Meher", gender: "F" },
        { id: "3", name: "Kabir", gender: "M" },
        { id: "4", name: "Aisha", gender: "F" },
        { id: "5", name: "Veer", gender: "M" },
        { id: "6", name: "Diya", gender: "F" },
        { id: "7", name: "Rehan", gender: "M" },
        { id: "8", name: "Kiara", gender: "F" },
        { id: "9", name: "Aryan", gender: "M" },
        { id: "10", name: "Sanya", gender: "F" },
        { id: "11", name: "Vivaan", gender: "M" },
        { id: "12", name: "Anvi", gender: "F" },
        { id: "13", name: "Shaan", gender: "M" },
        { id: "14", name: "Myra", gender: "F" },
        { id: "15", name: "Advait", gender: "M" },
        { id: "16", name: "Riya", gender: "F" }
      ],
      maxMembers: 20,
      tags: [
        { id: "1", name: "Theatre", icon: "🎭" },
        { id: "2", name: "Café Meetups", icon: "☕" },
        { id: "3", name: "Delhi", icon: "📍" }
      ],
      location: "Delhi",
      description: "For those who enjoy deep conversations, theatre, and cozy café meetups.",
      isComplete: false
    }
  ];
  
  // Generate stars for the background
  useEffect(() => {
    const generateStar = () => {
      const id = Date.now() + Math.random() * 1000;
      const left = Math.random() * 100;
      const top = Math.random() * 100;
      const size = 1 + Math.random() * 3;
      const opacity = 0.3 + Math.random() * 0.7;
      const animationDuration = 2 + Math.random() * 4;
      
      return {
        id,
        style: {
          left: `${left}%`,
          top: `${top}%`,
          width: `${size}px`,
          height: `${size}px`,
          opacity,
          animationDuration: `${animationDuration}s`
        }
      };
    };
    
    // Generate initial stars
    const initialStars = Array.from({ length: 100 }, generateStar);
    setStars(initialStars);
  }, []);
  
  const handleOpenGroup = (group: Group) => {
    setSelectedGroup(group);
  };
  
  const handleCloseGroup = () => {
    setSelectedGroup(null);
  };
  
  const handleRequestJoin = (group: Group) => {
    setSelectedGroup(group);
    setShowRequestModal(true);
  };
  
  const handleCloseRequestModal = () => {
    setShowRequestModal(false);
  };
  
  const countGenderDistribution = (members: GroupMember[]) => {
    const males = members.filter(m => m.gender === "M").length;
    const females = members.filter(m => m.gender === "F").length;
    return { males, females };
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-950 via-purple-900 to-indigo-900 flex flex-col pb-20">
      {/* Top Bar */}
      <header className="w-full py-3 px-4 sm:px-6 flex items-center justify-between bg-indigo-950/30 backdrop-blur-sm border-b border-indigo-500/20">
        <Link href="/singles/home">
          <Button variant="ghost" size="icon" className="rounded-full text-indigo-200 hover:bg-indigo-800/50">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </Button>
        </Link>
        
        <div className="flex flex-col items-center">
          <h1 className="text-xl sm:text-2xl font-bold text-indigo-100 tracking-wide flex items-center gap-2">
            Planet
            <motion.div
              animate={{ 
                rotate: [0, 360],
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                rotate: { duration: 20, repeat: Infinity, ease: "linear" },
                scale: { duration: 2, repeat: Infinity, repeatType: "reverse" }
              }}
            >
              <Globe className="h-5 w-5 text-indigo-300" />
            </motion.div>
          </h1>
          <div className="flex items-center gap-1">
            <LitAmorLogo size="small" />
            <span className="text-xs text-indigo-300">Lit Amor</span>
          </div>
        </div>
        
        <Button variant="ghost" size="icon" className="rounded-full text-indigo-200 hover:bg-indigo-800/50 relative">
          <Bell className="h-5 w-5" />
          <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-pink-500"></span>
          <span className="sr-only">Notifications</span>
        </Button>
      </header>
      
      {/* Search Bar */}
      <div className="w-full py-3 px-4 sm:px-6 bg-indigo-950/20 backdrop-blur-sm border-b border-indigo-500/20">
        <div className="relative max-w-md mx-auto">
          <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-indigo-300" />
          </div>
          <input
            type="text"
            placeholder="Search groups by interest, location..."
            className="w-full bg-indigo-900/30 border border-indigo-500/30 text-indigo-100 placeholder:text-indigo-400 rounded-full py-2 pl-10 pr-12 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
          />
          <Button variant="ghost" size="icon" className="absolute inset-y-0 right-1 rounded-full text-indigo-300 hover:bg-indigo-800/50">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 relative overflow-hidden">
        {/* Stars background */}
        <div className="absolute inset-0 overflow-hidden">
          {stars.map((star) => (
            <div
              key={star.id}
              className="absolute rounded-full bg-white animate-twinkle"
              style={star.style}
            />
          ))}
          
          {/* Nebula effects */}
          <div className="absolute top-[20%] left-[10%] w-48 h-48 sm:w-64 sm:h-64 rounded-full bg-pink-500/10 blur-3xl" />
          <div className="absolute bottom-[30%] right-[15%] w-56 h-56 sm:w-80 sm:h-80 rounded-full bg-indigo-500/10 blur-3xl" />
          <div className="absolute top-[60%] left-[30%] w-52 h-52 sm:w-72 sm:h-72 rounded-full bg-purple-500/10 blur-3xl" />
          
          {/* Orbit paths - hidden on mobile */}
          <div className="hidden sm:flex absolute inset-0 items-center justify-center opacity-20 pointer-events-none">
            <div className="w-[500px] h-[500px] rounded-full border border-indigo-500/30" />
            <div className="absolute w-[400px] h-[400px] rounded-full border border-indigo-500/30" />
            <div className="absolute w-[300px] h-[300px] rounded-full border border-indigo-500/30" />
          </div>
          
          {/* Floating hearts & comets */}
          <motion.div
            className="absolute top-[15%] left-[25%] text-pink-500/20"
            animate={{ 
              y: [0, -20, 0],
              x: [0, 10, 0],
              rotate: [0, 10, 0]
            }}
            transition={{ 
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Heart size={24} />
          </motion.div>
          
          <motion.div
            className="absolute bottom-[25%] right-[20%] text-indigo-500/20"
            animate={{ 
              y: [0, 15, 0],
              x: [0, -10, 0],
              rotate: [0, -5, 0]
            }}
            transition={{ 
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1
            }}
          >
            <Heart size={32} />
          </motion.div>
        </div>
        
        {/* View Toggle */}
        <div className="sticky top-0 z-10 w-full py-2 px-4 sm:px-6 flex justify-end bg-indigo-950/50 backdrop-blur-sm">
          <div className="flex items-center gap-2 bg-indigo-900/50 rounded-full p-1">
            <Button 
              variant={viewMode === "grid" ? "default" : "ghost"} 
              size="sm" 
              className={`rounded-full px-3 text-xs ${viewMode === "grid" ? "bg-indigo-700 text-white" : "text-indigo-200 hover:bg-indigo-800/50"}`}
              onClick={() => setViewMode("grid")}
            >
              Grid
            </Button>
            <Button 
              variant={viewMode === "list" ? "default" : "ghost"} 
              size="sm" 
              className={`rounded-full px-3 text-xs ${viewMode === "list" ? "bg-indigo-700 text-white" : "text-indigo-200 hover:bg-indigo-800/50"}`}
              onClick={() => setViewMode("list")}
            >
              List
            </Button>
          </div>
        </div>
        
        {/* Group Cards */}
        <div className="relative z-0 p-4 sm:p-6">
          <div className={`grid ${viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"} gap-4 sm:gap-6`}>
            {groups.map((group) => (
              <GroupCard 
                key={group.id}
                group={group}
                viewMode={viewMode}
                onView={() => handleOpenGroup(group)}
                onRequestJoin={() => handleRequestJoin(group)}
              />
            ))}
          </div>
        </div>
      </div>
      
      {/* Group Preview Modal */}
      <AnimatePresence>
        {selectedGroup && !showRequestModal && (
          <GroupPreviewModal 
            group={selectedGroup} 
            onClose={handleCloseGroup}
            onRequestJoin={() => setShowRequestModal(true)}
          />
        )}
      </AnimatePresence>
      
      {/* Request Join Modal */}
      <AnimatePresence>
        {selectedGroup && showRequestModal && (
          <RequestJoinModal 
            group={selectedGroup}
            onClose={handleCloseRequestModal}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
