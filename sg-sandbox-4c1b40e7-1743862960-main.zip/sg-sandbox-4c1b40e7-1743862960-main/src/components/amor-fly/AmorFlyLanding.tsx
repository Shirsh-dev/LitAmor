
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Plane,
  BookOpen, 
  Music, 
  Camera, 
  Code, 
  Dumbbell,
  Palette,
  Users,
  Shield,
  Clock,
  Sparkles
} from "lucide-react";

interface AmorFlyLandingProps {
  onGetStarted?: () => void;
}

export function AmorFlyLanding({ onGetStarted }: AmorFlyLandingProps) {
  const features = [
    {
      icon: Users,
      title: "Interest-Based Matching",
      description: "Connect with someone who shares your exact major interest"
    },
    {
      icon: Shield,
      title: "Photo-Free Experience",
      description: "Focus on personality and shared passions, not appearances"
    },
    {
      icon: Clock,
      title: "24-Hour Connections",
      description: "Each match lasts 24 hours, then disappears forever"
    }
  ];

  const interests = [
    { name: "Reading", icon: BookOpen, color: "from-blue-400 to-blue-600" },
    { name: "Music", icon: Music, color: "from-purple-400 to-purple-600" },
    { name: "Photography", icon: Camera, color: "from-green-400 to-green-600" },
    { name: "Programming", icon: Code, color: "from-orange-400 to-orange-600" },
    { name: "Fitness", icon: Dumbbell, color: "from-red-400 to-red-600" },
    { name: "Art & Design", icon: Palette, color: "from-pink-400 to-pink-600" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-50 pb-24">
      {/* Header */}
      <header className="w-full py-4 px-4">
        <div className="max-w-6xl mx-auto flex items-center gap-3">
          <Plane className="w-8 h-8 text-blue-500" />
          <div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              AmorFly
            </h1>
            <p className="text-xs text-gray-500">by Lit Amor</p>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-12 px-4 text-center relative overflow-hidden">
        <div className="max-w-3xl mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Badge className="mb-3 bg-blue-100 text-blue-700">
              Photo-free • Interest-based • 24-hour connections
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4 leading-tight">
              Connect through
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-indigo-600"> Curiosity</span>
            </h2>
            <p className="text-lg text-gray-600 mb-6 max-w-xl mx-auto">
              Meet one person daily who shares your passion. No photos, no filters—just genuine exploration.
            </p>
            <Button 
              size="lg" 
              onClick={onGetStarted}
              className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white font-medium px-8 py-4 rounded-full shadow-lg"
            >
              Start Exploring
            </Button>
            <p className="text-sm text-gray-500 mt-3">
              One match per day • Free forever
            </p>
          </motion.div>
        </div>

        {/* Floating icons background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[BookOpen, Music, Camera, Code, Palette, Sparkles].map((Icon, index) => (
            <motion.div
              key={index}
              className="absolute text-gray-200"
              style={{
                top: `${20 + (index * 12)}%`,
                left: `${10 + (index * 15)}%`,
              }}
              animate={{
                y: [0, -15, 0],
                opacity: [0.2, 0.5, 0.2]
              }}
              transition={{
                duration: 3 + index,
                repeat: Infinity,
                ease: "easeInOut",
                delay: index * 0.3
              }}
            >
              <Icon size={28 + index * 3} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className="py-12 px-4">
        <div className="max-w-5xl mx-auto">
          <h3 className="text-2xl font-bold text-gray-800 text-center mb-8">How It Works</h3>
          
          <div className="grid md:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.15 }}
                  viewport={{ once: true }}
                >
                  <Card className="text-center p-6 bg-white/80 backdrop-blur-sm border-blue-200">
                    <div className="w-14 h-14 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Icon className="text-blue-600" size={28} />
                    </div>
                    <h4 className="text-lg font-semibold text-gray-800 mb-2">{feature.title}</h4>
                    <p className="text-gray-600 text-sm">{feature.description}</p>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Interests */}
      <section className="py-12 px-4">
        <div className="max-w-5xl mx-auto">
          <h3 className="text-2xl font-bold text-gray-800 text-center mb-4">Explore Through Interests</h3>
          <p className="text-center text-gray-600 mb-8 max-w-2xl mx-auto">
            Choose your major interest and connect with someone who shares your passion
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {interests.map((interest, index) => {
              const Icon = interest.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.08 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.03 }}
                >
                  <Card className="p-5 bg-white/80 backdrop-blur-sm border-blue-200 hover:shadow-md transition-all">
                    <div className={`w-10 h-10 bg-gradient-to-br ${interest.color} rounded-full flex items-center justify-center mb-3`}>
                      <Icon className="text-white" size={20} />
                    </div>
                    <h4 className="font-medium text-gray-800 text-sm">{interest.name}</h4>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 px-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white text-center">
        <div className="max-w-3xl mx-auto">
          <Plane className="w-12 h-12 mx-auto mb-4" />
          <h3 className="text-3xl font-bold mb-3">Ready to Fly?</h3>
          <p className="text-lg mb-6 opacity-90">
            Start exploring through curiosity today
          </p>
          <Button 
            size="lg" 
            onClick={onGetStarted}
            className="bg-white text-blue-600 hover:bg-gray-100 font-medium px-8 py-4 rounded-full shadow-lg"
          >
            Get Started Free
          </Button>
        </div>
      </section>
    </div>
  );
}
