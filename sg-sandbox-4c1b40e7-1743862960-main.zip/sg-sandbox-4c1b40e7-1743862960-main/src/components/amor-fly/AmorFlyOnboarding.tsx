
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Plane, Heart, Sparkles, ChevronRight, ChevronLeft, AlertCircle } from "lucide-react";
import { AMOR_FLY_INTERESTS, validateAmorFlySetup, AmorFlyUser } from "@/types/amorFly";

interface AmorFlyOnboardingProps {
  onComplete: (userData: Partial<AmorFlyUser>) => void;
  onSkip?: () => void;
}

export function AmorFlyOnboarding({ onComplete, onSkip }: AmorFlyOnboardingProps) {
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    profession: "",
    lifeGoals: "",
    majorInterest: "",
    minorInterests: [] as string[],
    whyILoveIt: ""
  });
  const [errors, setErrors] = useState<string[]>([]);

  const totalSteps = 4;
  const progress = ((step + 1) / totalSteps) * 100;

  const handleFieldChange = (field: string, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setErrors([]);
  };

  const handleMajorInterestSelect = (interest: string) => {
    handleFieldChange("majorInterest", interest);
    setErrors([]);
    
    // Auto-advance to next step after selecting major interest
    setTimeout(() => {
      setStep(3);
    }, 300);
  };

  const handleMinorInterestToggle = (interest: string) => {
    const currentMinor = formData.minorInterests;
    
    if (currentMinor.includes(interest)) {
      handleFieldChange("minorInterests", currentMinor.filter(i => i !== interest));
    } else if (currentMinor.length < 4) {
      handleFieldChange("minorInterests", [...currentMinor, interest]);
    }
  };

  const validateCurrentStep = (): boolean => {
    const newErrors: string[] = [];

    if (step === 0) {
      if (!formData.name || formData.name.trim().length < 2) {
        newErrors.push("Name must be at least 2 characters");
      }
      const age = parseInt(formData.age);
      if (!formData.age || age < 18 || age > 100) {
        newErrors.push("Age must be between 18 and 100");
      }
    }

    if (step === 1) {
      if (!formData.profession || formData.profession.trim().length < 2) {
        newErrors.push("Profession is required");
      }
      if (!formData.lifeGoals || formData.lifeGoals.trim().length < 10) {
        newErrors.push("Life goals must be at least 10 characters");
      }
    }

    if (step === 2) {
      if (!formData.majorInterest) {
        newErrors.push("Please select your major interest");
      }
    }

    if (step === 3) {
      if (formData.minorInterests.length !== 4) {
        newErrors.push("Please select exactly 4 minor interests");
      }
      if (formData.minorInterests.includes(formData.majorInterest)) {
        newErrors.push("Minor interests cannot include your major interest");
      }
    }

    setErrors(newErrors);
    return newErrors.length === 0;
  };

  const handleNext = () => {
    if (!validateCurrentStep()) return;

    if (step < totalSteps - 1) {
      setStep(prev => prev + 1);
    } else {
      const validation = validateAmorFlySetup(
        formData.majorInterest,
        formData.minorInterests,
        formData.name,
        parseInt(formData.age),
        formData.profession,
        formData.lifeGoals
      );

      if (validation.isValid) {
        onComplete({
          name: formData.name,
          age: parseInt(formData.age),
          profession: formData.profession,
          lifeGoals: formData.lifeGoals,
          majorInterest: formData.majorInterest,
          minorInterests: formData.minorInterests,
          whyILoveIt: formData.whyILoveIt,
          flyStatus: "OFF",
          recentMatchUserIds: [],
          firstAmorFlyOnboardShown: true
        });
      } else {
        setErrors(validation.errors);
      }
    }
  };

  const handleBack = () => {
    if (step > 0) {
      setStep(prev => prev - 1);
      setErrors([]);
    }
  };

  const availableMinorInterests = AMOR_FLY_INTERESTS.filter(
    interest => interest !== formData.majorInterest
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Plane className="w-10 h-10 text-blue-500" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              AmorFly
            </h1>
          </div>
          <p className="text-gray-600 text-lg">
            Connect through shared interests. Learn. Explore. Grow.
          </p>
        </motion.div>

        {errors.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <Alert className="bg-red-50 border-red-200">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                <ul className="list-disc list-inside space-y-1">
                  {errors.map((error, idx) => (
                    <li key={idx}>{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          </motion.div>
        )}

        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-600">
              Step {step + 1} of {totalSteps}
            </span>
            <span className="text-sm text-blue-600 font-medium">
              {Math.round(progress)}% Complete
            </span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-blue-500 to-indigo-500"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="bg-white/80 backdrop-blur-sm border-blue-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-gray-800">
                  {step === 0 && (
                    <>
                      <Heart className="w-5 h-5 text-blue-500" />
                      Tell us about yourself
                    </>
                  )}
                  {step === 1 && (
                    <>
                      <Sparkles className="w-5 h-5 text-blue-500" />
                      Your aspirations
                    </>
                  )}
                  {step === 2 && (
                    <>
                      <Plane className="w-5 h-5 text-blue-500" />
                      Choose your Major Interest
                    </>
                  )}
                  {step === 3 && (
                    <>
                      <Sparkles className="w-5 h-5 text-blue-500" />
                      Select Minor Interests
                    </>
                  )}
                </CardTitle>
                <CardDescription className="text-gray-600">
                  {step === 0 && "Basic information to help us connect you with the right people"}
                  {step === 1 && "Share what drives you and what you're working towards"}
                  {step === 2 && "This will be your primary matching criteria - choose what you're most passionate about"}
                  {step === 3 && "Pick 4 more interests to enrich your connections"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {step === 0 && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-gray-700">Your Name</Label>
                      <Input
                        id="name"
                        type="text"
                        value={formData.name}
                        onChange={(e) => handleFieldChange("name", e.target.value)}
                        placeholder="Enter your name"
                        className="border-blue-200 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="age" className="text-gray-700">Your Age</Label>
                      <Input
                        id="age"
                        type="number"
                        value={formData.age}
                        onChange={(e) => handleFieldChange("age", e.target.value)}
                        placeholder="Enter your age"
                        min="18"
                        max="100"
                        className="border-blue-200 focus:ring-blue-500"
                      />
                    </div>
                  </>
                )}

                {step === 1 && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="profession" className="text-gray-700">Profession</Label>
                      <Input
                        id="profession"
                        type="text"
                        value={formData.profession}
                        onChange={(e) => handleFieldChange("profession", e.target.value)}
                        placeholder="e.g., Software Engineer, Teacher, Student"
                        className="border-blue-200 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lifeGoals" className="text-gray-700">Life Goals</Label>
                      <Textarea
                        id="lifeGoals"
                        value={formData.lifeGoals}
                        onChange={(e) => handleFieldChange("lifeGoals", e.target.value)}
                        placeholder="What are you working towards? What drives you?"
                        rows={4}
                        className="border-blue-200 focus:ring-blue-500 resize-none"
                      />
                      <p className="text-xs text-gray-500">
                        Share your aspirations, dreams, or what keeps you motivated
                      </p>
                    </div>
                  </>
                )}

                {step === 2 && (
                  <div className="space-y-4">
                    <p className="text-sm text-gray-600 bg-blue-50 p-3 rounded-lg border border-blue-200">
                      <strong>Your Major Interest</strong> is what you'll be matched on. Choose something you're truly passionate about and would love to discuss with others!
                    </p>
                    <div className="grid grid-cols-2 gap-3">
                      {AMOR_FLY_INTERESTS.map((interest) => (
                        <Badge
                          key={interest}
                          variant={formData.majorInterest === interest ? "default" : "outline"}
                          className={`cursor-pointer transition-all text-center py-3 ${
                            formData.majorInterest === interest
                              ? "bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-md"
                              : "border-blue-300 text-gray-700 hover:border-blue-500 hover:bg-blue-50"
                          }`}
                          onClick={() => handleMajorInterestSelect(interest)}
                        >
                          {interest}
                        </Badge>
                      ))}
                    </div>
                    <p className="text-xs text-gray-500 text-center pt-2">
                      Click on an interest to select and continue
                    </p>
                  </div>
                )}

                {step === 3 && (
                  <div className="space-y-4">
                    <div className="bg-blue-50 p-3 rounded-lg border border-blue-200 space-y-2">
                      <p className="text-sm text-gray-700">
                        <strong>Select exactly 4 minor interests</strong> to add depth to your profile
                      </p>
                      <p className="text-xs text-gray-600">
                        Selected: {formData.minorInterests.length}/4
                      </p>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      {availableMinorInterests.map((interest) => {
                        const isSelected = formData.minorInterests.includes(interest);
                        const canSelect = formData.minorInterests.length < 4 || isSelected;
                        
                        return (
                          <Badge
                            key={interest}
                            variant={isSelected ? "default" : "outline"}
                            className={`cursor-pointer transition-all text-center py-3 ${
                              isSelected
                                ? "bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-md"
                                : canSelect
                                ? "border-blue-300 text-gray-700 hover:border-blue-500 hover:bg-blue-50"
                                : "border-gray-300 text-gray-400 cursor-not-allowed opacity-50"
                            }`}
                            onClick={() => canSelect && handleMinorInterestToggle(interest)}
                          >
                            {interest}
                          </Badge>
                        );
                      })}
                    </div>
                    <div className="space-y-2 pt-4 border-t">
                      <Label htmlFor="whyILoveIt" className="text-gray-700">
                        Why you love {formData.majorInterest || "your major interest"} (Optional)
                      </Label>
                      <Input
                        id="whyILoveIt"
                        type="text"
                        value={formData.whyILoveIt}
                        onChange={(e) => handleFieldChange("whyILoveIt", e.target.value)}
                        placeholder="One line about why this interest matters to you"
                        className="border-blue-200 focus:ring-blue-500"
                        maxLength={100}
                      />
                      <p className="text-xs text-gray-500">
                        This will be shown to your matches
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        <div className="flex justify-between items-center mt-6">
          <Button
            variant="ghost"
            onClick={handleBack}
            disabled={step === 0}
            className="text-gray-600"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <div className="flex gap-2">
            {onSkip && step === 0 && (
              <Button
                variant="ghost"
                onClick={onSkip}
                className="text-gray-600"
              >
                Skip for now
              </Button>
            )}
            
            <Button
              onClick={handleNext}
              className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
            >
              {step === totalSteps - 1 ? "Complete Setup" : "Next"}
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
