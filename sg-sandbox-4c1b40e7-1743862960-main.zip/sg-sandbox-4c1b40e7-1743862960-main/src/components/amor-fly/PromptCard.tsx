
import { motion } from "framer-motion";
import { Textarea } from "@/components/ui/textarea";
import { PenLine } from "lucide-react";

interface PromptCardProps {
  question: string;
  answer: string;
  onChange: (answer: string) => void;
}

export function PromptCard({ question, answer, onChange }: PromptCardProps) {
  return (
    <motion.div
      className="bg-white/80 backdrop-blur-sm rounded-xl p-4 border border-lavender-200 shadow-sm"
      whileHover={{ y: -2, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-start gap-3">
        <div className="mt-1 bg-lavender-100 rounded-full p-2 text-lavender-500">
          <PenLine className="h-4 w-4" />
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-medium text-gray-700 mb-2">{question}</h3>
          <Textarea
            placeholder="Share your thoughts..."
            value={answer}
            onChange={(e) => onChange(e.target.value)}
            className="resize-none h-20 bg-white/50 border-lavender-200 focus-visible:ring-lavender-400 text-gray-700"
          />
        </div>
      </div>
      
      {/* Decorative sparkles */}
      <div className="absolute -top-1 -right-1 pointer-events-none">
        {Array.from({ length: 3 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-gold-300"
            initial={{
              x: 0,
              y: 0,
              opacity: 0.7,
            }}
            animate={{
              x: (Math.random() - 0.5) * 20,
              y: (Math.random() - 0.5) * 20,
              opacity: 0,
              scale: [1, 1.5, 0],
            }}
            transition={{
              duration: 1 + Math.random(),
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>
    </motion.div>
  );
}
