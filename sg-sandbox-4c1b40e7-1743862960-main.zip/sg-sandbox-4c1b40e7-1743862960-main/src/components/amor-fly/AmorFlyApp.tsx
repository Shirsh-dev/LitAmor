
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Plane, 
  Clock, 
  MessageCircle, 
  Phone, 
  AlertCircle, 
  Sparkles,
  Heart,
  Settings,
  User
} from "lucide-react";
import { 
  AmorFlyUser, 
  AmorFlyMatch, 
  AmorFlyMatchDisplay,
  AMOR_FLY_INTERESTS 
} from "@/types/amorFly";
import { 
  getTimeUntilExpiry, 
  isMatchExpired,
  getRandomChatPrompt 
} from "@/lib/amorFlyMatching";

interface AmorFlyAppProps {
  user: AmorFlyUser;
  currentMatch?: AmorFlyMatch;
  matchedUser?: AmorFlyUser;
  onToggleFlyStatus: (status: "ON" | "OFF") => void;
  onOpenChat: (matchId: string) => void;
  onOpenSettings: () => void;
}

export function AmorFlyApp({
  user,
  currentMatch,
  matchedUser,
  onToggleFlyStatus,
  onOpenChat,
  onOpenSettings
}: AmorFlyAppProps) {
  const [timeRemaining, setTimeRemaining] = useState({ hours: 0, minutes: 0, expired: false });
  const [chatPrompt] = useState(getRandomChatPrompt());

  useEffect(() => {
    if (currentMatch) {
      const updateTimer = () => {
        const time = getTimeUntilExpiry(currentMatch);
        setTimeRemaining(time);
        
        if (time.expired) {
          return;
        }
      };

      updateTimer();
      const interval = setInterval(updateTimer, 60000);

      return () => clearInterval(interval);
    }
  }, [currentMatch]);

  const hasActiveMatch = currentMatch && !isMatchExpired(currentMatch);

  const handleChatClick = () => {
    if (currentMatch) {
      onOpenChat(currentMatch.id);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <Plane className="w-8 h-8 text-blue-500" />
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                AmorFly
              </h1>
              <p className="text-sm text-gray-600">
                Connect through shared interests
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onOpenSettings}
            className="text-gray-600 hover:text-blue-600"
          >
            <Settings className="w-5 h-5" />
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-white/80 backdrop-blur-sm border-blue-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5 text-blue-500" />
                  Your Profile
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Label htmlFor="fly-status" className="text-sm font-medium text-gray-700">
                    Ready to Fly
                  </Label>
                  <Switch
                    id="fly-status"
                    checked={user.flyStatus === "ON"}
                    onCheckedChange={(checked) => onToggleFlyStatus(checked ? "ON" : "OFF")}
                    disabled={hasActiveMatch}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Name</p>
                  <p className="font-medium text-gray-800">{user.name}, {user.age}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Profession</p>
                  <p className="font-medium text-gray-800">{user.profession}</p>
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-600 mb-2">Life Goals</p>
                <p className="text-gray-800">{user.lifeGoals}</p>
              </div>

              <div>
                <p className="text-sm text-gray-600 mb-2">Major Interest</p>
                <Badge className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
                  {user.majorInterest}
                </Badge>
              </div>

              <div>
                <p className="text-sm text-gray-600 mb-2">Minor Interests</p>
                <div className="flex flex-wrap gap-2">
                  {user.minorInterests.map((interest) => (
                    <Badge key={interest} variant="outline" className="border-blue-300 text-gray-700">
                      {interest}
                    </Badge>
                  ))}
                </div>
              </div>

              {user.whyILoveIt && (
                <div>
                  <p className="text-sm text-gray-600 mb-1">Why I love {user.majorInterest}</p>
                  <p className="text-gray-800 italic">"{user.whyILoveIt}"</p>
                </div>
              )}

              {hasActiveMatch && (
                <Alert className="bg-amber-50 border-amber-200">
                  <AlertCircle className="h-4 w-4 text-amber-600" />
                  <AlertDescription className="text-amber-800">
                    You cannot toggle "Ready to Fly" while you have an active match
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {user.flyStatus === "OFF" && !hasActiveMatch && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Alert className="bg-blue-50 border-blue-200">
              <Sparkles className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                <strong>Toggle "Ready to Fly" ON</strong> to start receiving daily matches based on your major interest!
              </AlertDescription>
            </Alert>
          </motion.div>
        )}

        {user.flyStatus === "ON" && !hasActiveMatch && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gradient-to-br from-blue-100 to-indigo-100 border-blue-300">
              <CardContent className="py-12 text-center space-y-4">
                <motion.div
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
                >
                  <Plane className="w-16 h-16 text-blue-600 mx-auto" />
                </motion.div>
                <h3 className="text-2xl font-bold text-gray-800">Ready to Fly!</h3>
                <p className="text-gray-700 max-w-md mx-auto">
                  You're in the matchmaking queue. We'll connect you with someone who shares your passion for <strong>{user.majorInterest}</strong> within the next 24 hours.
                </p>
                <p className="text-sm text-gray-600">
                  Check back soon to meet your match!
                </p>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {hasActiveMatch && matchedUser && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-300">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Heart className="w-5 h-5 text-pink-500" />
                    Your Match
                  </span>
                  <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                    <Clock className="w-3 h-3 mr-1" />
                    {timeRemaining.hours}h {timeRemaining.minutes}m left
                  </Badge>
                </CardTitle>
                <CardDescription className="text-gray-600">
                  Connected through shared interest in <strong>{currentMatch.sharedMajorInterest}</strong>
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-white/60 backdrop-blur-sm p-4 rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-gray-800">
                        {matchedUser.name}, {matchedUser.age}
                      </h3>
                      <p className="text-sm text-gray-600">{matchedUser.profession}</p>
                    </div>
                    <Badge className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
                      {currentMatch.matchScope}
                    </Badge>
                  </div>

                  <div>
                    <p className="text-sm text-gray-600 mb-1">Life Goals</p>
                    <p className="text-gray-800">{matchedUser.lifeGoals}</p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-600 mb-2">Interests</p>
                    <div className="flex flex-wrap gap-2">
                      <Badge className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
                        {matchedUser.majorInterest}
                      </Badge>
                      {matchedUser.minorInterests.map((interest) => (
                        <Badge 
                          key={interest} 
                          variant="outline"
                          className={
                            currentMatch.overlappingMinorInterests.includes(interest)
                              ? "border-green-400 bg-green-50 text-green-700"
                              : "border-blue-300 text-gray-700"
                          }
                        >
                          {interest}
                          {currentMatch.overlappingMinorInterests.includes(interest) && (
                            <Sparkles className="w-3 h-3 ml-1 inline" />
                          )}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {matchedUser.whyILoveIt && (
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Why they love {matchedUser.majorInterest}</p>
                      <p className="text-gray-800 italic">"{matchedUser.whyILoveIt}"</p>
                    </div>
                  )}
                </div>

                <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-lg border border-purple-200">
                  <p className="text-sm text-gray-600 mb-2">Conversation Starter</p>
                  <p className="text-gray-800 font-medium italic">"{chatPrompt}"</p>
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={handleChatClick}
                    className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Open Chat
                  </Button>
                  <Button
                    onClick={handleChatClick}
                    variant="outline"
                    className="border-blue-300 text-blue-600 hover:bg-blue-50"
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    Voice Call
                  </Button>
                </div>

                <Alert className="bg-amber-50 border-amber-200">
                  <Clock className="h-4 w-4 text-amber-600" />
                  <AlertDescription className="text-amber-800 text-sm">
                    This match will expire in <strong>{timeRemaining.hours}h {timeRemaining.minutes}m</strong>. 
                    Chat and voice calls will be permanently deleted. No reconnection possible.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {!hasActiveMatch && currentMatch && isMatchExpired(currentMatch) && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Alert className="bg-gray-50 border-gray-300">
              <AlertCircle className="h-4 w-4 text-gray-600" />
              <AlertDescription className="text-gray-700">
                Your previous match has expired. Toggle "Ready to Fly" to get matched again!
              </AlertDescription>
            </Alert>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-center text-sm text-gray-500 space-y-2"
        >
          <p>
            ✨ One match per day • 24-hour connection • No photos, just curiosity
          </p>
          <p className="text-xs">
            AmorFly is designed for exploration and learning, not romance
          </p>
        </motion.div>
      </div>
    </div>
  );
}
