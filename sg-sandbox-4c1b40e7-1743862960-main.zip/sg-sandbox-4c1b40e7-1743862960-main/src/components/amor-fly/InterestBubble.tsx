
import { motion } from "framer-motion";

interface InterestBubbleProps {
  icon: string;
  name: string;
  selected: boolean;
  onClick: () => void;
}

export function InterestBubble({ icon, name, selected, onClick }: InterestBubbleProps) {
  return (
    <motion.div
      className={`flex flex-col items-center gap-2 cursor-pointer transition-all duration-300 ${
        selected ? "scale-110" : "opacity-70 hover:opacity-90"
      }`}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
    >
      <div 
        className={`w-16 h-16 rounded-full flex items-center justify-center shadow-md ${
          selected 
            ? "bg-gradient-to-br from-lavender-400 to-pink-400 text-white" 
            : "bg-white text-gray-700"
        }`}
      >
        <motion.div
          animate={selected ? {
            y: [0, -3, 0],
            scale: [1, 1.1, 1]
          } : {}}
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatType: "reverse"
          }}
          className="text-2xl"
        >
          {icon}
        </motion.div>
      </div>
      <span className={`text-xs font-medium ${selected ? "text-gray-800" : "text-gray-600"}`}>
        {name}
      </span>
      {selected && (
        <motion.div
          className="absolute inset-0 pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            {Array.from({ length: 5 }).map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 rounded-full bg-pink-300"
                initial={{
                  x: 0,
                  y: 0,
                  opacity: 0.7,
                }}
                animate={{
                  x: (Math.random() - 0.5) * 30,
                  y: (Math.random() - 0.5) * 30,
                  opacity: 0,
                  scale: [1, 1.5, 0],
                }}
                transition={{
                  duration: 1 + Math.random(),
                  repeat: Infinity,
                  delay: Math.random() * 2,
                }}
              />
            ))}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
