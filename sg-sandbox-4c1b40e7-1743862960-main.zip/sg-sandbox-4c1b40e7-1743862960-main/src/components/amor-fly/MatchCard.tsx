
import { motion } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Send, Lock } from "lucide-react";

interface MatchCardProps {
  name: string;
  age: number;
  avatar: string;
  interests: string[];
  promptAnswer: string;
}

export function MatchCard({ name, age, avatar, interests, promptAnswer }: MatchCardProps) {
  return (
    <motion.div
      className="bg-white/80 backdrop-blur-sm rounded-xl overflow-hidden border border-lavender-200 shadow-sm"
      whileHover={{ y: -3, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
      transition={{ duration: 0.2 }}
    >
      <div className="p-4 flex items-center gap-3">
        <Avatar className="h-12 w-12 border-2 border-lavender-200">
          <AvatarFallback>{name[0]}</AvatarFallback>
          <AvatarImage src={avatar} alt={name} />
        </Avatar>
        
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <h3 className="font-medium text-gray-800">{name}, {age}</h3>
            <div className="flex gap-1">
              {interests.map((interest, index) => (
                <Badge key={index} variant="outline" className="bg-lavender-50 text-lavender-700 border-lavender-200 text-xs">
                  {interest}
                </Badge>
              ))}
            </div>
          </div>
          <p className="text-sm text-gray-600 mt-1 line-clamp-2">"{promptAnswer}"</p>
        </div>
      </div>
      
      <div className="bg-lavender-50 p-3 flex items-center justify-between border-t border-lavender-200">
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-xs text-lavender-700 hover:text-lavender-800 hover:bg-lavender-100"
        >
          <Lock className="h-3 w-3 mr-1" />
          <span>View Full Profile</span>
        </Button>
        
        <Button 
          size="sm" 
          className="rounded-full bg-gradient-to-r from-lavender-400 to-pink-400 hover:from-lavender-500 hover:to-pink-500 text-white"
        >
          <Send className="h-3 w-3 mr-1" />
          <span>Send Hello</span>
        </Button>
      </div>
    </motion.div>
  );
}
