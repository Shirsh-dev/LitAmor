
import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Heart, Send } from "lucide-react";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import { InterestBubble } from "@/components/amor-fly/InterestBubble";
import { PromptCard } from "@/components/amor-fly/PromptCard";
import { MatchCard } from "@/components/amor-fly/MatchCard";
import Link from "next/link";

interface Interest {
  id: string;
  name: string;
  icon: string;
  selected: boolean;
}

interface Prompt {
  id: string;
  question: string;
  answer: string;
}

interface Match {
  id: string;
  name: string;
  age: number;
  avatar: string;
  interests: string[];
  promptAnswer: string;
}

export function AmorFly() {
  const [selectedInterests, setSelectedInterests] = useState<string[]>(["art", "music"]);
  const [prompts, setPrompts] = useState<Prompt[]>([
    {
      id: "1",
      question: "If we met in a museum, I'd...",
      answer: "sketch you on a napkin."
    },
    {
      id: "2",
      question: "Our song? Something that...",
      answer: "starts slow but ends in a wild dance."
    }
  ]);
  
  // Sample interests data
  const interests: Interest[] = [
    { id: "art", name: "Art", icon: "🎨", selected: selectedInterests.includes("art") },
    { id: "music", name: "Music", icon: "🎶", selected: selectedInterests.includes("music") },
    { id: "travel", name: "Travel", icon: "✈️", selected: selectedInterests.includes("travel") },
    { id: "dance", name: "Dance", icon: "💃", selected: selectedInterests.includes("dance") },
    { id: "photography", name: "Photography", icon: "📸", selected: selectedInterests.includes("photography") },
    { id: "coding", name: "Coding", icon: "💻", selected: selectedInterests.includes("coding") },
    { id: "self-growth", name: "Self-Growth", icon: "🧘", selected: selectedInterests.includes("self-growth") }
  ];
  
  // Sample matches data
  const matches: Match[] = [
    {
      id: "1",
      name: "Aarav",
      age: 26,
      avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80",
      interests: ["Art", "Dance"],
      promptAnswer: "I'd show you my favorite hidden sculpture and ask about yours."
    },
    {
      id: "2",
      name: "Meher",
      age: 23,
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80",
      interests: ["Music", "Poetry"],
      promptAnswer: "I'd compose a melody inspired by our conversation."
    }
  ];
  
  const handleInterestToggle = (id: string) => {
    setSelectedInterests(prev => 
      prev.includes(id) 
        ? prev.filter(i => i !== id) 
        : [...prev, id]
    );
  };
  
  const handlePromptChange = (id: string, answer: string) => {
    setPrompts(prev => 
      prev.map(prompt => 
        prompt.id === id ? { ...prompt, answer } : prompt
      )
    );
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-lavender-100 via-peach-100 to-gold-100 flex flex-col">
      {/* Top Bar */}
      <header className="w-full py-4 px-6 flex items-center justify-between bg-white/80 backdrop-blur-sm border-b border-lavender-200">
        <Link href="/singles/home">
          <Button variant="ghost" size="icon" className="rounded-full">
            <ArrowLeft className="h-5 w-5 text-gray-600" />
            <span className="sr-only">Back</span>
          </Button>
        </Link>
        
        <div className="flex flex-col items-center">
          <h1 className="text-2xl font-serif font-bold text-gray-800 tracking-wide flex items-center gap-2">
            Amor Fly
            <motion.div
              animate={{ 
                y: [0, -5, 0],
                rotate: [0, 10, 0]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                repeatType: "reverse"
              }}
            >
              <Send className="h-5 w-5 text-pink-500" />
            </motion.div>
          </h1>
          <div className="flex items-center gap-1">
            <LitAmorLogo size="small" />
            <span className="text-xs text-muted-foreground">Lit Amor</span>
          </div>
        </div>
        
        <div className="w-10 h-10" /> {/* Spacer to balance layout */}
      </header>
      
      {/* Tagline */}
      <div className="w-full py-3 px-6 bg-white/50 backdrop-blur-sm border-b border-lavender-200 text-center">
        <p className="text-sm font-medium text-gray-600 italic">Let your passion lead you to love.</p>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="max-w-3xl mx-auto p-6 space-y-8">
          {/* Decorative Paper Planes */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {Array.from({ length: 5 }).map((_, index) => (
              <motion.div
                key={index}
                className="absolute"
                style={{
                  top: `${10 + index * 15}%`,
                  left: `${5 + index * 20}%`,
                }}
                animate={{
                  x: [0, 100, 200, 300, 400, 500],
                  y: [0, -20, -10, -30, -20, -10],
                  rotate: [0, 10, 5, 15, 5, 10]
                }}
                transition={{
                  duration: 20 + index * 5,
                  repeat: Infinity,
                  ease: "linear"
                }}
              >
                <div className="text-pink-200/30">
                  <Send size={20 + index * 4} />
                </div>
              </motion.div>
            ))}
          </div>
          
          {/* Interest Bubbles */}
          <section>
            <h2 className="text-lg font-medium text-gray-700 mb-4">Choose your passions</h2>
            <div className="overflow-x-auto pb-4">
              <div className="flex gap-3">
                {interests.map(interest => (
                  <InterestBubble
                    key={interest.id}
                    icon={interest.icon}
                    name={interest.name}
                    selected={interest.selected}
                    onClick={() => handleInterestToggle(interest.id)}
                  />
                ))}
              </div>
            </div>
          </section>
          
          {/* Creative Prompts */}
          <section className="space-y-4">
            <h2 className="text-lg font-medium text-gray-700">Express yourself</h2>
            {prompts.map(prompt => (
              <PromptCard
                key={prompt.id}
                question={prompt.question}
                answer={prompt.answer}
                onChange={(answer) => handlePromptChange(prompt.id, answer)}
              />
            ))}
          </section>
          
          {/* Fly Together Button */}
          <section className="py-6 flex justify-center">
            <Button 
              className="bg-gradient-to-r from-lavender-500 to-pink-500 hover:from-lavender-600 hover:to-pink-600 text-white font-medium rounded-full px-8 py-6 flex items-center gap-2 shadow-lg shadow-lavender-200/50"
            >
              <span>Fly Together</span>
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatType: "reverse"
                }}
              >
                <Heart className="h-5 w-5" />
              </motion.div>
            </Button>
          </section>
          
          {/* Matches */}
          <section className="space-y-4">
            <h2 className="text-lg font-medium text-gray-700 flex items-center gap-2">
              <span>Let's Connect</span>
              <motion.div
                animate={{
                  y: [0, -3, 0],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  repeatType: "reverse"
                }}
              >
                <Send className="h-4 w-4 text-pink-500" />
              </motion.div>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {matches.map(match => (
                <MatchCard
                  key={match.id}
                  name={match.name}
                  age={match.age}
                  avatar={match.avatar}
                  interests={match.interests}
                  promptAnswer={match.promptAnswer}
                />
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
