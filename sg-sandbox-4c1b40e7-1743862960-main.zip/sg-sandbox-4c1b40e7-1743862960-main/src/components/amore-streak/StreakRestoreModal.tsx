import { useState } from "react";
import { Heart, CreditCard, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { motion } from "framer-motion";

interface StreakRestoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRestore: () => void;
}

export function StreakRestoreModal({ isOpen, onClose, onRestore }: StreakRestoreModalProps) {
  const [isProcessing, setIsProcessing] = useState(false);

  const handleRestore = async () => {
    setIsProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsProcessing(false);
    onRestore();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Heart className="h-5 w-5 text-red-500" />
            Streak Broken!
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="text-center py-4">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-20 h-20 rounded-full bg-gradient-to-br from-red-400 to-pink-400 flex items-center justify-center mx-auto mb-4"
            >
              <Heart className="h-10 w-10 text-white" />
            </motion.div>
            
            <h3 className="text-lg font-semibold mb-2">Your streak broke!</h3>
            <p className="text-muted-foreground text-sm">
              You missed sending a daily love message. Don't worry, you can restore your streak and keep the love flowing!
            </p>
          </div>

          <Card className="border-orange-200 bg-gradient-to-r from-orange-50 to-pink-50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Restore Your Streak
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm">Streak Restoration</span>
                <span className="font-bold text-lg">₹50</span>
              </div>
              
              <div className="text-xs text-muted-foreground mb-4">
                Restore your streak and continue building your love story together. Your partner will be notified that you've restored the streak.
              </div>

              <div className="space-y-2">
                <Button
                  onClick={handleRestore}
                  disabled={isProcessing}
                  className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600"
                >
                  {isProcessing ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      className="w-4 h-4 border-2 border-white border-t-transparent rounded-full"
                    />
                  ) : (
                    <>
                      <Heart className="h-4 w-4 mr-2" />
                      Restore for ₹50
                    </>
                  )}
                </Button>
                
                <Button
                  variant="ghost"
                  onClick={onClose}
                  disabled={isProcessing}
                  className="w-full"
                >
                  Start Fresh Streak
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="text-center">
            <p className="text-xs text-muted-foreground">
              Secure payment powered by Razorpay
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
