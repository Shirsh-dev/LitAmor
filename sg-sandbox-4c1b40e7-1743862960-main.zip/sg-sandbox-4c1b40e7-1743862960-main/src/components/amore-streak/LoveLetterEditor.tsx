import { useState } from "react";
import { ArrowLeft, Send, Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight, Palette, Type } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

interface LoveLetterEditorProps {
  onBack: () => void;
  onSent: () => void;
  prompt: string;
}

const fontOptions = [
  { name: "Poppins", value: "font-sans" },
  { name: "Serif", value: "font-serif" },
  { name: "Mono", value: "font-mono" }
];

const backgroundGradients = [
  "bg-gradient-to-br from-pink-100 to-orange-100",
  "bg-gradient-to-br from-purple-100 to-pink-100",
  "bg-gradient-to-br from-orange-100 to-yellow-100",
  "bg-gradient-to-br from-blue-100 to-purple-100",
  "bg-white"
];

export function LoveLetterEditor({ onBack, onSent, prompt }: LoveLetterEditorProps) {
  const [message, setMessage] = useState("");
  const [selectedFont, setSelectedFont] = useState("font-sans");
  const [selectedBackground, setSelectedBackground] = useState(backgroundGradients[0]);
  const [textAlign, setTextAlign] = useState("text-left");
  const [showPreview, setShowPreview] = useState(false);
  const [formatting, setFormatting] = useState({
    bold: false,
    italic: false,
    underline: false
  });

  const handleSend = () => {
    if (message.trim()) {
      onSent();
    }
  };

  const getFormattingClasses = () => {
    let classes = `${selectedFont} ${textAlign}`;
    if (formatting.bold) classes += " font-bold";
    if (formatting.italic) classes += " italic";
    if (formatting.underline) classes += " underline";
    return classes;
  };

  if (showPreview) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-white p-4">
        <div className="flex items-center justify-between mb-6">
          <Button variant="ghost" onClick={() => setShowPreview(false)}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Edit
          </Button>
          <h1 className="text-lg font-semibold">Preview</h1>
          <Button onClick={handleSend} className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600">
            <Send className="h-4 w-4 mr-2" />
            Send
          </Button>
        </div>

        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className={`${selectedBackground} p-6 rounded-lg shadow-lg min-h-[400px]`}
        >
          <div className={`${getFormattingClasses()} text-gray-800 whitespace-pre-wrap leading-relaxed`}>
            {message}
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-white p-4">
      <div className="flex items-center justify-between mb-6">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <h1 className="text-lg font-semibold">Love Letter</h1>
        <Button 
          variant="outline" 
          onClick={() => setShowPreview(true)}
          disabled={!message.trim()}
        >
          Preview
        </Button>
      </div>

      {/* Prompt */}
      <Card className="mb-4 border-orange-200 bg-gradient-to-r from-orange-50 to-pink-50">
        <CardContent className="pt-4">
          <p className="text-gray-700 italic text-sm">"{prompt}"</p>
        </CardContent>
      </Card>

      {/* Formatting Tools */}
      <Card className="mb-4">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Formatting</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Text Formatting */}
          <div className="flex gap-2">
            <Button
              variant={formatting.bold ? "default" : "outline"}
              size="sm"
              onClick={() => setFormatting(prev => ({ ...prev, bold: !prev.bold }))}
            >
              <Bold className="h-4 w-4" />
            </Button>
            <Button
              variant={formatting.italic ? "default" : "outline"}
              size="sm"
              onClick={() => setFormatting(prev => ({ ...prev, italic: !prev.italic }))}
            >
              <Italic className="h-4 w-4" />
            </Button>
            <Button
              variant={formatting.underline ? "default" : "outline"}
              size="sm"
              onClick={() => setFormatting(prev => ({ ...prev, underline: !prev.underline }))}
            >
              <Underline className="h-4 w-4" />
            </Button>
          </div>

          {/* Alignment */}
          <div className="flex gap-2">
            <Button
              variant={textAlign === "text-left" ? "default" : "outline"}
              size="sm"
              onClick={() => setTextAlign("text-left")}
            >
              <AlignLeft className="h-4 w-4" />
            </Button>
            <Button
              variant={textAlign === "text-center" ? "default" : "outline"}
              size="sm"
              onClick={() => setTextAlign("text-center")}
            >
              <AlignCenter className="h-4 w-4" />
            </Button>
            <Button
              variant={textAlign === "text-right" ? "default" : "outline"}
              size="sm"
              onClick={() => setTextAlign("text-right")}
            >
              <AlignRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Font Selection */}
          <div className="space-y-2">
            <label className="text-sm font-medium flex items-center gap-2">
              <Type className="h-4 w-4" />
              Font
            </label>
            <div className="flex gap-2">
              {fontOptions.map((font) => (
                <Button
                  key={font.value}
                  variant={selectedFont === font.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedFont(font.value)}
                  className={font.value}
                >
                  {font.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Background Selection */}
          <div className="space-y-2">
            <label className="text-sm font-medium flex items-center gap-2">
              <Palette className="h-4 w-4" />
              Background
            </label>
            <div className="flex gap-2">
              {backgroundGradients.map((bg, index) => (
                <button
                  key={index}
                  className={`w-8 h-8 rounded-full ${bg} border-2 ${
                    selectedBackground === bg ? "border-gray-400" : "border-gray-200"
                  }`}
                  onClick={() => setSelectedBackground(bg)}
                />
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Text Editor */}
      <Card>
        <CardContent className="pt-4">
          <Textarea
            placeholder="Write your love letter here..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className={`min-h-[300px] resize-none border-none focus:ring-0 ${getFormattingClasses()}`}
          />
        </CardContent>
      </Card>

      {/* Send Button */}
      <div className="fixed bottom-20 left-4 right-4">
        <Button
          onClick={handleSend}
          disabled={!message.trim()}
          className="w-full h-12 bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600"
        >
          <Send className="h-4 w-4 mr-2" />
          Send Love Letter
        </Button>
      </div>
    </div>
  );
}