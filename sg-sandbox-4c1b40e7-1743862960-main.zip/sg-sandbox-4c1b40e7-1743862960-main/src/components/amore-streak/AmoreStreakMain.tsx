import { useState, useEffect } from "react";
import { Heart, Camera, Video, PenTool, Calendar, Archive } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { LoveLetterEditor } from "./LoveLetterEditor";
import { PhotoVideoCapture } from "./PhotoVideoCapture";
import { StreakHistory } from "./StreakHistory";
import { StreakRestoreModal } from "./StreakRestoreModal";

interface AmoreStreakMainProps {
  streakCount?: number;
  hasStreakToday?: boolean;
  streakBroken?: boolean;
}

const dailyPrompts = [
  "One moment from today that made you smile?",
  "Three things I love about you today",
  "Why are you proud of your partner?",
  "Write about your first memory together",
  "Send a photo of something that reminded you of them",
  "What made you fall in love with them?",
  "Describe your perfect day together",
  "What's your favorite thing about their laugh?",
  "Share a dream you have for your future together",
  "What's something new you learned about them recently?"
];

export function AmoreStreakMain({ 
  streakCount = 7, 
  hasStreakToday = false,
  streakBroken = false 
}: AmoreStreakMainProps) {
  const [activeView, setActiveView] = useState<"main" | "letter" | "photo" | "video" | "history">("main");
  const [showRestoreModal, setShowRestoreModal] = useState(false);
  
  const todaysPrompt = dailyPrompts[new Date().getDate() % dailyPrompts.length];

  useEffect(() => {
    // Check if streak is broken and show restore modal
    if (streakBroken) {
      setShowRestoreModal(true);
    }
  }, [streakBroken]);

  const handleStreakType = (type: "letter" | "photo" | "video") => {
    if (hasStreakToday) {
      return;
    }
    setActiveView(type);
  };

  const handleStreakSent = () => {
    setActiveView("main");
  };

  const handleRestoreStreak = () => {
    // Here you would implement the logic to restore the streak
    // For now, we'll just close the modal and update the UI
    setShowRestoreModal(false);
    // You might want to update streakCount or other state here
  };

  if (activeView === "letter") {
    return <LoveLetterEditor onBack={() => setActiveView("main")} onSent={handleStreakSent} prompt={todaysPrompt} />;
  }

  if (activeView === "photo" || activeView === "video") {
    return <PhotoVideoCapture type={activeView} onBack={() => setActiveView("main")} onSent={handleStreakSent} />;
  }

  if (activeView === "history") {
    return <StreakHistory onBack={() => setActiveView("main")} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-white p-4 pb-20">
      {/* Streak Counter */}
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="text-center mb-8"
      >
        <div className="relative inline-block">
          <div className="w-32 h-32 rounded-full bg-gradient-to-br from-orange-300 via-pink-300 to-orange-400 flex items-center justify-center shadow-lg">
            <div className="text-center">
              <Heart className="h-8 w-8 text-white mx-auto mb-1" />
              <div className="text-2xl font-bold text-white">{streakCount}</div>
              <div className="text-white text-sm font-medium">Days</div>
            </div>
          </div>
          {!hasStreakToday && (
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-yellow-400 flex items-center justify-center"
            >
              <span className="text-white font-bold text-sm">!</span>
            </motion.div>
          )}
        </div>
        <h1 className="text-2xl font-bold mt-4 bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent">
          Amore Streak
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          {hasStreakToday ? "Streak sent today! ❤️" : "Send your daily love message"}
        </p>
      </motion.div>

      {/* Daily Prompt */}
      <Card className="mb-6 border-orange-200 bg-gradient-to-r from-orange-50 to-pink-50">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <PenTool className="h-5 w-5 text-orange-500" />
            Today's Inspiration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 italic">"{todaysPrompt}"</p>
        </CardContent>
      </Card>

      {/* Streak Options */}
      <div className="space-y-4 mb-6">
        <h2 className="text-lg font-semibold text-gray-800">Send Your Streak</h2>
        
        <div className="grid grid-cols-1 gap-4">
          <motion.div whileTap={{ scale: 0.98 }}>
            <Button
              variant="outline"
              className={`w-full h-16 flex items-center justify-start gap-4 border-2 ${
                hasStreakToday 
                  ? "border-gray-200 bg-gray-50 cursor-not-allowed" 
                  : "border-pink-200 hover:border-pink-300 hover:bg-pink-50"
              }`}
              onClick={() => handleStreakType("letter")}
              disabled={hasStreakToday}
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-400 to-orange-400 flex items-center justify-center">
                <PenTool className="h-6 w-6 text-white" />
              </div>
              <div className="text-left">
                <div className="font-semibold">Love Letter</div>
                <div className="text-sm text-muted-foreground">Write a heartfelt message</div>
              </div>
              {hasStreakToday && <Badge variant="secondary">Sent</Badge>}
            </Button>
          </motion.div>

          <motion.div whileTap={{ scale: 0.98 }}>
            <Button
              variant="outline"
              className={`w-full h-16 flex items-center justify-start gap-4 border-2 ${
                hasStreakToday 
                  ? "border-gray-200 bg-gray-50 cursor-not-allowed" 
                  : "border-pink-200 hover:border-pink-300 hover:bg-pink-50"
              }`}
              onClick={() => handleStreakType("photo")}
              disabled={hasStreakToday}
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-purple-400 flex items-center justify-center">
                <Camera className="h-6 w-6 text-white" />
              </div>
              <div className="text-left">
                <div className="font-semibold">Photo Message</div>
                <div className="text-sm text-muted-foreground">Capture a special moment</div>
              </div>
              {hasStreakToday && <Badge variant="secondary">Sent</Badge>}
            </Button>
          </motion.div>

          <motion.div whileTap={{ scale: 0.98 }}>
            <Button
              variant="outline"
              className={`w-full h-16 flex items-center justify-start gap-4 border-2 ${
                hasStreakToday 
                  ? "border-gray-200 bg-gray-50 cursor-not-allowed" 
                  : "border-pink-200 hover:border-pink-300 hover:bg-pink-50"
              }`}
              onClick={() => handleStreakType("video")}
              disabled={hasStreakToday}
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
                <Video className="h-6 w-6 text-white" />
              </div>
              <div className="text-left">
                <div className="font-semibold">Video Note</div>
                <div className="text-sm text-muted-foreground">Record a personal message</div>
              </div>
              {hasStreakToday && <Badge variant="secondary">Sent</Badge>}
            </Button>
          </motion.div>
        </div>
      </div>

      {/* View History */}
      <Button
        variant="ghost"
        className="w-full flex items-center gap-2 text-gray-600 hover:text-gray-800"
        onClick={() => setActiveView("history")}
      >
        <Archive className="h-4 w-4" />
        View Past Streaks
      </Button>

      {/* Restore Modal */}
      <StreakRestoreModal
        isOpen={showRestoreModal}
        onClose={() => setShowRestoreModal(false)}
        onRestore={handleRestoreStreak}
      />
    </div>
  );
}
