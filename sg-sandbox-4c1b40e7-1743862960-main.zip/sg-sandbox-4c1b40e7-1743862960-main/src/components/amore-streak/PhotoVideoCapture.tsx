import { useState } from "react";
import { ArrowLeft, Camera, Video, Send, Filter, Palette, Type } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";

interface PhotoVideoCaptureProps {
  type: "photo" | "video";
  onBack: () => void;
  onSent: () => void;
}

const filters = [
  { name: "None", class: "" },
  { name: "Warm", class: "sepia-[0.3] saturate-150" },
  { name: "Retro", class: "sepia-[0.5] contrast-125" },
  { name: "Dreamy", class: "blur-[0.5px] brightness-110" },
  { name: "B&W", class: "grayscale" }
];

export function PhotoVideoCapture({ type, onBack, onSent }: PhotoVideoCaptureProps) {
  const [step, setStep] = useState<"capture" | "edit" | "preview">("capture");
  const [selectedFilter, setSelectedFilter] = useState(filters[0]);
  const [textOverlay, setTextOverlay] = useState("");
  const [isRecording, setIsRecording] = useState(false);

  const handleCapture = () => {
    setStep("edit");
  };

  const handleSend = () => {
    onSent();
  };

  if (step === "capture") {
    return (
      <div className="min-h-screen bg-black relative">
        <div className="absolute top-4 left-4 right-4 z-10 flex items-center justify-between">
          <Button variant="ghost" onClick={onBack} className="text-white">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="text-white font-semibold">
            {type === "photo" ? "Take Photo" : "Record Video"}
          </h1>
          <div></div>
        </div>

        {/* Camera Preview Placeholder */}
        <div className="h-screen bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
          <div className="text-center text-white">
            <div className="w-32 h-32 rounded-full bg-white/20 flex items-center justify-center mb-4 mx-auto">
              {type === "photo" ? (
                <Camera className="h-16 w-16" />
              ) : (
                <Video className="h-16 w-16" />
              )}
            </div>
            <p className="text-lg mb-2">Camera Preview</p>
            <p className="text-sm text-gray-300">
              {type === "photo" ? "Position your shot" : "Get ready to record"}
            </p>
          </div>
        </div>

        {/* Capture Controls */}
        <div className="absolute bottom-8 left-0 right-0 flex justify-center">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleCapture}
            className={`w-20 h-20 rounded-full border-4 border-white flex items-center justify-center ${
              type === "video" && isRecording ? "bg-red-500" : "bg-white/20"
            }`}
          >
            {type === "photo" ? (
              <Camera className="h-8 w-8 text-white" />
            ) : (
              <Video className={`h-8 w-8 ${isRecording ? "text-white" : "text-white"}`} />
            )}
          </motion.button>
        </div>
      </div>
    );
  }

  if (step === "edit") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-white p-4">
        <div className="flex items-center justify-between mb-6">
          <Button variant="ghost" onClick={() => setStep("capture")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retake
          </Button>
          <h1 className="text-lg font-semibold">Edit {type === "photo" ? "Photo" : "Video"}</h1>
          <Button onClick={() => setStep("preview")}>
            Preview
          </Button>
        </div>

        {/* Media Preview */}
        <Card className="mb-6">
          <CardContent className="p-0">
            <div className={`aspect-square bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg overflow-hidden ${selectedFilter.class}`}>
              <div className="h-full flex items-center justify-center relative">
                <div className="text-center text-gray-600">
                  {type === "photo" ? (
                    <Camera className="h-16 w-16 mx-auto mb-2" />
                  ) : (
                    <Video className="h-16 w-16 mx-auto mb-2" />
                  )}
                  <p>Your {type} preview</p>
                </div>
                {textOverlay && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-black/50 text-white px-4 py-2 rounded-lg">
                      {textOverlay}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        <Card className="mb-4">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 mb-3">
              <Filter className="h-4 w-4" />
              <span className="font-medium text-sm">Filters</span>
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {filters.map((filter) => (
                <Button
                  key={filter.name}
                  variant={selectedFilter.name === filter.name ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedFilter(filter)}
                  className="whitespace-nowrap"
                >
                  {filter.name}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Text Overlay */}
        <Card className="mb-6">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 mb-3">
              <Type className="h-4 w-4" />
              <span className="font-medium text-sm">Add Text</span>
            </div>
            <Input
              placeholder="Add a message..."
              value={textOverlay}
              onChange={(e) => setTextOverlay(e.target.value)}
            />
          </CardContent>
        </Card>

        {/* Send Button */}
        <Button
          onClick={handleSend}
          className="w-full h-12 bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600"
        >
          <Send className="h-4 w-4 mr-2" />
          Send {type === "photo" ? "Photo" : "Video"}
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-white p-4">
      <div className="flex items-center justify-between mb-6">
        <Button variant="ghost" onClick={() => setStep("edit")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Edit
        </Button>
        <h1 className="text-lg font-semibold">Preview</h1>
        <Button onClick={handleSend} className="bg-gradient-to-r from-orange-500 to-pink-500">
          <Send className="h-4 w-4 mr-2" />
          Send
        </Button>
      </div>

      {/* Final Preview */}
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="aspect-square bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg overflow-hidden"
      >
        <div className={`h-full flex items-center justify-center relative ${selectedFilter.class}`}>
          <div className="text-center text-gray-600">
            {type === "photo" ? (
              <Camera className="h-16 w-16 mx-auto mb-2" />
            ) : (
              <Video className="h-16 w-16 mx-auto mb-2" />
            )}
            <p>Final {type} with filters</p>
          </div>
          {textOverlay && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="bg-black/50 text-white px-4 py-2 rounded-lg">
                {textOverlay}
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}