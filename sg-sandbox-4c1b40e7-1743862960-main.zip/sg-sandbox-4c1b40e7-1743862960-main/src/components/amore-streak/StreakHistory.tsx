import { useState } from "react";
import { ArrowLeft, Heart, Camera, Video, PenTool, Calendar, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

interface StreakHistoryProps {
  onBack: () => void;
}

interface StreakItem {
  id: string;
  date: string;
  type: "letter" | "photo" | "video";
  preview: string;
  sent: boolean;
}

const mockStreakHistory: StreakItem[] = [
  {
    id: "1",
    date: "2024-06-01",
    type: "letter",
    preview: "My dearest love, today I watched the sunrise and thought of you...",
    sent: true
  },
  {
    id: "2",
    date: "2024-05-31",
    type: "photo",
    preview: "Beautiful sunset photo with heart overlay",
    sent: true
  },
  {
    id: "3",
    date: "2024-05-30",
    type: "video",
    preview: "Good morning video message",
    sent: true
  },
  {
    id: "4",
    date: "2024-05-29",
    type: "letter",
    preview: "Three things I love about you today: your smile, your laugh...",
    sent: true
  },
  {
    id: "5",
    date: "2024-05-28",
    type: "photo",
    preview: "Coffee shop where we had our first date",
    sent: true
  }
];

export function StreakHistory({ onBack }: StreakHistoryProps) {
  const [selectedItem, setSelectedItem] = useState<StreakItem | null>(null);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "letter":
        return <PenTool className="h-4 w-4" />;
      case "photo":
        return <Camera className="h-4 w-4" />;
      case "video":
        return <Video className="h-4 w-4" />;
      default:
        return <Heart className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "letter":
        return "from-pink-400 to-orange-400";
      case "photo":
        return "from-blue-400 to-purple-400";
      case "video":
        return "from-purple-400 to-pink-400";
      default:
        return "from-gray-400 to-gray-500";
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric"
    });
  };

  if (selectedItem) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-white p-4">
        <div className="flex items-center justify-between mb-6">
          <Button variant="ghost" onClick={() => setSelectedItem(null)}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to History
          </Button>
          <h1 className="text-lg font-semibold">Streak Details</h1>
          <div></div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${getTypeColor(selectedItem.type)} flex items-center justify-center text-white`}>
                {getTypeIcon(selectedItem.type)}
              </div>
              {selectedItem.type.charAt(0).toUpperCase() + selectedItem.type.slice(1)}
              <Badge variant="secondary">{formatDate(selectedItem.date)}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedItem.type === "letter" ? (
              <div className="bg-gradient-to-br from-pink-100 to-orange-100 p-6 rounded-lg">
                <p className="text-gray-800 leading-relaxed">{selectedItem.preview}</p>
              </div>
            ) : (
              <div className="aspect-square bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg flex items-center justify-center">
                <div className="text-center text-gray-600">
                  {getTypeIcon(selectedItem.type)}
                  <p className="mt-2">{selectedItem.preview}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-white p-4 pb-20">
      <div className="flex items-center justify-between mb-6">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <h1 className="text-lg font-semibold">Streak History</h1>
        <div></div>
      </div>

      {/* Stats */}
      <Card className="mb-6 border-orange-200 bg-gradient-to-r from-orange-50 to-pink-50">
        <CardContent className="pt-4">
          <div className="flex items-center justify-between">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">7</div>
              <div className="text-sm text-muted-foreground">Current Streak</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-pink-600">23</div>
              <div className="text-sm text-muted-foreground">Total Sent</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">15</div>
              <div className="text-sm text-muted-foreground">Best Streak</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* History List */}
      <div className="space-y-3">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Recent Streaks</h2>
        
        {mockStreakHistory.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setSelectedItem(item)}>
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${getTypeColor(item.type)} flex items-center justify-center text-white flex-shrink-0`}>
                    {getTypeIcon(item.type)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium capitalize">{item.type}</span>
                      <Badge variant="secondary" className="text-xs">
                        {formatDate(item.date)}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">
                      {item.preview}
                    </p>
                  </div>
                  
                  <Button variant="ghost" size="sm">
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {mockStreakHistory.length === 0 && (
        <div className="text-center py-12">
          <Heart className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-600 mb-2">No streaks yet</h3>
          <p className="text-muted-foreground">Start sending daily love messages to build your streak history!</p>
        </div>
      )}
    </div>
  );
}