
import { Flame } from "lucide-react";

interface AmoreStreakCounterProps {
  count: number;
}

export function AmoreStreakCounter({ count }: AmoreStreakCounterProps) {
  return (
    <div className="flex items-center gap-1 bg-background/80 backdrop-blur-sm px-3 py-1.5 rounded-full border border-primary/20 shadow-sm">
      <Flame className="h-5 w-5 text-primary" />
      <span className="font-medium text-sm">{count}</span>
    </div>
  );
}
