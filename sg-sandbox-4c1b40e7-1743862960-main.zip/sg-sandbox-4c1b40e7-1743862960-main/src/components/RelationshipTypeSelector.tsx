
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, User, Users } from "lucide-react";
import { useRouter } from "next/router";

interface RelationshipTypeSelectorProps {
  onSelect: (type: "single" | "couple") => void;
}

export function RelationshipTypeSelector({ onSelect }: RelationshipTypeSelectorProps) {
  const [selected, setSelected] = useState<"single" | "couple" | null>(null);
  
  const handleSelect = (type: "single" | "couple") => {
    setSelected(type);
  };
  
  const handleContinue = () => {
    if (selected) {
      onSelect(selected);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto border border-border/30 shadow-lg bg-card/80 backdrop-blur-sm">
      <CardContent className="p-8 flex flex-col items-center space-y-8">
        <h2 className="text-2xl font-bold text-center">How will you use LIT AMOR?</h2>
        
        <div className="grid grid-cols-2 gap-8 w-full">
          <div 
            className={`flex flex-col items-center justify-center p-6 rounded-xl border-2 cursor-pointer transition-all ${
              selected === "single" 
                ? "border-primary bg-primary/5" 
                : "border-border/50 hover:border-primary/50"
            }`}
            onClick={() => handleSelect("single")}
          >
            <div className="relative h-24 w-24 mb-4">
              <Heart 
                className="absolute inset-0 text-primary" 
                size={96} 
                strokeWidth={1.5}
              />
              <User 
                className="absolute inset-0 m-auto text-foreground" 
                size={40} 
              />
            </div>
            <span className="text-xl font-medium">Single</span>
          </div>
          
          <div 
            className={`flex flex-col items-center justify-center p-6 rounded-xl border-2 cursor-pointer transition-all ${
              selected === "couple" 
                ? "border-primary bg-primary/5" 
                : "border-border/50 hover:border-primary/50"
            }`}
            onClick={() => handleSelect("couple")}
          >
            <div className="relative h-24 w-24 mb-4">
              <Heart 
                className="absolute inset-0 text-primary" 
                size={96} 
                strokeWidth={1.5}
              />
              <Users 
                className="absolute inset-0 m-auto text-foreground" 
                size={40} 
              />
            </div>
            <span className="text-xl font-medium">Couple</span>
          </div>
        </div>
        
        <Button 
          className="w-full py-6 text-lg font-medium rounded-full"
          disabled={!selected}
          onClick={handleContinue}
        >
          Continue
        </Button>
      </CardContent>
    </Card>
  );
}
