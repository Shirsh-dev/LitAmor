
import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart } from "lucide-react";

interface Memory {
  id: string;
  imageUrl: string;
  text: string;
  date: string;
  position: {
    x: number;
    y: number;
  };
}

interface CherryBlossomTreeProps {
  memories: Memory[];
  onMemoryClick: (memory: Memory) => void;
  theme: "sakura" | "autumn" | "plain";
}

export function CherryBlossomTree({ memories, onMemoryClick, theme }: CherryBlossomTreeProps) {
  const [petals, setPetals] = useState<Array<{ id: number; style: React.CSSProperties }>>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Generate falling petals animation
  useEffect(() => {
    if (theme !== "sakura") return;
    
    const generatePetal = () => {
      const id = Date.now() + Math.random() * 1000;
      const left = Math.random() * 100;
      const animationDuration = 7 + Math.random() * 7;
      const size = 8 + Math.random() * 15;
      const opacity = 0.6 + Math.random() * 0.4;
      const rotation = Math.random() * 360;
      
      return {
        id,
        style: {
          left: `${left}%`,
          animationDuration: `${animationDuration}s`,
          width: `${size}px`,
          height: `${size}px`,
          opacity,
          transform: `rotate(${rotation}deg)`
        }
      };
    };
    
    // Initial petals
    const initialPetals = Array.from({ length: 30 }, generatePetal);
    setPetals(initialPetals);
    
    // Add new petals periodically
    const interval = setInterval(() => {
      setPetals(prev => [...prev.slice(-40), generatePetal()]);
    }, 300);
    
    return () => clearInterval(interval);
  }, [theme]);

  return (
    <div ref={containerRef} className="relative w-full h-full overflow-hidden">
      {/* Sky background */}
      <div className={`absolute inset-0 ${theme === "sakura" ? "bg-gradient-to-b from-blue-200 to-blue-400" : 
        theme === "autumn" ? "bg-gradient-to-b from-orange-100 to-amber-200" : 
        "bg-gradient-to-b from-blue-100 to-purple-200"} transition-colors duration-500`}></div>
      
      {/* Clouds */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div 
          className="absolute top-[10%] left-[5%] w-24 h-12 bg-white/80 rounded-full blur-md"
          animate={{ x: [0, 20, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute top-[15%] right-[15%] w-32 h-16 bg-white/80 rounded-full blur-md"
          animate={{ x: [0, -30, 0] }}
          transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute top-[8%] left-[40%] w-20 h-10 bg-white/80 rounded-full blur-md"
          animate={{ x: [0, 15, 0] }}
          transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
        />
      </div>
      
      {/* Falling petals animation (only for sakura theme) */}
      {theme === "sakura" && (
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {petals.map(petal => (
            <motion.div
              key={petal.id}
              className="absolute petal"
              style={petal.style}
              initial={{ top: "-5%", rotate: 0 }}
              animate={{ 
                top: "105%", 
                rotate: 360,
                x: [0, 20, -20, 10, -10, 0]
              }}
              transition={{ 
                duration: parseFloat(petal.style.animationDuration as string), 
                ease: "linear",
                repeat: 0
              }}
            />
          ))}
        </div>
      )}
      
      {/* Tree SVG */}
      <div className="absolute inset-0 flex items-center justify-center">
        {theme === "sakura" && (
          <svg width="100%" height="100%" viewBox="0 0 800 800" preserveAspectRatio="xMidYMid meet" className="max-w-5xl">
            {/* Ground/Grass */}
            <ellipse cx="400" cy="730" rx="300" ry="30" fill="#8B5A2B" opacity="0.7" />
            <ellipse cx="400" cy="730" rx="280" ry="20" fill="#7CFC00" opacity="0.3" />
            
            {/* Tree trunk */}
            <path 
              d="M380,730 C360,650 350,600 350,550 C350,500 360,450 380,400 C400,450 410,500 410,550 C410,600 400,650 380,730 Z" 
              fill="#8B4513"
            />
            
            {/* Main trunk */}
            <path 
              d="M380,400 C360,350 350,300 350,250 C350,200 360,150 380,100 C400,150 410,200 410,250 C410,300 400,350 380,400 Z" 
              fill="#A0522D"
            />
            
            {/* Main branches */}
            <path 
              d="M380,250 C340,230 300,200 270,150 C240,100 230,50 250,20 C280,40 300,70 320,120 C340,170 360,220 380,250 Z" 
              fill="#A0522D"
            />
            <path 
              d="M380,250 C420,230 460,200 490,150 C520,100 530,50 510,20 C480,40 460,70 440,120 C420,170 400,220 380,250 Z" 
              fill="#A0522D"
            />
            
            {/* Secondary branches - left */}
            <path 
              d="M270,150 C250,140 220,130 190,140 C160,150 140,170 130,200 C150,190 170,190 190,200 C210,210 240,180 270,150 Z" 
              fill="#A0522D"
            />
            <path 
              d="M320,120 C300,100 280,70 270,40 C260,10 270,-10 290,-20 C300,0 310,20 315,50 C320,80 320,100 320,120 Z" 
              fill="#A0522D"
            />
            
            {/* Secondary branches - right */}
            <path 
              d="M490,150 C510,140 540,130 570,140 C600,150 620,170 630,200 C610,190 590,190 570,200 C550,210 520,180 490,150 Z" 
              fill="#A0522D"
            />
            <path 
              d="M440,120 C460,100 480,70 490,40 C500,10 490,-10 470,-20 C460,0 450,20 445,50 C440,80 440,100 440,120 Z" 
              fill="#A0522D"
            />
            
            {/* Tertiary branches */}
            <path 
              d="M190,140 C170,120 140,110 110,120 C130,130 150,140 170,140 C180,140 190,140 190,140 Z" 
              fill="#A0522D"
            />
            <path 
              d="M570,140 C590,120 620,110 650,120 C630,130 610,140 590,140 C580,140 570,140 570,140 Z" 
              fill="#A0522D"
            />
            <path 
              d="M270,40 C250,20 240,-10 250,-30 C260,-10 270,10 275,30 C275,35 270,40 270,40 Z" 
              fill="#A0522D"
            />
            <path 
              d="M490,40 C510,20 520,-10 510,-30 C500,-10 490,10 485,30 C485,35 490,40 490,40 Z" 
              fill="#A0522D"
            />
            
            {/* Cherry blossom clusters */}
            <g>
              {/* Left side blossoms */}
              <circle cx="190" cy="140" r="40" fill="#FFB7C5" opacity="0.9" />
              <circle cx="150" cy="120" r="35" fill="#FFB7C5" opacity="0.9" />
              <circle cx="220" cy="110" r="30" fill="#FFB7C5" opacity="0.9" />
              <circle cx="240" cy="150" r="35" fill="#FFB7C5" opacity="0.9" />
              <circle cx="200" cy="180" r="30" fill="#FFB7C5" opacity="0.9" />
              
              {/* Right side blossoms */}
              <circle cx="570" cy="140" r="40" fill="#FFB7C5" opacity="0.9" />
              <circle cx="610" cy="120" r="35" fill="#FFB7C5" opacity="0.9" />
              <circle cx="540" cy="110" r="30" fill="#FFB7C5" opacity="0.9" />
              <circle cx="520" cy="150" r="35" fill="#FFB7C5" opacity="0.9" />
              <circle cx="560" cy="180" r="30" fill="#FFB7C5" opacity="0.9" />
              
              {/* Top blossoms */}
              <circle cx="270" cy="40" r="35" fill="#FFB7C5" opacity="0.9" />
              <circle cx="240" cy="10" r="30" fill="#FFB7C5" opacity="0.9" />
              <circle cx="290" cy="0" r="25" fill="#FFB7C5" opacity="0.9" />
              <circle cx="320" cy="30" r="30" fill="#FFB7C5" opacity="0.9" />
              
              <circle cx="490" cy="40" r="35" fill="#FFB7C5" opacity="0.9" />
              <circle cx="520" cy="10" r="30" fill="#FFB7C5" opacity="0.9" />
              <circle cx="470" cy="0" r="25" fill="#FFB7C5" opacity="0.9" />
              <circle cx="440" cy="30" r="30" fill="#FFB7C5" opacity="0.9" />
              
              {/* Center top blossoms */}
              <circle cx="380" cy="50" r="45" fill="#FFB7C5" opacity="0.9" />
              <circle cx="340" cy="70" r="35" fill="#FFB7C5" opacity="0.9" />
              <circle cx="420" cy="70" r="35" fill="#FFB7C5" opacity="0.9" />
              <circle cx="380" cy="100" r="40" fill="#FFB7C5" opacity="0.9" />
              
              {/* Middle blossoms */}
              <circle cx="320" cy="180" r="35" fill="#FFB7C5" opacity="0.9" />
              <circle cx="280" cy="200" r="30" fill="#FFB7C5" opacity="0.9" />
              <circle cx="350" cy="210" r="35" fill="#FFB7C5" opacity="0.9" />
              
              <circle cx="440" cy="180" r="35" fill="#FFB7C5" opacity="0.9" />
              <circle cx="480" cy="200" r="30" fill="#FFB7C5" opacity="0.9" />
              <circle cx="410" cy="210" r="35" fill="#FFB7C5" opacity="0.9" />
              
              {/* Center blossoms */}
              <circle cx="380" cy="150" r="40" fill="#FFB7C5" opacity="0.9" />
              <circle cx="340" cy="140" r="30" fill="#FFB7C5" opacity="0.9" />
              <circle cx="420" cy="140" r="30" fill="#FFB7C5" opacity="0.9" />
              <circle cx="380" cy="180" r="35" fill="#FFB7C5" opacity="0.9" />
            </g>
          </svg>
        )}
        
        {theme === "autumn" && (
          <svg width="100%" height="100%" viewBox="0 0 800 800" preserveAspectRatio="xMidYMid meet" className="max-w-5xl">
            {/* Ground/Grass */}
            <ellipse cx="400" cy="730" rx="300" ry="30" fill="#8B5A2B" opacity="0.7" />
            <ellipse cx="400" cy="730" rx="280" ry="20" fill="#DAA520" opacity="0.3" />
            
            {/* Tree trunk */}
            <path 
              d="M380,730 C360,650 350,600 350,550 C350,500 360,450 380,400 C400,450 410,500 410,550 C410,600 400,650 380,730 Z" 
              fill="#8B4513"
            />
            
            {/* Main trunk */}
            <path 
              d="M380,400 C360,350 350,300 350,250 C350,200 360,150 380,100 C400,150 410,200 410,250 C410,300 400,350 380,400 Z" 
              fill="#A0522D"
            />
            
            {/* Main branches */}
            <path 
              d="M380,250 C340,230 300,200 270,150 C240,100 230,50 250,20 C280,40 300,70 320,120 C340,170 360,220 380,250 Z" 
              fill="#A0522D"
            />
            <path 
              d="M380,250 C420,230 460,200 490,150 C520,100 530,50 510,20 C480,40 460,70 440,120 C420,170 400,220 380,250 Z" 
              fill="#A0522D"
            />
            
            {/* Secondary branches - left */}
            <path 
              d="M270,150 C250,140 220,130 190,140 C160,150 140,170 130,200 C150,190 170,190 190,200 C210,210 240,180 270,150 Z" 
              fill="#A0522D"
            />
            <path 
              d="M320,120 C300,100 280,70 270,40 C260,10 270,-10 290,-20 C300,0 310,20 315,50 C320,80 320,100 320,120 Z" 
              fill="#A0522D"
            />
            
            {/* Secondary branches - right */}
            <path 
              d="M490,150 C510,140 540,130 570,140 C600,150 620,170 630,200 C610,190 590,190 570,200 C550,210 520,180 490,150 Z" 
              fill="#A0522D"
            />
            <path 
              d="M440,120 C460,100 480,70 490,40 C500,10 490,-10 470,-20 C460,0 450,20 445,50 C440,80 440,100 440,120 Z" 
              fill="#A0522D"
            />
            
            {/* Tertiary branches */}
            <path 
              d="M190,140 C170,120 140,110 110,120 C130,130 150,140 170,140 C180,140 190,140 190,140 Z" 
              fill="#A0522D"
            />
            <path 
              d="M570,140 C590,120 620,110 650,120 C630,130 610,140 590,140 C580,140 570,140 570,140 Z" 
              fill="#A0522D"
            />
            <path 
              d="M270,40 C250,20 240,-10 250,-30 C260,-10 270,10 275,30 C275,35 270,40 270,40 Z" 
              fill="#A0522D"
            />
            <path 
              d="M490,40 C510,20 520,-10 510,-30 C500,-10 490,10 485,30 C485,35 490,40 490,40 Z" 
              fill="#A0522D"
            />
            
            {/* Autumn leaf clusters */}
            <g>
              {/* Left side leaves */}
              <circle cx="190" cy="140" r="40" fill="#FF8C00" opacity="0.9" />
              <circle cx="150" cy="120" r="35" fill="#FF4500" opacity="0.9" />
              <circle cx="220" cy="110" r="30" fill="#CD5C5C" opacity="0.9" />
              <circle cx="240" cy="150" r="35" fill="#FF6347" opacity="0.9" />
              <circle cx="200" cy="180" r="30" fill="#FF7F50" opacity="0.9" />
              
              {/* Right side leaves */}
              <circle cx="570" cy="140" r="40" fill="#FF8C00" opacity="0.9" />
              <circle cx="610" cy="120" r="35" fill="#FF4500" opacity="0.9" />
              <circle cx="540" cy="110" r="30" fill="#CD5C5C" opacity="0.9" />
              <circle cx="520" cy="150" r="35" fill="#FF6347" opacity="0.9" />
              <circle cx="560" cy="180" r="30" fill="#FF7F50" opacity="0.9" />
              
              {/* Top leaves */}
              <circle cx="270" cy="40" r="35" fill="#FF8C00" opacity="0.9" />
              <circle cx="240" cy="10" r="30" fill="#FF4500" opacity="0.9" />
              <circle cx="290" cy="0" r="25" fill="#CD5C5C" opacity="0.9" />
              <circle cx="320" cy="30" r="30" fill="#FF6347" opacity="0.9" />
              
              <circle cx="490" cy="40" r="35" fill="#FF8C00" opacity="0.9" />
              <circle cx="520" cy="10" r="30" fill="#FF4500" opacity="0.9" />
              <circle cx="470" cy="0" r="25" fill="#CD5C5C" opacity="0.9" />
              <circle cx="440" cy="30" r="30" fill="#FF6347" opacity="0.9" />
              
              {/* Center top leaves */}
              <circle cx="380" cy="50" r="45" fill="#FF8C00" opacity="0.9" />
              <circle cx="340" cy="70" r="35" fill="#FF4500" opacity="0.9" />
              <circle cx="420" cy="70" r="35" fill="#CD5C5C" opacity="0.9" />
              <circle cx="380" cy="100" r="40" fill="#FF6347" opacity="0.9" />
              
              {/* Middle leaves */}
              <circle cx="320" cy="180" r="35" fill="#FF8C00" opacity="0.9" />
              <circle cx="280" cy="200" r="30" fill="#FF4500" opacity="0.9" />
              <circle cx="350" cy="210" r="35" fill="#CD5C5C" opacity="0.9" />
              
              <circle cx="440" cy="180" r="35" fill="#FF8C00" opacity="0.9" />
              <circle cx="480" cy="200" r="30" fill="#FF4500" opacity="0.9" />
              <circle cx="410" cy="210" r="35" fill="#CD5C5C" opacity="0.9" />
              
              {/* Center leaves */}
              <circle cx="380" cy="150" r="40" fill="#FF8C00" opacity="0.9" />
              <circle cx="340" cy="140" r="30" fill="#FF4500" opacity="0.9" />
              <circle cx="420" cy="140" r="30" fill="#CD5C5C" opacity="0.9" />
              <circle cx="380" cy="180" r="35" fill="#FF6347" opacity="0.9" />
            </g>
          </svg>
        )}
        
        {theme === "plain" && (
          <svg width="100%" height="100%" viewBox="0 0 800 800" preserveAspectRatio="xMidYMid meet" className="max-w-5xl">
            {/* Ground/Grass */}
            <ellipse cx="400" cy="730" rx="300" ry="30" fill="#8B5A2B" opacity="0.7" />
            <ellipse cx="400" cy="730" rx="280" ry="20" fill="#7CFC00" opacity="0.3" />
            
            {/* Tree trunk */}
            <path 
              d="M380,730 C360,650 350,600 350,550 C350,500 360,450 380,400 C400,450 410,500 410,550 C410,600 400,650 380,730 Z" 
              fill="#8B4513"
            />
            
            {/* Main trunk */}
            <path 
              d="M380,400 C360,350 350,300 350,250 C350,200 360,150 380,100 C400,150 410,200 410,250 C410,300 400,350 380,400 Z" 
              fill="#A0522D"
            />
            
            {/* Main branches */}
            <path 
              d="M380,250 C340,230 300,200 270,150 C240,100 230,50 250,20 C280,40 300,70 320,120 C340,170 360,220 380,250 Z" 
              fill="#A0522D"
            />
            <path 
              d="M380,250 C420,230 460,200 490,150 C520,100 530,50 510,20 C480,40 460,70 440,120 C420,170 400,220 380,250 Z" 
              fill="#A0522D"
            />
            
            {/* Secondary branches - left */}
            <path 
              d="M270,150 C250,140 220,130 190,140 C160,150 140,170 130,200 C150,190 170,190 190,200 C210,210 240,180 270,150 Z" 
              fill="#A0522D"
            />
            <path 
              d="M320,120 C300,100 280,70 270,40 C260,10 270,-10 290,-20 C300,0 310,20 315,50 C320,80 320,100 320,120 Z" 
              fill="#A0522D"
            />
            
            {/* Secondary branches - right */}
            <path 
              d="M490,150 C510,140 540,130 570,140 C600,150 620,170 630,200 C610,190 590,190 570,200 C550,210 520,180 490,150 Z" 
              fill="#A0522D"
            />
            <path 
              d="M440,120 C460,100 480,70 490,40 C500,10 490,-10 470,-20 C460,0 450,20 445,50 C440,80 440,100 440,120 Z" 
              fill="#A0522D"
            />
            
            {/* Tertiary branches */}
            <path 
              d="M190,140 C170,120 140,110 110,120 C130,130 150,140 170,140 C180,140 190,140 190,140 Z" 
              fill="#A0522D"
            />
            <path 
              d="M570,140 C590,120 620,110 650,120 C630,130 610,140 590,140 C580,140 570,140 570,140 Z" 
              fill="#A0522D"
            />
            <path 
              d="M270,40 C250,20 240,-10 250,-30 C260,-10 270,10 275,30 C275,35 270,40 270,40 Z" 
              fill="#A0522D"
            />
            <path 
              d="M490,40 C510,20 520,-10 510,-30 C500,-10 490,10 485,30 C485,35 490,40 490,40 Z" 
              fill="#A0522D"
            />
            
            {/* Green leaf clusters */}
            <g>
              {/* Left side leaves */}
              <circle cx="190" cy="140" r="40" fill="#32CD32" opacity="0.9" />
              <circle cx="150" cy="120" r="35" fill="#228B22" opacity="0.9" />
              <circle cx="220" cy="110" r="30" fill="#008000" opacity="0.9" />
              <circle cx="240" cy="150" r="35" fill="#3CB371" opacity="0.9" />
              <circle cx="200" cy="180" r="30" fill="#2E8B57" opacity="0.9" />
              
              {/* Right side leaves */}
              <circle cx="570" cy="140" r="40" fill="#32CD32" opacity="0.9" />
              <circle cx="610" cy="120" r="35" fill="#228B22" opacity="0.9" />
              <circle cx="540" cy="110" r="30" fill="#008000" opacity="0.9" />
              <circle cx="520" cy="150" r="35" fill="#3CB371" opacity="0.9" />
              <circle cx="560" cy="180" r="30" fill="#2E8B57" opacity="0.9" />
              
              {/* Top leaves */}
              <circle cx="270" cy="40" r="35" fill="#32CD32" opacity="0.9" />
              <circle cx="240" cy="10" r="30" fill="#228B22" opacity="0.9" />
              <circle cx="290" cy="0" r="25" fill="#008000" opacity="0.9" />
              <circle cx="320" cy="30" r="30" fill="#3CB371" opacity="0.9" />
              
              <circle cx="490" cy="40" r="35" fill="#32CD32" opacity="0.9" />
              <circle cx="520" cy="10" r="30" fill="#228B22" opacity="0.9" />
              <circle cx="470" cy="0" r="25" fill="#008000" opacity="0.9" />
              <circle cx="440" cy="30" r="30" fill="#3CB371" opacity="0.9" />
              
              {/* Center top leaves */}
              <circle cx="380" cy="50" r="45" fill="#32CD32" opacity="0.9" />
              <circle cx="340" cy="70" r="35" fill="#228B22" opacity="0.9" />
              <circle cx="420" cy="70" r="35" fill="#008000" opacity="0.9" />
              <circle cx="380" cy="100" r="40" fill="#3CB371" opacity="0.9" />
              
              {/* Middle leaves */}
              <circle cx="320" cy="180" r="35" fill="#32CD32" opacity="0.9" />
              <circle cx="280" cy="200" r="30" fill="#228B22" opacity="0.9" />
              <circle cx="350" cy="210" r="35" fill="#008000" opacity="0.9" />
              
              <circle cx="440" cy="180" r="35" fill="#32CD32" opacity="0.9" />
              <circle cx="480" cy="200" r="30" fill="#228B22" opacity="0.9" />
              <circle cx="410" cy="210" r="35" fill="#008000" opacity="0.9" />
              
              {/* Center leaves */}
              <circle cx="380" cy="150" r="40" fill="#32CD32" opacity="0.9" />
              <circle cx="340" cy="140" r="30" fill="#228B22" opacity="0.9" />
              <circle cx="420" cy="140" r="30" fill="#008000" opacity="0.9" />
              <circle cx="380" cy="180" r="35" fill="#3CB371" opacity="0.9" />
            </g>
          </svg>
        )}
      </div>
      
      {/* Memory photos as leaves */}
      <div className="absolute inset-0 pointer-events-none">
        {memories.map((memory) => (
          <motion.div
            key={memory.id}
            className="absolute cursor-pointer pointer-events-auto"
            style={{ 
              left: `calc(50% + ${memory.position.x}px)`, 
              top: `calc(50% + ${memory.position.y}px)` 
            }}
            whileHover={{ scale: 1.1 }}
            onClick={() => onMemoryClick(memory)}
          >
            <motion.div 
              className={`relative w-16 h-16 rounded-full overflow-hidden border-2 border-white shadow-lg ${theme === "sakura" ? "leaf-shape" : "rounded-full"}`}
              animate={{ 
                rotate: [0, 5, 0, -5, 0],
              }}
              transition={{ 
                duration: 5 + Math.random() * 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <img 
                src={memory.imageUrl} 
                alt={memory.text}
                className="w-full h-full object-cover"
              />
              <div className={`absolute inset-0 ${theme === "sakura" ? "bg-pink-200/30" : theme === "autumn" ? "bg-orange-200/30" : "bg-green-200/30"} transition-colors duration-500`}></div>
            </motion.div>
            
            <motion.div
              className="absolute -top-1 -right-1 text-primary"
              animate={{ 
                rotate: [0, 10, 0, -10, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                repeatType: "reverse"
              }}
            >
              <Heart className="h-4 w-4 fill-primary" />
            </motion.div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
