
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import { Heart, Leaf, Settings, Calendar, PlusCircle } from "lucide-react";
import { AmoreStreakCounter } from "@/components/AmoreStreakCounter";
import { AddMemoryModal } from "@/components/love-tree/AddMemoryModal";
import { MemoryViewer } from "@/components/love-tree/MemoryViewer";
import { TreeThemeSelector } from "@/components/love-tree/TreeThemeSelector";
import { CherryBlossomTree } from '@/components/love-tree/CherryBlossomTree';

interface Memory {
  id: string;
  imageUrl: string;
  text: string;
  date: string;
  position: {
    x: number;
    y: number;
  };
}

export function LoveTree() {
  const [activeTheme, setActiveTheme] = useState<"sakura" | "autumn" | "plain">("sakura");
  const [showAddMemoryModal, setShowAddMemoryModal] = useState(false);
  const [selectedMemory, setSelectedMemory] = useState<Memory | null>(null);
  
  // Sample data
  const coupleData = {
    partner1: {
      name: "Sarah",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80"
    },
    partner2: {
      name: "Michael",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80"
    },
    daysTogether: 125,
    amoreStreak: 28
  };
  
  const sampleMemories: Memory[] = [
    {
      id: "1",
      imageUrl: "https://images.unsplash.com/photo-1522673607200-164d1b6ce486?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80",
      text: "Our first date at the beach",
      date: "2024-12-15",
      position: { x: -80, y: 20 }
    },
    {
      id: "2",
      imageUrl: "https://images.unsplash.com/photo-1522748906645-95d8adfd52c7?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80",
      text: "Weekend getaway",
      date: "2025-01-22",
      position: { x: 100, y: -30 }
    },
    {
      id: "3",
      imageUrl: "https://images.unsplash.com/photo-1523301343968-6a6ebf63c672?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80",
      text: "Cooking together",
      date: "2025-02-14",
      position: { x: 40, y: 80 }
    }
  ];
  
  const handleOpenMemory = (memory: Memory) => {
    setSelectedMemory(memory);
  };
  
  const handleCloseMemory = () => {
    setSelectedMemory(null);
  };
  
  const getTreeBackground = () => {
    switch (activeTheme) {
      case "sakura":
        return "bg-gradient-to-b from-pink-100 to-pink-200";
      case "autumn":
        return "bg-gradient-to-b from-orange-100 to-amber-200";
      case "plain":
        return "bg-gradient-to-b from-blue-50 to-purple-100";
      default:
        return "bg-gradient-to-b from-pink-100 to-pink-200";
    }
  };
  
  const getTreeColor = () => {
    switch (activeTheme) {
      case "sakura":
        return "text-pink-800";
      case "autumn":
        return "text-amber-800";
      case "plain":
        return "text-purple-800";
      default:
        return "text-pink-800";
    }
  };
  
  const getLeafColor = () => {
    switch (activeTheme) {
      case "sakura":
        return "text-pink-400 fill-pink-200";
      case "autumn":
        return "text-orange-400 fill-orange-200";
      case "plain":
        return "text-green-400 fill-green-200";
      default:
        return "text-pink-400 fill-pink-200";
    }
  };

  return (
    <div className="min-h-screen romantic-gradient flex flex-col">
      {/* Top Bar */}
      <header className="w-full py-4 px-6 flex items-center justify-between bg-white/80 backdrop-blur-sm border-b border-pink-100">
        <div className="flex items-center gap-2">
          <Avatar className="border-2 border-primary/50 h-10 w-10">
            <AvatarFallback>{coupleData.partner1.name[0]}</AvatarFallback>
            <AvatarImage src={coupleData.partner1.avatar} alt={coupleData.partner1.name} />
          </Avatar>
          <Avatar className="border-2 border-primary/50 h-10 w-10 -ml-2">
            <AvatarFallback>{coupleData.partner2.name[0]}</AvatarFallback>
            <AvatarImage src={coupleData.partner2.avatar} alt={coupleData.partner2.name} />
          </Avatar>
        </div>
        
        <div className="flex flex-col items-center">
          <h1 className="text-2xl font-bold text-foreground tracking-wide">Love Tree</h1>
          <div className="flex items-center gap-1">
            <LitAmorLogo size="small" />
            <span className="text-xs text-muted-foreground">Lit Amor</span>
          </div>
        </div>
        
        <Button variant="ghost" size="icon" className="rounded-full">
          <Settings className="h-5 w-5 text-muted-foreground" />
        </Button>
      </header>
      
      {/* Stats Bar */}
      <div className="w-full py-3 px-6 flex items-center justify-between bg-white/50 backdrop-blur-sm border-b border-pink-100">
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium">{coupleData.daysTogether} Days Together</span>
        </div>
        
        <div className="flex items-center gap-2">
          <AmoreStreakCounter count={coupleData.amoreStreak} />
          <span className="text-sm font-medium">Amore Streak</span>
        </div>
      </div>
      
      {/* Tree Display */}
      <div className="flex-1 relative overflow-hidden">
        <div className={`absolute inset-0 ${getTreeBackground()} transition-colors duration-500`}></div>
        
        {/* Tree trunk and branches */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <svg width="280" height="360" viewBox="0 0 280 360" className="transform scale-110">
            <g className={`${getTreeColor()} transition-colors duration-500`}>
              {/* Tree trunk */}
              <path d="M140,360 C120,360 110,320 110,280 C110,240 120,200 140,160 C160,200 170,240 170,280 C170,320 160,360 140,360 Z" 
                fill="currentColor" />
              
              {/* Left branch */}
              <path d="M140,160 C120,160 90,140 70,100 C50,60 60,30 80,20 C100,30 110,60 120,100 C130,140 140,160 140,160 Z" 
                fill="currentColor" />
              
              {/* Right branch */}
              <path d="M140,160 C160,160 190,140 210,100 C230,60 220,30 200,20 C180,30 170,60 160,100 C150,140 140,160 140,160 Z" 
                fill="currentColor" />
              
              {/* Small branches */}
              <path d="M80,20 C70,10 60,0 40,10 C60,20 70,30 80,20 Z" fill="currentColor" />
              <path d="M200,20 C210,10 220,0 240,10 C220,20 210,30 200,20 Z" fill="currentColor" />
              <path d="M70,100 C60,90 40,90 30,100 C40,110 60,110 70,100 Z" fill="currentColor" />
              <path d="M210,100 C220,90 240,90 250,100 C240,110 220,110 210,100 Z" fill="currentColor" />
            </g>
            
            {/* Decorative leaves */}
            <g className={`${getLeafColor()} transition-colors duration-500`}>
              <circle cx="40" cy="10" r="10" />
              <circle cx="240" cy="10" r="10" />
              <circle cx="30" cy="100" r="10" />
              <circle cx="250" cy="100" r="10" />
              <circle cx="100" cy="50" r="8" />
              <circle cx="180" cy="50" r="8" />
              <circle cx="90" cy="120" r="8" />
              <circle cx="190" cy="120" r="8" />
              <circle cx="140" cy="90" r="8" />
            </g>
          </svg>
        </div>
        
        {/* Memory photos */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="relative w-full h-full">
            {sampleMemories.map((memory) => (
              <motion.div
                key={memory.id}
                className="absolute cursor-pointer"
                style={{ 
                  left: `calc(50% + ${memory.position.x}px)`, 
                  top: `calc(50% + ${memory.position.y}px)` 
                }}
                whileHover={{ scale: 1.05 }}
                onClick={() => handleOpenMemory(memory)}
              >
                <div className="w-20 h-20 rounded-lg overflow-hidden border-2 border-white shadow-lg">
                  <img 
                    src={memory.imageUrl} 
                    alt={memory.text}
                    className="w-full h-full object-cover"
                  />
                </div>
                <motion.div
                  className={`absolute -top-1 -right-1 ${getLeafColor()} transition-colors duration-500`}
                >
                  <Leaf className="h-5 w-5" />
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Bottom Bar */}
      <div className="w-full py-4 px-6 flex items-center justify-between bg-white/80 backdrop-blur-sm border-t border-pink-100">
        <TreeThemeSelector activeTheme={activeTheme} onChange={setActiveTheme} />
        
        <Button 
          onClick={() => setShowAddMemoryModal(true)}
          className="bg-primary hover:bg-primary/90 text-white font-medium rounded-full px-6 py-6 flex items-center gap-2"
        >
          <PlusCircle className="h-5 w-5" />
          <span>Add Memory</span>
        </Button>
        
        <Button variant="outline" size="icon" className="rounded-full border-pink-200 h-10 w-10">
          <Heart className="h-5 w-5 text-primary" />
        </Button>
      </div>
      
      {/* Memory Viewer Modal */}
      <AnimatePresence>
        {selectedMemory && (
          <MemoryViewer memory={selectedMemory} onClose={handleCloseMemory} />
        )}
      </AnimatePresence>
      
      {/* Add Memory Modal */}
      <AnimatePresence>
        {showAddMemoryModal && (
          <AddMemoryModal onClose={() => setShowAddMemoryModal(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}
