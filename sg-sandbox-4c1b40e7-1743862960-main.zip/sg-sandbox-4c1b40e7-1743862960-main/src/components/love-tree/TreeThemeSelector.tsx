import { Button } from "@/components/ui/button";
import { Palette } from "lucide-react";
import { motion } from 'framer-motion';

interface TreeThemeSelectorProps {
  activeTheme: "sakura" | "autumn" | "plain";
  onChange: (theme: "sakura" | "autumn" | "plain") => void;
}

export function TreeThemeSelector({ activeTheme, onChange }: TreeThemeSelectorProps) {
  return (
    <div className="relative group">
      <Button variant="outline" size="icon" className="rounded-full border-pink-200 h-10 w-10">
        <Palette className="h-5 w-5 text-muted-foreground" />
      </Button>
      
      <div className="absolute bottom-full left-0 mb-2 bg-white rounded-lg shadow-lg border border-pink-100 p-2 hidden group-hover:block">
        <div className="flex flex-col gap-2 w-32">
          <Button
            variant="ghost"
            className={`justify-start rounded-md px-3 py-2 text-sm ${activeTheme === "sakura" ? "bg-pink-100" : ""}`}
            onClick={() => onChange("sakura")}
          >
            <div className="w-4 h-4 rounded-full bg-pink-400 mr-2"></div>
            Sakura
          </Button>
          
          <Button
            variant="ghost"
            className={`justify-start rounded-md px-3 py-2 text-sm ${activeTheme === "autumn" ? "bg-orange-100" : ""}`}
            onClick={() => onChange("autumn")}
          >
            <div className="w-4 h-4 rounded-full bg-orange-400 mr-2"></div>
            Autumn
          </Button>
          
          <Button
            variant="ghost"
            className={`justify-start rounded-md px-3 py-2 text-sm ${activeTheme === "plain" ? "bg-purple-100" : ""}`}
            onClick={() => onChange("plain")}
          >
            <div className="w-4 h-4 rounded-full bg-purple-400 mr-2"></div>
            Plain
          </Button>
        </div>
      </div>
    </div>
  );
}