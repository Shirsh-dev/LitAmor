
import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Camera, X, Upload } from "lucide-react";

interface AddMemoryModalProps {
  onClose: () => void;
}

export function AddMemoryModal({ onClose }: AddMemoryModalProps) {
  const [memoryText, setMemoryText] = useState("");
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save the memory
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div 
        className="bg-white rounded-2xl w-full max-w-md mx-4 overflow-hidden shadow-xl"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.2 }}
      >
        <div className="p-4 border-b border-pink-100 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-foreground">Add New Memory</h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full">
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Upload Photo</label>
            <div className="border-2 border-dashed border-pink-200 rounded-xl p-4 flex flex-col items-center justify-center bg-pink-50/50">
              {previewImage ? (
                <div className="relative w-full aspect-square rounded-lg overflow-hidden">
                  <img 
                    src={previewImage} 
                    alt="Memory preview"
                    className="w-full h-full object-cover"
                  />
                  <Button 
                    type="button"
                    variant="ghost" 
                    size="icon" 
                    className="absolute top-2 right-2 bg-black/30 hover:bg-black/40 text-white rounded-full h-8 w-8"
                    onClick={() => setPreviewImage(null)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <>
                  <Camera className="h-12 w-12 text-pink-300 mb-2" />
                  <p className="text-sm text-center text-muted-foreground mb-4">
                    Upload a photo for your memory
                  </p>
                  <div className="flex gap-4">
                    <label className="cursor-pointer">
                      <Input 
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={handleImageUpload}
                      />
                      <Button type="button" variant="outline" className="rounded-full">
                        <Upload className="h-4 w-4 mr-2" />
                        Choose File
                      </Button>
                    </label>
                    <Button type="button" variant="outline" className="rounded-full">
                      <Camera className="h-4 w-4 mr-2" />
                      Take Photo
                    </Button>
                  </div>
                </>
              )}
            </div>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Memory Description</label>
            <Textarea 
              placeholder="Write something about this memory..."
              className="resize-none h-24"
              value={memoryText}
              onChange={(e) => setMemoryText(e.target.value)}
            />
          </div>
          
          <div className="pt-4 flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onClose} className="rounded-full">
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-primary hover:bg-primary/90 text-white rounded-full"
              disabled={!previewImage || !memoryText.trim()}
            >
              Add to Tree
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
