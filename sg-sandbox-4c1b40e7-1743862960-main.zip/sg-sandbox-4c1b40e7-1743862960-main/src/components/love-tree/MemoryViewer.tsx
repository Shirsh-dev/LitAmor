
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { X, Heart, Calendar } from "lucide-react";
import { formatDate } from "@/lib/utils";

interface Memory {
  id: string;
  imageUrl: string;
  text: string;
  date: string;
  position: {
    x: number;
    y: number;
  };
}

interface MemoryViewerProps {
  memory: Memory;
  onClose: () => void;
}

export function MemoryViewer({ memory, onClose }: MemoryViewerProps) {
  const formattedDate = formatDate(memory.date);
  
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div 
        className="bg-white rounded-2xl w-full max-w-md mx-4 overflow-hidden shadow-xl"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.2 }}
      >
        <div className="relative aspect-square">
          <img 
            src={memory.imageUrl} 
            alt={memory.text}
            className="w-full h-full object-cover"
          />
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute top-4 right-4 bg-black/30 hover:bg-black/40 text-white rounded-full"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span className="text-sm">{formattedDate}</span>
            </div>
            
            <Button variant="ghost" size="icon" className="text-primary rounded-full">
              <Heart className="h-5 w-5" />
            </Button>
          </div>
          
          <p className="text-foreground">{memory.text}</p>
        </div>
      </motion.div>
    </div>
  );
}
