
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Pin, MessageCircle } from "lucide-react";

interface Conversation {
  id: string;
  matchName: string;
  lastMessage: string;
  timestamp: string;
  isPinned: boolean;
  unreadCount: number;
}

interface PinnedConversationsProps {
  conversations: Conversation[];
}

export default function PinnedConversations({ conversations }: PinnedConversationsProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Pin className="w-4 h-4 text-purple-500" />
        <h3 className="text-lg font-semibold text-gray-800">Pinned Conversations</h3>
      </div>

      <div className="space-y-3">
        {conversations.map((conversation, index) => (
          <motion.div
            key={conversation.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
          >
            <Card className="bg-white/60 backdrop-blur-sm border-purple-200 hover:border-purple-300 transition-all duration-300 cursor-pointer hover:shadow-md">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center">
                      <MessageCircle className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <h4 className="font-medium text-gray-800 truncate">
                          {conversation.matchName}
                        </h4>
                        {conversation.isPinned && (
                          <Pin className="w-3 h-3 text-purple-500" />
                        )}
                      </div>
                      <p className="text-sm text-gray-600 truncate">
                        {conversation.lastMessage}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {conversation.timestamp}
                      </p>
                    </div>
                  </div>
                  
                  {conversation.unreadCount > 0 && (
                    <Badge 
                      className="bg-pink-500 text-white text-xs min-w-[20px] h-5 flex items-center justify-center rounded-full"
                    >
                      {conversation.unreadCount}
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
