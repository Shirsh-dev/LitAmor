
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Heart, X, Star, Lock } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface PersonalityPrompt {
  question: string;
  answer: string;
}

interface ProfileCardProps {
  name: string;
  age: number;
  prompts: PersonalityPrompt[];
  interests: string[];
  compatibility: number;
  onVibe: () => void;
  onPass: () => void;
  onSave: () => void;
  onUnlock: () => void;
}

export function ProfileCard({
  name,
  age,
  prompts,
  interests,
  compatibility,
  onVibe,
  onPass,
  onSave,
  onUnlock
}: ProfileCardProps) {
  return (
    <motion.div 
      className="w-full max-w-sm bg-white rounded-3xl overflow-hidden shadow-xl border border-pink-100"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      drag="y"
      dragConstraints={{ top: 0, bottom: 0 }}
      dragElastic={0.7}
      onDragEnd={(e, info) => {
        if (info.offset.y < -100) {
          onVibe();
        } else if (info.offset.y > 100) {
          onPass();
        }
      }}
    >
      {/* Header with name, age and compatibility */}
      <div className="p-6 pb-4 border-b border-pink-100">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-800">{name}, {age}</h2>
          <div className="flex flex-col items-end">
            <span className="text-sm text-gray-500 mb-1">Compatibility</span>
            <div className="flex items-center gap-2">
              <Progress 
                value={compatibility} 
                max={100} 
                className="w-24 h-2 bg-pink-100" 
                indicatorClassName="bg-gradient-to-r from-pink-400 to-purple-400" 
              />
              <span className="text-sm font-medium text-gray-700">{compatibility}%</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Personality prompts */}
      <div className="p-6 space-y-5">
        {prompts.map((prompt, index) => (
          <div key={index} className="space-y-1">
            <h3 className="text-sm font-medium text-gray-500">{prompt.question}</h3>
            <p className="text-gray-800">{prompt.answer}</p>
          </div>
        ))}
        
        {/* Interests */}
        <div className="pt-2">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Interests</h3>
          <div className="flex flex-wrap gap-2">
            {interests.map((interest, index) => (
              <Badge key={index} variant="outline" className="bg-pink-50 text-pink-700 hover:bg-pink-100 border-pink-200">
                {interest}
              </Badge>
            ))}
          </div>
        </div>
        
        {/* Locked Clipsy section */}
        <div className="mt-6 bg-gray-50 rounded-xl p-4 border border-gray-200 flex items-center justify-between">
          <div>
            <h3 className="font-medium text-gray-700">Clipsy hidden</h3>
            <p className="text-sm text-gray-500">Unlock with Vibe Match</p>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="rounded-full text-gray-400 hover:text-gray-600"
            onClick={onUnlock}
          >
            <Lock className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Action buttons */}
      <div className="p-6 pt-2 flex items-center justify-between bg-gray-50 border-t border-gray-100">
        <Button 
          variant="outline" 
          size="icon" 
          className="h-14 w-14 rounded-full border-pink-200 hover:bg-pink-50 hover:text-pink-600"
          onClick={onPass}
        >
          <X className="h-6 w-6" />
          <span className="sr-only">Pass</span>
        </Button>
        
        <Button 
          className="h-16 w-16 rounded-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white shadow-lg"
          onClick={onVibe}
        >
          <Heart className="h-8 w-8" />
          <span className="sr-only">Vibe</span>
        </Button>
        
        <Button 
          variant="outline" 
          size="icon" 
          className="h-14 w-14 rounded-full border-pink-200 hover:bg-pink-50 hover:text-pink-600"
          onClick={onSave}
        >
          <Star className="h-6 w-6" />
          <span className="sr-only">Save for Later</span>
        </Button>
      </div>
    </motion.div>
  );
}
