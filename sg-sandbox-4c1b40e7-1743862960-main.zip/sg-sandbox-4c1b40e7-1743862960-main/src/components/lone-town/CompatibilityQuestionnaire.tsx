
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Heart, ChevronRight, ChevronLeft, AlertCircle } from "lucide-react";
import { CompatibilityQuestionnaire, EditWarning } from "@/types/loneTown";

// Define strict types for form fields to enable discriminated unions
type FieldBase = {
  name: keyof CompatibilityQuestionnaire;
  label: string;
  points: number;
};

type SelectField = FieldBase & {
  type: "select";
  options: string[];
};

type InputField = FieldBase & {
  type: "input";
  placeholder: string;
};

type MultiSelectField = FieldBase & {
  type: "multiselect";
  options: string[];
  maxSelections: number;
};

type HeightRangeField = FieldBase & {
  type: "height-range";
  name: "heightPreference";
};

type FormField = SelectField | InputField | MultiSelectField | HeightRangeField;

interface Step {
  title: string;
  fields: FormField[];
}

interface CompatibilityQuestionnaireProps {
  initialData?: Partial<CompatibilityQuestionnaire>;
  onComplete: (data: CompatibilityQuestionnaire) => void;
  onSkip?: () => void;
  showEditWarning?: EditWarning;
}

export default function CompatibilityQuestionnaireComponent({ 
  initialData, 
  onComplete, 
  onSkip,
  showEditWarning 
}: CompatibilityQuestionnaireProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<Partial<CompatibilityQuestionnaire>>(initialData || {
    priorities: []
  });

  const steps: Step[] = [
    {
      title: "Relationship Goals",
      fields: [
        {
          name: "relationshipTypeSeeking",
          label: "What type of relationship are you seeking?",
          type: "select",
          options: [
            "Long-term committed",
            "Marriage-oriented",
            "Open to possibilities",
            "Taking it slow",
            "Life partnership"
          ],
          points: 10
        }
      ]
    },
    {
      title: "Lifestyle Choices",
      fields: [
        {
          name: "smoking",
          label: "Smoking habits",
          type: "select",
          options: ["Never", "Socially", "Regularly", "Trying to quit"],
          points: 1
        },
        {
          name: "drinking",
          label: "Drinking habits",
          type: "select",
          options: ["Never", "Socially", "Regularly", "Occasionally"],
          points: 1
        },
        {
          name: "diet",
          label: "Dietary preference",
          type: "select",
          options: ["Vegetarian", "Non-Vegetarian", "Vegan", "Flexible"],
          points: 2
        }
      ]
    },
    {
      title: "Cultural Background",
      fields: [
        {
          name: "religion",
          label: "Religious/Spiritual beliefs",
          type: "select",
          options: [
            "Hindu",
            "Muslim",
            "Christian",
            "Sikh",
            "Buddhist",
            "Jain",
            "Spiritual but not religious",
            "Atheist/Agnostic",
            "Other"
          ],
          points: 5
        },
        {
          name: "ethnicity",
          label: "Cultural background",
          type: "input",
          placeholder: "e.g., North Indian, South Indian, etc.",
          points: 0
        },
        {
          name: "firstLanguage",
          label: "First language",
          type: "select",
          options: [
            "Hindi",
            "English",
            "Tamil",
            "Telugu",
            "Bengali",
            "Marathi",
            "Gujarati",
            "Kannada",
            "Malayalam",
            "Punjabi",
            "Other"
          ],
          points: 5
        }
      ]
    },
    {
      title: "Career & Values",
      fields: [
        {
          name: "profession",
          label: "Your profession/field",
          type: "input",
          placeholder: "e.g., Software Engineer, Teacher, Entrepreneur",
          points: 5
        },
        {
          name: "politicalViews",
          label: "Political/social views",
          type: "select",
          options: [
            "Progressive",
            "Liberal",
            "Moderate",
            "Conservative",
            "Apolitical",
            "Prefer not to say"
          ],
          points: 3
        },
        {
          name: "priorities",
          label: "Life priorities (select up to 3)",
          type: "multiselect",
          options: ["Love & Relationships", "Career Growth", "Financial Security", "Family", "Personal Growth", "Adventure"],
          maxSelections: 3,
          points: 3
        }
      ]
    },
    {
      title: "Personality & Compatibility",
      fields: [
        {
          name: "sexualAttraction",
          label: "Sexual orientation",
          type: "select",
          options: [
            "Heterosexual",
            "Homosexual",
            "Bisexual",
            "Pansexual",
            "Asexual",
            "Prefer not to say"
          ],
          points: 5
        },
        {
          name: "pastRelationships",
          label: "Relationship history",
          type: "select",
          options: [
            "Never been in a relationship",
            "Few short-term relationships",
            "One long-term relationship",
            "Multiple long-term relationships",
            "Divorced/Separated",
            "Prefer not to say"
          ],
          points: 3
        }
      ]
    },
    {
      title: "Personality Type",
      fields: [
        {
          name: "personalityType",
          label: "Your personality",
          type: "select",
          options: [
            "Introvert",
            "Extrovert",
            "Ambivert",
            "Social but selective"
          ],
          points: 2
        },
        {
          name: "loveLanguage",
          label: "Primary love language",
          type: "select",
          options: [
            "Words of Affirmation",
            "Quality Time",
            "Physical Touch",
            "Acts of Service",
            "Receiving Gifts"
          ],
          points: 3
        },
        {
          name: "lifestyle",
          label: "Lifestyle preference",
          type: "select",
          options: [
            "Outdoorsy & Active",
            "Homebody & Cozy",
            "Balanced mix",
            "Spontaneous & Adventurous"
          ],
          points: 2
        }
      ]
    },
    {
      title: "Physical Preferences",
      fields: [
        {
          name: "heightPreference",
          label: "Height preference range (cm)",
          type: "height-range",
          points: 0
        }
      ]
    }
  ];

  const currentStepData = steps[currentStep];
  const totalSteps = steps.length;
  const progress = ((currentStep + 1) / totalSteps) * 100;

  const handleFieldChange = (fieldName: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [fieldName]: value
    }));
  };

  const handleMultiSelectToggle = (fieldName: keyof CompatibilityQuestionnaire, option: string, maxSelections: number) => {
    const current = (formData[fieldName] as string[]) || [];
    
    if (current.includes(option)) {
      handleFieldChange(fieldName, current.filter(item => item !== option));
    } else if (current.length < maxSelections) {
      handleFieldChange(fieldName, [...current, option]);
    }
  };

  const isStepComplete = () => {
    return currentStepData.fields.every(field => {
      const value = formData[field.name];
      if (field.type === "multiselect") {
        return Array.isArray(value) && value.length > 0;
      }
      if (field.type === "height-range") {
        return formData.heightPreference?.min && formData.heightPreference?.max;
      }
      return value !== undefined && value !== "";
    });
  };

  const handleNext = () => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onComplete(formData as CompatibilityQuestionnaire);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {showEditWarning?.show && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <Alert className="bg-amber-50 border-amber-200">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-800">
                {showEditWarning.message}
              </AlertDescription>
            </Alert>
          </motion.div>
        )}

        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-600">
              Step {currentStep + 1} of {totalSteps}
            </span>
            <span className="text-sm text-purple-600 font-medium">
              {Math.round(progress)}% Complete
            </span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-pink-500 to-purple-500"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="bg-white/80 backdrop-blur-sm border-pink-200">
              <CardHeader>
                <CardTitle className="text-2xl text-center text-gray-800 flex items-center justify-center gap-2">
                  <Heart className="w-6 h-6 text-pink-500" />
                  {currentStepData.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {currentStepData.fields.map((field) => (
                  <div key={field.name} className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">
                      {field.label}
                      {field.points > 0 && (
                        <Badge variant="secondary" className="ml-2 bg-purple-100 text-purple-700 text-xs">
                          {field.points} pts
                        </Badge>
                      )}
                    </Label>

                    {field.type === "select" && (
                      <Select
                        value={formData[field.name] as string}
                        onValueChange={(value) => handleFieldChange(field.name, value)}
                      >
                        <SelectTrigger className="border-pink-200 focus:ring-pink-500">
                          <SelectValue placeholder="Select an option" />
                        </SelectTrigger>
                        <SelectContent>
                          {field.options.map((option: string) => (
                            <SelectItem key={option} value={option}>
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {field.type === "input" && (
                      <Input
                        type="text"
                        value={formData[field.name] as string || ""}
                        onChange={(e) => handleFieldChange(field.name, e.target.value)}
                        placeholder={field.placeholder}
                        className="border-pink-200 focus:ring-pink-500"
                      />
                    )}

                    {field.type === "multiselect" && (
                      <div className="flex flex-wrap gap-2">
                        {field.options.map((option: string) => {
                          const isSelected = (formData[field.name] as string[] || []).includes(option);
                          return (
                            <Badge
                              key={option}
                              variant={isSelected ? "default" : "outline"}
                              className={`cursor-pointer transition-colors ${
                                isSelected
                                  ? "bg-gradient-to-r from-pink-500 to-purple-500 text-white"
                                  : "border-pink-300 text-gray-700 hover:border-pink-500"
                              }`}
                              onClick={() => handleMultiSelectToggle(field.name, option, field.maxSelections)}
                            >
                              {option}
                            </Badge>
                          );
                        })}
                      </div>
                    )}

                    {field.type === "height-range" && (
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label className="text-xs text-gray-600">Min Height (cm)</Label>
                          <Input
                            type="number"
                            value={formData.heightPreference?.min || ""}
                            onChange={(e) => handleFieldChange("heightPreference", {
                              ...formData.heightPreference,
                              min: parseInt(e.target.value)
                            })}
                            placeholder="150"
                            min="140"
                            max="220"
                            className="border-pink-200 focus:ring-pink-500"
                          />
                        </div>
                        <div>
                          <Label className="text-xs text-gray-600">Max Height (cm)</Label>
                          <Input
                            type="number"
                            value={formData.heightPreference?.max || ""}
                            onChange={(e) => handleFieldChange("heightPreference", {
                              ...formData.heightPreference,
                              max: parseInt(e.target.value)
                            })}
                            placeholder="200"
                            min="140"
                            max="220"
                            className="border-pink-200 focus:ring-pink-500"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        <div className="flex justify-between items-center mt-6">
          <Button
            variant="ghost"
            onClick={handleBack}
            disabled={currentStep === 0}
            className="text-gray-600"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <div className="flex gap-2">
            {onSkip && currentStep === 0 && (
              <Button
                variant="ghost"
                onClick={onSkip}
                className="text-gray-600"
              >
                Skip for now
              </Button>
            )}
            
            <Button
              onClick={handleNext}
              disabled={!isStepComplete()}
              className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
            >
              {currentStep === totalSteps - 1 ? "Complete" : "Next"}
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
