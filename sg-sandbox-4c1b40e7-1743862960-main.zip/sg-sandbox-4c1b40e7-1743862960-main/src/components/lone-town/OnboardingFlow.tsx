
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, Sparkles, Clock, Lock, MessageCircle, Camera, ChevronRight } from "lucide-react";

interface OnboardingFlowProps {
  onComplete: () => void;
  onSkip: () => void;
}

export default function OnboardingFlow({ onComplete, onSkip }: OnboardingFlowProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      icon: Heart,
      title: "Welcome to Lone Town",
      description: "A space where meaningful connections bloom through emotional intelligence and compatibility.",
      highlight: "Quality over quantity, depth over surface."
    },
    {
      icon: Sparkles,
      title: "How It Works",
      description: "Every day, receive one carefully matched connection based on your values, personality, and life goals.",
      highlight: "One thoughtful match > Endless swiping"
    },
    {
      icon: Clock,
      title: "The 24-Hour Journey",
      description: "You have 24 hours to connect with your daily match. If both feel the spark, pin the conversation to continue beyond time limits.",
      highlight: "Real connections need real time"
    },
    {
      icon: Lock,
      title: "Privacy & Unlocks",
      description: "Photos stay private initially. After 3 days of continuous conversation, profiles unlock naturally—building trust first.",
      highlight: "Trust before visuals, depth before faces"
    },
    {
      icon: MessageCircle,
      title: "Meaningful Conversations",
      description: "Voice calls unlock after 24 hours of pinned conversation. We encourage emotional connection over instant gratification.",
      highlight: "Hear their voice when trust is built"
    }
  ];

  const currentSlideData = slides[currentSlide];
  const IconComponent = currentSlideData.icon;
  const isLastSlide = currentSlide === slides.length - 1;

  const handleNext = () => {
    if (isLastSlide) {
      onComplete();
    } else {
      setCurrentSlide(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentSlide > 0) {
      setCurrentSlide(prev => prev - 1);
    }
  };

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50 z-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.4 }}
          >
            <Card className="bg-white/90 backdrop-blur-sm border-pink-200 shadow-2xl">
              <CardHeader className="text-center space-y-4 pb-2">
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                  className="mx-auto w-20 h-20 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full flex items-center justify-center"
                >
                  <IconComponent className="w-10 h-10 text-white" />
                </motion.div>
                <CardTitle className="text-2xl text-gray-800">
                  {currentSlideData.title}
                </CardTitle>
              </CardHeader>

              <CardContent className="space-y-6 pt-4">
                <p className="text-gray-700 text-center leading-relaxed">
                  {currentSlideData.description}
                </p>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg p-4 border border-pink-200"
                >
                  <p className="text-sm text-purple-700 font-medium text-center italic">
                    "{currentSlideData.highlight}"
                  </p>
                </motion.div>

                {/* Progress Dots */}
                <div className="flex justify-center space-x-2">
                  {slides.map((_, index) => (
                    <div
                      key={index}
                      className={`h-2 rounded-full transition-all duration-300 ${
                        index === currentSlide
                          ? "w-8 bg-gradient-to-r from-pink-500 to-purple-500"
                          : "w-2 bg-gray-300"
                      }`}
                    />
                  ))}
                </div>

                {/* Navigation Buttons */}
                <div className="flex justify-between items-center pt-4">
                  <Button
                    variant="ghost"
                    onClick={handleBack}
                    disabled={currentSlide === 0}
                    className="text-gray-600"
                  >
                    Back
                  </Button>

                  <div className="flex gap-2">
                    {!isLastSlide && (
                      <Button
                        variant="ghost"
                        onClick={onSkip}
                        className="text-gray-600"
                      >
                        Skip
                      </Button>
                    )}
                    <Button
                      onClick={handleNext}
                      className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
                    >
                      {isLastSlide ? "Get Started" : "Next"}
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
