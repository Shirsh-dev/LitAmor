
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { X, Heart, MessageCircle, Sparkles, Lock, Phone, PhoneOff, AlertCircle } from "lucide-react";
import { useState } from "react";
import { MatchCardDisplay } from "@/types/loneTown";

interface MatchProfileModalProps {
  match: MatchCardDisplay;
  onClose: () => void;
  onStartChat: () => void;
  onVoiceCall?: () => void;
  onUnmatch?: () => void;
}

export default function MatchProfileModal({ 
  match, 
  onClose, 
  onStartChat,
  onVoiceCall,
  onUnmatch 
}: MatchProfileModalProps) {
  const [showUnmatchConfirm, setShowUnmatchConfirm] = useState(false);

  const handleUnmatch = () => {
    if (onUnmatch) {
      onUnmatch();
      onClose();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="w-full max-w-md max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="bg-white/95 backdrop-blur-md border-pink-200">
          <CardHeader className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="absolute top-2 right-2 w-8 h-8 p-0 hover:bg-pink-100"
            >
              <X className="w-4 h-4" />
            </Button>
            
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-gradient-to-br from-pink-400 to-purple-400 rounded-full flex items-center justify-center mx-auto relative">
                {match.profileUnlocked ? (
                  <Heart className="w-8 h-8 text-white" />
                ) : (
                  <Lock className="w-8 h-8 text-white" />
                )}
              </div>
              <CardTitle className="text-xl text-gray-800">
                {match.firstName}, {match.age}
              </CardTitle>
              <p className="text-sm text-gray-600">{match.profession}</p>
              
              {/* Match Status Badge */}
              {match.matchStatus === "pinned" && (
                <Badge className="bg-purple-100 text-purple-700">
                  Pinned Conversation
                </Badge>
              )}
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Profile Locked State */}
            {!match.profileUnlocked && (
              <Alert className="bg-amber-50 border-amber-200">
                <Lock className="h-4 w-4 text-amber-600" />
                <AlertDescription className="text-amber-800">
                  Keep chatting for {3 - match.conversationDays} more day(s) to unlock full profile and photos
                </AlertDescription>
              </Alert>
            )}

            {/* Personality Questions */}
            <div>
              <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-500" />
                Get to Know Me
              </h4>
              <div className="space-y-3">
                {match.personalityQuestions.slice(0, 3).map((qa, index) => (
                  <div key={index} className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg p-3 border border-purple-100">
                    <p className="text-xs font-medium text-purple-700 mb-1">
                      {qa.question}
                    </p>
                    <p className="text-sm text-gray-700">
                      {qa.answer}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Interests */}
            <div>
              <h4 className="font-semibold text-gray-800 mb-2">Interests & Hobbies</h4>
              <div className="flex flex-wrap gap-2">
                {match.interests.map((interest, index) => (
                  <Badge 
                    key={index}
                    variant="secondary"
                    className="bg-purple-100 text-purple-700 text-xs"
                  >
                    {interest}
                  </Badge>
                ))}
                {match.hobbies.map((hobby, index) => (
                  <Badge 
                    key={index}
                    variant="secondary"
                    className="bg-pink-100 text-pink-700 text-xs"
                  >
                    {hobby}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Future Goal */}
            {match.futureGoal && (
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">Future Goal</h4>
                <p className="text-sm text-gray-700 italic">
                  "{match.futureGoal}"
                </p>
              </div>
            )}

            {/* Voice Call Status */}
            {match.voiceCallUnlocked && (
              <Alert className="bg-green-50 border-green-200">
                <Phone className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  Voice calls are now unlocked! Connect deeper through conversation.
                </AlertDescription>
              </Alert>
            )}

            {match.isPinned && !match.voiceCallUnlocked && (
              <Alert className="bg-blue-50 border-blue-200">
                <AlertCircle className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-800 text-xs">
                  Voice calls will unlock 24 hours after pinning
                </AlertDescription>
              </Alert>
            )}

            {/* Action Buttons */}
            <div className="space-y-3 pt-4">
              <div className="flex space-x-3">
                <Button
                  onClick={onStartChat}
                  className="flex-1 bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  {match.matchStatus === "active" ? "Start Chat" : "Continue Chat"}
                </Button>
                
                {match.voiceCallUnlocked && onVoiceCall && (
                  <Button
                    onClick={onVoiceCall}
                    variant="outline"
                    className="border-purple-200 text-purple-600 hover:bg-purple-50"
                  >
                    <Phone className="w-4 h-4" />
                  </Button>
                )}
              </div>

              {/* Unmatch Option */}
              {onUnmatch && !showUnmatchConfirm && (
                <Button
                  variant="ghost"
                  onClick={() => setShowUnmatchConfirm(true)}
                  className="w-full text-gray-500 hover:text-red-500 hover:bg-red-50 text-sm"
                >
                  Unmatch
                </Button>
              )}

              {showUnmatchConfirm && (
                <Alert className="bg-red-50 border-red-200">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800 text-sm">
                    <p className="mb-2">Are you sure? This action cannot be undone.</p>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={handleUnmatch}
                        className="flex-1"
                      >
                        Yes, Unmatch
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setShowUnmatchConfirm(false)}
                        className="flex-1"
                      >
                        Cancel
                      </Button>
                    </div>
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
