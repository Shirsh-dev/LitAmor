
import { motion } from "framer-motion";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { User } from "lucide-react";

interface UserIdentityBarProps {
  firstName: string;
  matchType: "similar" | "opposite";
  onMatchTypeToggle: (checked: boolean) => void;
  onProfileClick: () => void;
}

export default function UserIdentityBar({
  firstName,
  matchType,
  onMatchTypeToggle,
  onProfileClick
}: UserIdentityBarProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-pink-100"
    >
      <div className="px-4 py-3 max-w-md mx-auto flex items-center justify-between">
        {/* User Name - Clickable */}
        <Button
          variant="ghost"
          onClick={onProfileClick}
          className="p-2 hover:bg-pink-50 rounded-full transition-colors"
        >
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-pink-400 to-purple-400 rounded-full flex items-center justify-center">
              <User className="w-4 h-4 text-white" />
            </div>
            <span className="font-medium text-gray-800">{firstName}</span>
          </div>
        </Button>

        {/* Match Type Toggle */}
        <div className="flex items-center space-x-3">
          <div className="text-right">
            <div className="text-xs text-gray-500 mb-1">Match Type</div>
            <div className="flex items-center space-x-2">
              <span className={`text-xs font-medium transition-colors ${
                matchType === "similar" ? "text-pink-600" : "text-gray-400"
              }`}>
                Similar
              </span>
              <Switch
                checked={matchType === "opposite"}
                onCheckedChange={onMatchTypeToggle}
                className="data-[state=checked]:bg-purple-500 data-[state=unchecked]:bg-pink-400"
              />
              <span className={`text-xs font-medium transition-colors ${
                matchType === "opposite" ? "text-purple-600" : "text-gray-400"
              }`}>
                Opposite
              </span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
