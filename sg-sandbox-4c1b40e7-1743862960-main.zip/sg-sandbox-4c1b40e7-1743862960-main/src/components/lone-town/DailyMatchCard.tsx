
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Heart, Briefcase, Target, Lock, Clock, Pin } from "lucide-react";
import { MatchCardDisplay } from "@/types/loneTown";
import { formatTimeRemaining } from "@/lib/matchLifecycle";

interface DailyMatchCardProps {
  match: MatchCardDisplay;
  onClick: () => void;
  onPin?: () => void;
  onUnpin?: () => void;
  canPin?: boolean;
  canUnpin?: boolean;
}

export default function DailyMatchCard({ 
  match, 
  onClick, 
  onPin, 
  onUnpin,
  canPin = false,
  canUnpin = false 
}: DailyMatchCardProps) {
  const handlePinClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (canPin && onPin) onPin();
    if (canUnpin && onUnpin) onUnpin();
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      <Card 
        className="cursor-pointer bg-white/70 backdrop-blur-sm border-pink-200 hover:border-pink-300 transition-all duration-300 shadow-lg hover:shadow-xl relative"
        onClick={onClick}
      >
        {/* Pin Button */}
        {(canPin || canUnpin) && (
          <Button
            size="sm"
            variant={match.isPinned ? "default" : "ghost"}
            className={`absolute top-3 right-3 z-10 ${
              match.isPinned 
                ? "bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600" 
                : "hover:bg-pink-50"
            }`}
            onClick={handlePinClick}
          >
            <Pin className={`w-4 h-4 ${match.isPinned ? "fill-white" : ""}`} />
          </Button>
        )}

        <CardContent className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-pink-400 to-purple-400 rounded-full flex items-center justify-center relative">
                {match.profileUnlocked ? (
                  <Heart className="w-6 h-6 text-white" />
                ) : (
                  <Lock className="w-6 h-6 text-white" />
                )}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800">
                  {match.firstName}
                </h3>
                <p className="text-sm text-gray-600">{match.age} years old</p>
              </div>
            </div>
            
            {/* Match Status Indicator */}
            <div className="flex flex-col items-end">
              {match.matchStatus === "active" && match.expiresAt && (
                <Badge variant="outline" className="border-amber-300 text-amber-700 text-xs">
                  <Clock className="w-3 h-3 mr-1" />
                  {formatTimeRemaining(match.expiresAt)}
                </Badge>
              )}
              {match.matchStatus === "pinned" && (
                <Badge className="bg-purple-100 text-purple-700 text-xs">
                  <Pin className="w-3 h-3 mr-1 fill-current" />
                  Pinned
                </Badge>
              )}
            </div>
          </div>

          {/* Profession */}
          <div className="flex items-center space-x-2 mb-3">
            <Briefcase className="w-4 h-4 text-purple-500" />
            <span className="text-sm text-gray-700">{match.profession}</span>
          </div>

          {/* Interests/Hobbies */}
          <div className="mb-3">
            <div className="flex flex-wrap gap-2">
              {match.interests.slice(0, 2).map((interest, index) => (
                <Badge 
                  key={index}
                  variant="secondary"
                  className="bg-pink-100 text-pink-700 hover:bg-pink-200 text-xs"
                >
                  {interest}
                </Badge>
              ))}
              {match.hobbies.slice(0, 1).map((hobby, index) => (
                <Badge 
                  key={index}
                  variant="secondary"
                  className="bg-purple-100 text-purple-700 hover:bg-purple-200 text-xs"
                >
                  {hobby}
                </Badge>
              ))}
            </div>
          </div>

          {/* Future Goal */}
          {match.futureGoal && (
            <div className="flex items-center space-x-2 mb-3">
              <Target className="w-4 h-4 text-purple-500" />
              <span className="text-sm text-gray-700">
                Becoming: <span className="font-medium">{match.futureGoal}</span>
              </span>
            </div>
          )}

          {/* Unlock Status */}
          {!match.profileUnlocked && match.conversationDays > 0 && (
            <div className="mt-4 pt-3 border-t border-pink-100">
              <p className="text-xs text-gray-600 text-center">
                🔓 Profile unlocks in {3 - match.conversationDays} day(s) of continuous chat
              </p>
            </div>
          )}

          {match.profileUnlocked && (
            <div className="mt-4 pt-3 border-t border-pink-100">
              <p className="text-xs text-purple-600 text-center font-medium">
                ✨ Full profile unlocked
              </p>
            </div>
          )}

          {/* CTA */}
          <div className="mt-4 pt-4 border-t border-pink-100">
            <p className="text-center text-sm text-purple-600 font-medium">
              Tap to explore their world ✨
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
