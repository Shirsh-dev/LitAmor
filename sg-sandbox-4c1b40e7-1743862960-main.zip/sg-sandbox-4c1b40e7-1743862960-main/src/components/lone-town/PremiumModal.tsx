
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Crown, Heart, Zap, Star } from "lucide-react";

interface PremiumModalProps {
  onClose: () => void;
}

export default function PremiumModal({ onClose }: PremiumModalProps) {
  const features = [
    {
      icon: Heart,
      title: "3 Daily Matches",
      description: "Get up to 3 carefully curated matches every day"
    },
    {
      icon: Zap,
      title: "Priority Matching",
      description: "Your profile gets shown to compatible matches first"
    },
    {
      icon: Star,
      title: "Advanced Compatibility",
      description: "Access to deeper personality matching algorithms"
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="w-full max-w-md"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="bg-white/95 backdrop-blur-md border-purple-200">
          <CardHeader className="relative text-center">
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="absolute top-2 right-2 w-8 h-8 p-0 hover:bg-purple-100"
            >
              <X className="w-4 h-4" />
            </Button>
            
            <div className="space-y-2">
              <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-400 rounded-full flex items-center justify-center mx-auto">
                <Crown className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-xl text-gray-800">
                Unlock Premium
              </CardTitle>
              <p className="text-sm text-gray-600">
                Enhance your journey to meaningful connections
              </p>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Features */}
            <div className="space-y-4">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start space-x-3"
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center flex-shrink-0">
                    <feature.icon className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800">{feature.title}</h4>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Pricing */}
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-gray-800">$9.99</div>
              <div className="text-sm text-gray-600">per month</div>
              <div className="text-xs text-purple-600 mt-1">Cancel anytime</div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                <Crown className="w-4 h-4 mr-2" />
                Start Premium Journey
              </Button>
              <Button
                variant="ghost"
                onClick={onClose}
                className="w-full text-gray-600 hover:bg-gray-50"
              >
                Maybe later
              </Button>
            </div>

            <p className="text-xs text-gray-500 text-center">
              Premium features help us maintain quality connections and support our community
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
