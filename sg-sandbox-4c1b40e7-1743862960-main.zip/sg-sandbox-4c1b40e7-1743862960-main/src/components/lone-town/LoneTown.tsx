import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Settings, Heart, Sparkles, Lock, AlertCircle } from "lucide-react";
import OnboardingFlow from "./OnboardingFlow";
import CompatibilityQuestionnaire from "./CompatibilityQuestionnaire";
import DailyMatchCard from "./DailyMatchCard";
import MatchProfileModal from "./MatchProfileModal";
import PinnedConversations from "./PinnedConversations";
import UserIdentityBar from "./UserIdentityBar";
import { 
  UserProfile, 
  Match, 
  MatchCardDisplay,
  CompatibilityQuestionnaire as QuestionnaireData 
} from "@/types/loneTown";
import { 
  getMatchStatus, 
  pinMatch, 
  unpinMatch, 
  unmatchUsers,
  calculateContinuousDays 
} from "@/lib/matchLifecycle";
import { calculateCompatibilityScore } from "@/lib/compatibilityScoring";
import { checkEditWarning, recordEdit } from "@/lib/editWarnings";
import { useRouter } from "next/navigation";

export default function LoneTown() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showQuestionnaire, setShowQuestionnaire] = useState(false);
  const [selectedMatch, setSelectedMatch] = useState<MatchCardDisplay | null>(null);
  const [activeMatches, setActiveMatches] = useState<Match[]>([]);
  const [matchVisibility, setMatchVisibility] = useState(true);
  const [editWarning, setEditWarning] = useState<any>(null);
  const router = useRouter();

  useEffect(() => {
    initializeUser();
  }, []);

  const initializeUser = () => {
    const mockUser: UserProfile = {
      id: "user_123",
      firstName: "Shirsh",
      age: 26,
      gender: "male",
      location: {
        lat: 28.6139,
        lng: 77.2090,
        city: "Delhi"
      },
      height: 175,
      questionnaire: {
        relationshipTypeSeeking: "Long-term committed",
        smoking: "Never",
        drinking: "Socially",
        religion: "Hindu",
        ethnicity: "North Indian",
        firstLanguage: "Hindi",
        diet: "Vegetarian",
        profession: "Software Engineer",
        politicalViews: "Moderate",
        priorities: ["Career Growth", "Love & Relationships", "Personal Growth"],
        sexualAttraction: "Heterosexual",
        pastRelationships: "Few short-term relationships",
        personalityType: "Ambivert",
        loveLanguage: "Quality Time",
        lifestyle: "Balanced mix",
        heightPreference: {
          min: 155,
          max: 175
        }
      },
      basicCompatibilityScore: 0,
      bio: "Looking for genuine connections",
      interests: ["Technology", "Travel", "Music"],
      hobbies: ["Coding", "Reading", "Hiking"],
      futureGoal: "Building meaningful relationships",
      personalityAnswers: [
        {
          question: "What keeps you going on tough days?",
          answer: "The belief that tomorrow can be better and the people who support me"
        }
      ],
      photos: [],
      matchVisibility: true,
      isNew: true,
      firstLoneTownOnboardShown: false,
      questionnaireLastEditedAt: "",
      questionnaireEditCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setCurrentUser(mockUser);
    setMatchVisibility(mockUser.matchVisibility);

    if (mockUser.isNew && !mockUser.firstLoneTownOnboardShown) {
      setShowOnboarding(true);
    } else if (!mockUser.questionnaire.relationshipTypeSeeking) {
      setShowQuestionnaire(true);
    }

    loadMockMatches(mockUser);
  };

  const loadMockMatches = (user: UserProfile) => {
    const mockMatch: Match = {
      id: "match_001",
      users: [user.id, "user_456"],
      compatibilityScore: 42,
      matchCreatedAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
      matchExpiresAt: new Date(Date.now() + 21 * 60 * 60 * 1000).toISOString(),
      status: "active",
      messageCount: 0,
      conversationDays: 0,
      maxGapHours: 2,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setActiveMatches([mockMatch]);
  };

  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
    if (currentUser) {
      const updatedUser = {
        ...currentUser,
        firstLoneTownOnboardShown: true,
        isNew: false
      };
      setCurrentUser(updatedUser);
      
      if (!currentUser.questionnaire.relationshipTypeSeeking) {
        setShowQuestionnaire(true);
      }
    }
  };

  const handleOnboardingSkip = () => {
    setShowOnboarding(false);
    if (currentUser) {
      const updatedUser = {
        ...currentUser,
        firstLoneTownOnboardShown: true
      };
      setCurrentUser(updatedUser);
    }
  };

  const handleQuestionnaireComplete = (data: QuestionnaireData) => {
    if (!currentUser) return;

    const warning = checkEditWarning(
      currentUser.questionnaireLastEditedAt,
      currentUser.questionnaireEditCount,
      currentUser.lastEditWarningShownAt
    );

    if (warning.show) {
      setEditWarning(warning);
      return;
    }

    const editRecord = recordEdit(currentUser.questionnaireEditCount);
    
    const updatedUser: UserProfile = {
      ...currentUser,
      questionnaire: data,
      basicCompatibilityScore: 0,
      questionnaireLastEditedAt: editRecord.lastEditedAt,
      questionnaireEditCount: editRecord.newEditCount,
      updatedAt: new Date().toISOString()
    };

    setCurrentUser(updatedUser);
    setShowQuestionnaire(false);
  };

  const handleMatchClick = (match: Match) => {
    const mockMatchProfile: MatchCardDisplay = {
      id: match.id,
      firstName: "Khushi",
      age: 24,
      profession: "Product Designer",
      interests: ["Art", "Psychology", "Sustainable Living"],
      hobbies: ["Painting", "Yoga", "Cooking"],
      futureGoal: "Creating meaningful impact through design",
      personalityQuestions: [
        {
          question: "What keeps you going on tough days?",
          answer: "The belief that creativity can change the world and the support of loved ones"
        },
        {
          question: "Describe your ideal Sunday",
          answer: "Morning yoga, afternoon at an art gallery, evening cooking with friends"
        },
        {
          question: "What's your philosophy on relationships?",
          answer: "Deep connection built on trust, vulnerability, and shared growth"
        }
      ],
      photosUnlocked: false,
      profileUnlocked: !!match.profileUnlockedAt,
      voiceCallUnlocked: !!match.voiceCallUnlockedAt,
      matchStatus: match.status,
      expiresAt: match.matchExpiresAt,
      isPinned: match.status === "pinned",
      conversationDays: calculateContinuousDays(match)
    };

    setSelectedMatch(mockMatchProfile);
  };

  const handlePinMatch = (matchId: string) => {
    if (!currentUser) return;

    setActiveMatches(prev =>
      prev.map(match =>
        match.id === matchId ? pinMatch(match, currentUser.id) : match
      )
    );
  };

  const handleUnpinMatch = (matchId: string) => {
    if (!currentUser) return;

    setActiveMatches(prev =>
      prev.map(match =>
        match.id === matchId ? unpinMatch(match, currentUser.id) : match
      )
    );
  };

  const handleUnmatch = (matchId: string) => {
    if (!currentUser) return;

    setActiveMatches(prev =>
      prev.map(match =>
        match.id === matchId ? unmatchUsers(match, currentUser.id) : match
      )
    );
  };

  const handleStartChat = () => {
    if (selectedMatch) {
      router.push(`/messages/${selectedMatch.id}`);
    }
  };

  const handleVoiceCall = () => {
    console.log("Starting voice call...");
  };

  const toggleMatchVisibility = () => {
    const newVisibility = !matchVisibility;
    setMatchVisibility(newVisibility);
    
    if (currentUser) {
      setCurrentUser({
        ...currentUser,
        matchVisibility: newVisibility,
        updatedAt: new Date().toISOString()
      });
    }
  };

  if (showOnboarding) {
    return (
      <OnboardingFlow
        onComplete={handleOnboardingComplete}
        onSkip={handleOnboardingSkip}
      />
    );
  }

  if (showQuestionnaire) {
    return (
      <CompatibilityQuestionnaire
        initialData={currentUser?.questionnaire}
        onComplete={handleQuestionnaireComplete}
        onSkip={() => setShowQuestionnaire(false)}
        showEditWarning={editWarning}
      />
    );
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <Heart className="w-12 h-12 text-pink-500 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Loading your journey...</p>
        </div>
      </div>
    );
  }

  const dailyMatch = activeMatches.find(m => m.status === "active" || m.status === "pinned");
  const matchStatus = dailyMatch ? getMatchStatus(dailyMatch) : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50">
      <UserIdentityBar
        firstName={currentUser.firstName}
        matchType="similar"
        onMatchTypeToggle={() => {}}
        onProfileClick={() => setShowQuestionnaire(true)}
      />

      <div className="px-4 pt-20 pb-24 max-w-md mx-auto space-y-6">
        {!matchVisibility && (
          <Alert className="bg-amber-50 border-amber-200">
            <Lock className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-800">
              Match visibility is OFF. Turn it on in settings to receive daily matches.
            </AlertDescription>
          </Alert>
        )}

        {!currentUser.questionnaire.relationshipTypeSeeking && (
          <Alert className="bg-blue-50 border-blue-200">
            <AlertCircle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              Complete your compatibility questionnaire to start receiving matches.
              <Button
                variant="link"
                onClick={() => setShowQuestionnaire(true)}
                className="text-blue-600 underline p-0 h-auto ml-1"
              >
                Complete now
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {dailyMatch && matchVisibility && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-4"
          >
            <div className="text-center space-y-2">
              <h2 className="text-xl font-semibold text-gray-800">
                Today's Connection
              </h2>
              <p className="text-sm text-gray-600">
                Someone who resonates with your values and journey
              </p>
            </div>

            <DailyMatchCard
              match={{
                id: dailyMatch.id,
                firstName: "Khushi",
                age: 24,
                profession: "Product Designer",
                interests: ["Art", "Psychology"],
                hobbies: ["Painting", "Yoga"],
                futureGoal: "Creating meaningful impact",
                personalityQuestions: [],
                photosUnlocked: false,
                profileUnlocked: matchStatus?.profileUnlocked || false,
                voiceCallUnlocked: matchStatus?.voiceCallEnabled || false,
                matchStatus: dailyMatch.status,
                expiresAt: dailyMatch.matchExpiresAt,
                isPinned: dailyMatch.status === "pinned",
                conversationDays: calculateContinuousDays(dailyMatch)
              }}
              onClick={() => handleMatchClick(dailyMatch)}
              onPin={() => handlePinMatch(dailyMatch.id)}
              onUnpin={() => handleUnpinMatch(dailyMatch.id)}
              canPin={matchStatus?.canPin}
              canUnpin={matchStatus?.canUnpin}
            />
          </motion.div>
        )}

        {activeMatches.filter(m => m.status === "pinned").length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <PinnedConversations
              conversations={activeMatches
                .filter(m => m.status === "pinned")
                .map(m => ({
                  id: m.id,
                  matchName: "Khushi",
                  lastMessage: "Looking forward to connecting more!",
                  timestamp: "2 hours ago",
                  isPinned: true,
                  unreadCount: 0
                }))}
            />
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center py-8"
        >
          <div className="inline-flex items-center space-x-2 text-gray-500 text-sm">
            <Sparkles className="w-4 h-4" />
            <span>Meaningful connections are worth the wait</span>
            <Sparkles className="w-4 h-4" />
          </div>
        </motion.div>

        <div className="fixed bottom-20 right-4">
          <Button
            size="sm"
            variant="outline"
            onClick={toggleMatchVisibility}
            className={`border-2 ${
              matchVisibility
                ? "border-green-300 bg-green-50 text-green-700"
                : "border-gray-300 bg-gray-50 text-gray-600"
            }`}
          >
            <Settings className="w-4 h-4 mr-2" />
            {matchVisibility ? "Visible" : "Hidden"}
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {selectedMatch && (
          <MatchProfileModal
            match={selectedMatch}
            onClose={() => setSelectedMatch(null)}
            onStartChat={handleStartChat}
            onVoiceCall={matchStatus?.voiceCallEnabled ? handleVoiceCall : undefined}
            onUnmatch={() => handleUnmatch(selectedMatch.id)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
