
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Flower, Globe, Palmtree, Building, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FlowerMenuProps {
  onSelect: (option: string) => void;
}

export function FlowerMenu({ onSelect }: FlowerMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  
  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };
  
  const handleSelect = (option: string) => {
    onSelect(option);
    setIsOpen(false);
  };
  
  const menuItems = [
    { id: "planet", icon: <Globe className="h-6 w-6" />, label: "Planet" },
    { id: "love-tree", icon: <Palmtree className="h-6 w-6" />, label: "Love Tree" },
    { id: "town-of-love", icon: <Building className="h-6 w-6" />, label: "Town of Love" },
    { id: "amore-streak", icon: <Flame className="h-6 w-6" />, label: "Amore Streak" }
  ];

  return (
    <div className="relative z-50">
      <Button
        onClick={toggleMenu}
        variant="default"
        size="icon"
        className="h-14 w-14 rounded-full bg-primary hover:bg-primary/90 shadow-lg"
      >
        <Flower className="h-6 w-6 text-primary-foreground" />
      </Button>
      
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40" onClick={toggleMenu} />
        )}
      </AnimatePresence>
      
      <AnimatePresence>
        {isOpen && (
          <div className="absolute left-0 z-50">
            {menuItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ 
                  scale: 1, 
                  opacity: 1
                }}
                exit={{ scale: 0, opacity: 0 }}
                transition={{ 
                  type: "spring", 
                  stiffness: 300, 
                  damping: 20,
                  delay: index * 0.05 
                }}
                className="absolute flex items-center"
                style={{ bottom: `${(index + 1) * 70}px` }}
              >
                <Button
                  onClick={() => handleSelect(item.id)}
                  variant="secondary"
                  size="icon"
                  className="h-12 w-12 rounded-full shadow-lg flex items-center justify-center bg-card border border-primary/20"
                >
                  {item.icon}
                </Button>
                <span className="ml-2 text-xs font-medium bg-background/80 backdrop-blur-sm px-2 py-1 rounded-full shadow-sm whitespace-nowrap">
                  {item.label}
                </span>
              </motion.div>
            ))}
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
