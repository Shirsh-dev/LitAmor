
import Link from "next/link";
import { useRouter } from "next/router";
import { Home, Globe, Zap, Heart, User } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function SinglesBottomNav() {
  const router = useRouter();
  const currentPath = router.pathname;

  const navItems = [
    {
      icon: Home,
      label: "Home",
      href: "/singles/home",
      active: currentPath === "/singles/home"
    },
    {
      icon: Globe,
      label: "Planet",
      href: "/singles/planet",
      active: currentPath === "/singles/planet"
    },
    {
      icon: Zap,
      label: "Amor-Fly",
      href: "/singles/amor-fly",
      active: currentPath === "/singles/amor-fly"
    },
    {
      icon: Heart,
      label: "Lone Town",
      href: "/singles/lone-town",
      active: currentPath === "/singles/lone-town"
    },
    {
      icon: User,
      label: "Profile",
      href: "/singles/profile",
      active: currentPath === "/singles/profile"
    }
  ];

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-pink-100 z-50 safe-area-bottom"
      role="navigation"
      aria-label="Main navigation"
    >
      <div className="flex items-center justify-around py-2 px-4 max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Button
                variant="ghost"
                size="sm"
                className={`nav-item flex flex-col items-center gap-1 h-auto py-3 px-3 touch-friendly accessibility-focus ${
                  item.active 
                    ? "text-pink-600 bg-pink-50 shadow-sm" 
                    : "text-gray-500 hover:text-pink-600 hover:bg-pink-25"
                }`}
                aria-label={`Navigate to ${item.label}`}
                aria-current={item.active ? "page" : undefined}
              >
                <Icon className={`h-5 w-5 transition-all duration-200 ${item.active ? 'scale-110' : ''}`} />
                <span className="text-xs font-medium">{item.label}</span>
              </Button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
