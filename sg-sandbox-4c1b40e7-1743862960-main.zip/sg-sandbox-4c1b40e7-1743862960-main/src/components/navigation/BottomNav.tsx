
import Link from "next/link";
import { useRouter } from "next/router";
import { Home, Heart, BookOpen, User, Star, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function BottomNav() {
  const router = useRouter();
  const currentPath = router.pathname;

  const navItems = [
    {
      icon: Home,
      label: "Home",
      href: "/couple/home",
      active: currentPath === "/couple/home"
    },
    {
      icon: Heart,
      label: "Planet",
      href: "/couple/planet",
      active: currentPath === "/couple/planet"
    },
    {
      icon: Flame,
      label: "Amore Streak",
      href: "/couple/amore-streak",
      active: currentPath === "/couple/amore-streak"
    },
    {
      icon: BookOpen,
      label: "Love Diary",
      href: "/couple/love-diary",
      active: currentPath === "/couple/love-diary"
    },
    {
      icon: Star,
      label: "Lit Score",
      href: "/couple/lit-score",
      active: currentPath === "/couple/lit-score"
    },
    {
      icon: User,
      label: "Profile",
      href: "/couple/profile",
      active: currentPath === "/couple/profile"
    }
  ];

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-pink-100 z-50 safe-area-bottom"
      role="navigation"
      aria-label="Main navigation"
    >
      <div className="flex items-center justify-around py-2 px-2 max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href} legacyBehavior>
              <a
                className={`flex flex-col items-center justify-center gap-1 h-auto py-2 px-2 rounded-lg transition-all duration-200 touch-friendly accessibility-focus ${
                  item.active 
                    ? "text-pink-600 bg-pink-50 shadow-inner" 
                    : "text-gray-500 hover:text-pink-600 hover:bg-pink-50/50"
                }`}
                aria-label={`Navigate to ${item.label}`}
                aria-current={item.active ? "page" : undefined}
              >
                <Icon className={`h-5 w-5 transition-all duration-200 ${item.active ? 'scale-110' : ''}`} />
                <span className="text-[10px] font-medium">{item.label}</span>
              </a>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
