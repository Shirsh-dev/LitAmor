import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  User, 
  Edit3, 
  Camera, 
  CheckCircle, 
  Heart, 
  Users, 
  MessageCircle, 
  Calendar,
  Crown,
  Shield,
  Settings,
  Bell,
  Lock,
  FileText,
  Info,
  LogOut,
  Trash2,
  QrCode,
  BookOpen,
  Upload,
  Copy,
  ExternalLink,
  Verified
} from "lucide-react";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import { useRouter } from "next/router";

interface UserProfile {
  id: string;
  name: string;
  age: number;
  gender: string;
  profession: string;
  hobbies: string[];
  lifeGoals: string;
  bio: string;
  profilePhoto: string | null;
  isVerified: boolean;
  compatibilityCompleted: boolean;
}

interface ActivityStats {
  connectionsCount: number;
  averageConnectionDuration: string;
  gratitudeEntries: number;
  memoriesSaved: number;
}

export function SinglesProfile() {
  const router = useRouter();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);
  const [isCoupleModalOpen, setIsCoupleModalOpen] = useState(false);
  const [partnerUsername, setPartnerUsername] = useState("");
  const [inviteLink, setInviteLink] = useState("");
  const [reflection, setReflection] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const [userProfile, setUserProfile] = useState<UserProfile>({
    id: "user123",
    name: "Shirsh",
    age: 23,
    gender: "Non-binary",
    profession: "UX Designer",
    hobbies: ["Photography", "Hiking", "Cooking", "Reading"],
    lifeGoals: "Travel the world, build meaningful relationships, and create beautiful digital experiences",
    bio: "Creative soul who loves capturing moments and exploring new places. Looking for someone to share adventures with.",
    profilePhoto: null,
    isVerified: false,
    compatibilityCompleted: true
  });

  const [activityStats] = useState<ActivityStats>({
    connectionsCount: 12,
    averageConnectionDuration: "3.2 months",
    gratitudeEntries: 45,
    memoriesSaved: 23
  });

  const generateInviteLink = () => {
    const link = `https://litamor.app/invite/${userProfile.id}`;
    setInviteLink(link);
  };

  const copyInviteLink = () => {
    navigator.clipboard.writeText(inviteLink);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleProfileUpdate = () => {
    setIsEditModalOpen(false);
  };

  const handleVerificationSubmit = () => {
    setUserProfile(prev => ({ ...prev, isVerified: true }));
    setIsVerificationModalOpen(false);
  };

  const handleLogout = () => {
    localStorage.clear();
    sessionStorage.clear();
    router.push("/auth/signin");
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-gradient-to-r from-pink-500 to-orange-400 text-white py-4 px-4 md:py-6 md:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 md:gap-3">
            <LitAmorLogo size="default" />
            <div>
              <h1 className="text-lg md:text-2xl font-bold">LIT AMOR</h1>
              <p className="text-xs md:text-sm opacity-90">Love but little more</p>
            </div>
          </div>
          <Button variant="outline" size="sm" className="bg-white/20 border-white/30 text-white hover:bg-white/30">
            <Settings size={14} className="mr-1 md:mr-2" />
            <span className="hidden sm:inline">Settings</span>
          </Button>
        </div>
      </header>

      <div className="max-w-4xl mx-auto py-4 md:py-8 px-4 md:px-6 lg:px-8 space-y-6 md:space-y-8">
        {/* User Info Card */}
        <Card className="overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-pink-50 to-orange-50 p-4 md:p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <CardTitle className="flex items-center gap-2">
                <User className="text-pink-600" size={20} />
                <span className="text-lg">Profile Information</span>
              </CardTitle>
              <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="w-full sm:w-auto">
                    <Edit3 size={14} className="mr-2" />
                    Edit Profile
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-sm mx-4 md:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Edit Profile</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Name</label>
                      <Input value={userProfile.name} onChange={(e) => setUserProfile(prev => ({ ...prev, name: e.target.value }))} />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Profession</label>
                      <Input value={userProfile.profession} onChange={(e) => setUserProfile(prev => ({ ...prev, profession: e.target.value }))} />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Hobbies (comma separated)</label>
                      <Input value={userProfile.hobbies.join(", ")} onChange={(e) => setUserProfile(prev => ({ ...prev, hobbies: e.target.value.split(", ") }))} />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Life Goals</label>
                      <Textarea value={userProfile.lifeGoals} onChange={(e) => setUserProfile(prev => ({ ...prev, lifeGoals: e.target.value }))} />
                    </div>
                    <Button onClick={handleProfileUpdate} className="w-full bg-gradient-to-r from-pink-500 to-orange-400">
                      Save Changes
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent className="p-4 md:p-6">
            <div className="flex flex-col sm:flex-row items-start gap-4 md:gap-6">
              <div className="relative mx-auto sm:mx-0">
                <div className="w-20 h-20 md:w-24 md:h-24 bg-gradient-to-br from-pink-100 to-orange-100 rounded-full flex items-center justify-center">
                  {userProfile.profilePhoto ? (
                    <img src={userProfile.profilePhoto} alt="Profile" className="w-full h-full rounded-full object-cover" />
                  ) : (
                    <Camera className="text-pink-600" size={28} />
                  )}
                </div>
                <button className="absolute -bottom-1 -right-1 w-7 h-7 md:w-8 md:h-8 bg-pink-500 text-white rounded-full flex items-center justify-center hover:bg-pink-600 transition-colors">
                  <Edit3 size={12} />
                </button>
              </div>
              <div className="flex-1 text-center sm:text-left">
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-2">
                  <h2 className="text-xl md:text-2xl font-bold text-gray-800">{userProfile.name}</h2>
                  {userProfile.isVerified && (
                    <Verified className="text-blue-500 mx-auto sm:mx-0" size={18} />
                  )}
                </div>
                <p className="text-gray-600 mb-1 text-sm md:text-base">{userProfile.age} years old • {userProfile.gender}</p>
                <p className="text-gray-600 mb-3 text-sm md:text-base">{userProfile.profession}</p>
                <div className="mb-3">
                  <p className="text-sm font-medium text-gray-700 mb-1">Hobbies:</p>
                  <div className="flex flex-wrap gap-1 justify-center sm:justify-start">
                    {userProfile.hobbies.map((hobby, index) => (
                      <Badge key={index} variant="secondary" className="bg-pink-100 text-pink-700 text-xs">
                        {hobby}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Life Goals:</p>
                  <p className="text-gray-600 text-sm">{userProfile.lifeGoals}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Compatibility Questionnaire */}
        <Card>
          <CardHeader className="p-4 md:p-6">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Heart className="text-pink-600" size={20} />
              Compatibility Assessment
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <p className="text-gray-600 mb-2 text-sm md:text-base">
                  Complete our compatibility questionnaire to find better matches
                </p>
                {userProfile.compatibilityCompleted && (
                  <Badge className="bg-green-100 text-green-700">
                    <CheckCircle size={14} className="mr-1" />
                    Compatibility Ready
                  </Badge>
                )}
              </div>
              <Button 
                variant={userProfile.compatibilityCompleted ? "outline" : "default"}
                className={`w-full sm:w-auto ${!userProfile.compatibilityCompleted ? "bg-gradient-to-r from-pink-500 to-orange-400" : ""}`}
                size="sm"
              >
                <ExternalLink size={14} className="mr-2" />
                <span className="text-sm">{userProfile.compatibilityCompleted ? "Retake Test" : "Take Test"}</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Activity Summary */}
        <Card>
          <CardHeader className="p-4 md:p-6">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Users className="text-pink-600" size={20} />
              Your Journey
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
              <motion.div 
                className="text-center p-3 md:p-4 bg-gradient-to-br from-pink-50 to-orange-50 rounded-lg cursor-pointer hover:shadow-md transition-shadow"
                whileHover={{ scale: 1.02 }}
              >
                <MessageCircle className="text-pink-600 mx-auto mb-2" size={20} />
                <p className="text-lg md:text-2xl font-bold text-gray-800">{activityStats.connectionsCount}</p>
                <p className="text-xs md:text-sm text-gray-600">Connections</p>
              </motion.div>
              <motion.div 
                className="text-center p-3 md:p-4 bg-gradient-to-br from-pink-50 to-orange-50 rounded-lg cursor-pointer hover:shadow-md transition-shadow"
                whileHover={{ scale: 1.02 }}
              >
                <Calendar className="text-pink-600 mx-auto mb-2" size={20} />
                <p className="text-lg md:text-2xl font-bold text-gray-800">{activityStats.averageConnectionDuration}</p>
                <p className="text-xs md:text-sm text-gray-600">Avg Duration</p>
              </motion.div>
              <motion.div 
                className="text-center p-3 md:p-4 bg-gradient-to-br from-pink-50 to-orange-50 rounded-lg cursor-pointer hover:shadow-md transition-shadow"
                whileHover={{ scale: 1.02 }}
              >
                <Heart className="text-pink-600 mx-auto mb-2" size={20} />
                <p className="text-lg md:text-2xl font-bold text-gray-800">{activityStats.gratitudeEntries}</p>
                <p className="text-xs md:text-sm text-gray-600">Gratitude Entries</p>
              </motion.div>
              <motion.div 
                className="text-center p-3 md:p-4 bg-gradient-to-br from-pink-50 to-orange-50 rounded-lg cursor-pointer hover:shadow-md transition-shadow"
                whileHover={{ scale: 1.02 }}
              >
                <Camera className="text-pink-600 mx-auto mb-2" size={20} />
                <p className="text-lg md:text-2xl font-bold text-gray-800">{activityStats.memoriesSaved}</p>
                <p className="text-xs md:text-sm text-gray-600">Memories Saved</p>
              </motion.div>
            </div>
          </CardContent>
        </Card>

        {/* Switch to Couple Profile */}
        <Card>
          <CardHeader className="p-4 md:p-6">
            <CardTitle className="text-lg">In a relationship?</CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            <div className="space-y-4">
              <p className="text-gray-600 text-sm md:text-base">
                Switch to couple profile to track your relationship journey together
              </p>
              <Dialog open={isCoupleModalOpen} onOpenChange={setIsCoupleModalOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full sm:w-auto bg-gradient-to-r from-pink-500 to-orange-400">
                    Switch to Couple Profile
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-sm mx-4 md:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Create Couple Profile</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Partner's Username</label>
                      <Input 
                        placeholder="Enter your partner's username"
                        value={partnerUsername}
                        onChange={(e) => setPartnerUsername(e.target.value)}
                      />
                    </div>
                    <Button 
                      onClick={generateInviteLink}
                      variant="outline"
                      className="w-full"
                    >
                      Generate Invite Link
                    </Button>
                    {inviteLink && (
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-600 mb-2">Share this link with your partner:</p>
                        <div className="flex gap-2">
                          <Input value={inviteLink} readOnly className="text-xs" />
                          <Button size="sm" onClick={copyInviteLink}>
                            <Copy size={14} />
                          </Button>
                        </div>
                      </div>
                    )}
                    <Button className="w-full bg-gradient-to-r from-pink-500 to-orange-400">
                      Send Invitation
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>

        {/* Verification */}
        <Card>
          <CardHeader className="p-4 md:p-6">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Shield className="text-blue-600" size={20} />
              Verified Badge
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <p className="text-gray-600 mb-2 text-sm md:text-base">
                  Upload a valid Government ID to verify your identity
                </p>
                <p className="text-xs md:text-sm text-gray-500">
                  Verified users are trusted on Lit Amor
                </p>
              </div>
              {!userProfile.isVerified ? (
                <Dialog open={isVerificationModalOpen} onOpenChange={setIsVerificationModalOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full sm:w-auto" size="sm">
                      <Upload size={14} className="mr-2" />
                      Verify Identity
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-sm mx-4 md:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Identity Verification</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <p className="text-sm text-gray-600">
                        Upload a clear photo of your government-issued ID. Your information will be kept secure and private.
                      </p>
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 md:p-6 text-center">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="hidden"
                          id="id-upload"
                        />
                        <label htmlFor="id-upload" className="cursor-pointer">
                          <Upload className="mx-auto mb-2 text-gray-400" size={28} />
                          <p className="text-sm text-gray-600">Click to upload ID document</p>
                        </label>
                      </div>
                      {selectedFile && (
                        <p className="text-sm text-green-600">
                          File selected: {selectedFile.name}
                        </p>
                      )}
                      <Button 
                        onClick={handleVerificationSubmit}
                        disabled={!selectedFile}
                        className="w-full bg-gradient-to-r from-pink-500 to-orange-400"
                      >
                        Submit for Verification
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              ) : (
                <Badge className="bg-blue-100 text-blue-700">
                  <Verified size={14} className="mr-1" />
                  Verified User
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Premium Subscription */}
        <Card className="border-2 border-gradient-to-r from-amber-200 to-orange-200">
          <CardHeader className="bg-gradient-to-r from-amber-50 to-orange-50 p-4 md:p-6">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Crown className="text-amber-600" size={20} />
              Unlock Premium Features
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6">
            <div className="space-y-4">
              <p className="text-gray-600 text-sm md:text-base">
                Get the most out of Lit Amor with premium features
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Heart className="text-amber-600" size={16} />
                  <span>Unlimited likes</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="text-amber-600" size={16} />
                  <span>Compatibility insights</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="text-amber-600" size={16} />
                  <span>Event access</span>
                </div>
              </div>
              <Button className="w-full sm:w-auto bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600">
                View Plans
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Reflection Section */}
        <Card>
          <CardHeader className="p-4 md:p-6">
            <CardTitle className="flex items-center gap-2 text-lg">
              <BookOpen className="text-pink-600" size={20} />
              Daily Reflection
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            <div className="space-y-4">
              <p className="text-gray-600 text-sm">
                Take a moment to reflect on your emotions and experiences today
              </p>
              <Textarea
                placeholder="How are you feeling today? What are you grateful for?"
                value={reflection}
                onChange={(e) => setReflection(e.target.value)}
                className="min-h-[80px] md:min-h-[100px]"
              />
              <Button variant="outline" className="w-full">
                Save Reflection
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* General Settings */}
        <Card>
          <CardHeader className="p-4 md:p-6">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Settings className="text-gray-600" size={20} />
              General Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6 pt-0">
            <div className="space-y-2 md:space-y-3">
              <Button variant="ghost" className="w-full justify-start text-sm md:text-base h-10 md:h-auto">
                <User size={16} className="mr-3" />
                Account Info
              </Button>
              <Button variant="ghost" className="w-full justify-start text-sm md:text-base h-10 md:h-auto">
                <Lock size={16} className="mr-3" />
                Change Password
              </Button>
              <Button variant="ghost" className="w-full justify-start text-sm md:text-base h-10 md:h-auto">
                <Bell size={16} className="mr-3" />
                Notifications
              </Button>
              <Button variant="ghost" className="w-full justify-start text-sm md:text-base h-10 md:h-auto">
                <FileText size={16} className="mr-3" />
                Privacy Policy
              </Button>
              <Button variant="ghost" className="w-full justify-start text-sm md:text-base h-10 md:h-auto">
                <FileText size={16} className="mr-3" />
                Terms & Conditions
              </Button>
              <Button variant="ghost" className="w-full justify-start text-sm md:text-base h-10 md:h-auto">
                <Info size={16} className="mr-3" />
                About Us
              </Button>
              <Button variant="ghost" className="w-full justify-start text-sm md:text-base h-10 md:h-auto">
                <QrCode size={16} className="mr-3" />
                Invite Friends
              </Button>
              <hr className="my-3 md:my-4" />
              <Button 
                variant="ghost" 
                className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50 text-sm md:text-base h-10 md:h-auto"
                onClick={handleLogout}
              >
                <LogOut size={16} className="mr-3" />
                Log Out
              </Button>
              <Button variant="ghost" className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50 text-sm md:text-base h-10 md:h-auto">
                <Trash2 size={16} className="mr-3" />
                Delete Account
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
