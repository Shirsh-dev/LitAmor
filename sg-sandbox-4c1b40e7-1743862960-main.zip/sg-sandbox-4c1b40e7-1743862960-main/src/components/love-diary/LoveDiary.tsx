
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  Plus, 
  Calendar, 
  Heart, 
  Star, 
  Smile, 
  Frown,
  ChevronLeft,
  ChevronRight,
  Filter,
  Search,
  BookOpen,
  Camera,
  Mic,
  Palette,
  Pin,
  Lock,
  Unlock
} from "lucide-react";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import { useRouter } from "next/router";
import { DiaryPage } from "./DiaryPage";
import { AddEntryModal } from "./AddEntryModal";
import { CalendarView } from "./CalendarView";

export interface DiaryEntry {
  id: string;
  title: string;
  content: string;
  author: "user" | "partner";
  authorName: string;
  date: string;
  mood: "love" | "funny" | "peaceful" | "sad";
  vibeScore: number;
  photos: string[];
  stickers: string[];
  background: string;
  isPrivate: boolean;
  isPinned: boolean;
  reactions: Array<{
    emoji: string;
    author: string;
  }>;
  comments: Array<{
    text: string;
    author: string;
    date: string;
  }>;
  voiceNote?: string;
  drawing?: string;
}

const MOCK_ENTRIES: DiaryEntry[] = [
  {
    id: "1",
    title: "Our First Date ❤️",
    content: "Today was magical! We went to that little café you mentioned, and I couldn't stop smiling. The way you laughed at my terrible jokes made my heart flutter. I can't wait for our next adventure together!",
    author: "user",
    authorName: "Sarah",
    date: "2024-01-15",
    mood: "love",
    vibeScore: 10,
    photos: ["https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=400"],
    stickers: ["💕", "☕", "🌟"],
    background: "pastel-pink",
    isPrivate: false,
    isPinned: true,
    reactions: [
      { emoji: "❤️", author: "John" },
      { emoji: "😍", author: "Sarah" }
    ],
    comments: [
      { text: "I was nervous but you made me feel so comfortable!", author: "John", date: "2024-01-15" }
    ]
  },
  {
    id: "2",
    title: "Rainy Day Cuddles",
    content: "Perfect Sunday staying in. We built a blanket fort and watched old movies. Sometimes the simplest moments are the most precious. Your head on my shoulder, the sound of rain... pure bliss.",
    author: "partner",
    authorName: "John",
    date: "2024-01-22",
    mood: "peaceful",
    vibeScore: 9,
    photos: [],
    stickers: ["🌧️", "🏠", "💤"],
    background: "watercolor-blue",
    isPrivate: false,
    isPinned: false,
    reactions: [
      { emoji: "🥰", author: "Sarah" }
    ],
    comments: []
  },
  {
    id: "3",
    title: "Cooking Disaster 😂",
    content: "Tried to make pasta from scratch... let's just say the kitchen looked like a flour bomb exploded! But we laughed until our stomachs hurt and ordered pizza instead. Best cooking fail ever!",
    author: "user",
    authorName: "Sarah",
    date: "2024-02-03",
    mood: "funny",
    vibeScore: 8,
    photos: ["https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400"],
    stickers: ["🍝", "💥", "😂"],
    background: "kraft-paper",
    isPrivate: false,
    isPinned: false,
    reactions: [
      { emoji: "😂", author: "John" },
      { emoji: "🍕", author: "Sarah" }
    ],
    comments: [
      { text: "I'm still finding flour in weird places!", author: "John", date: "2024-02-04" }
    ]
  }
];

export function LoveDiary() {
  const router = useRouter();
  const [entries, setEntries] = useState<DiaryEntry[]>(MOCK_ENTRIES);
  const [currentPage, setCurrentPage] = useState(0);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [filterMood, setFilterMood] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [isFlipping, setIsFlipping] = useState(false);

  const filteredEntries = entries.filter(entry => {
    const matchesSearch = searchQuery === "" || 
      entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.content.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesMood = filterMood === "all" || entry.mood === filterMood;
    
    return matchesSearch && matchesMood;
  });

  const handlePageChange = (direction: "next" | "prev") => {
    if (isFlipping) return;
    
    setIsFlipping(true);
    
    if (direction === "next" && currentPage < filteredEntries.length - 1) {
      setCurrentPage(prev => prev + 1);
    } else if (direction === "prev" && currentPage > 0) {
      setCurrentPage(prev => prev - 1);
    }
    
    setTimeout(() => setIsFlipping(false), 600);
  };

  const handleAddEntry = (newEntry: Omit<DiaryEntry, "id" | "date" | "reactions" | "comments">) => {
    const entry: DiaryEntry = {
      ...newEntry,
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      reactions: [],
      comments: []
    };
    
    setEntries(prev => [entry, ...prev]);
    setCurrentPage(0);
    setShowAddModal(false);
  };

  const handleReaction = (entryId: string, emoji: string) => {
    setEntries(prev => prev.map(entry => {
      if (entry.id === entryId) {
        const existingReaction = entry.reactions.find(r => r.author === "Current User");
        if (existingReaction) {
          return {
            ...entry,
            reactions: entry.reactions.map(r => 
              r.author === "Current User" ? { ...r, emoji } : r
            )
          };
        } else {
          return {
            ...entry,
            reactions: [...entry.reactions, { emoji, author: "Current User" }]
          };
        }
      }
      return entry;
    }));
  };

  const getMoodEmoji = (mood: string) => {
    switch (mood) {
      case "love": return "🥰";
      case "funny": return "😂";
      case "peaceful": return "😌";
      case "sad": return "😢";
      default: return "❤️";
    }
  };

  const getMoodColor = (mood: string) => {
    switch (mood) {
      case "love": return "bg-pink-100 text-pink-700";
      case "funny": return "bg-yellow-100 text-yellow-700";
      case "peaceful": return "bg-blue-100 text-blue-700";
      case "sad": return "bg-gray-100 text-gray-700";
      default: return "bg-pink-100 text-pink-700";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-orange-50 to-yellow-50 relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-20 h-20 bg-pink-200/30 rounded-full blur-xl" />
        <div className="absolute top-32 right-16 w-16 h-16 bg-orange-200/30 rounded-full blur-xl" />
        <div className="absolute bottom-20 left-20 w-24 h-24 bg-yellow-200/30 rounded-full blur-xl" />
        <div className="absolute bottom-40 right-10 w-18 h-18 bg-pink-200/30 rounded-full blur-xl" />
      </div>

      {/* Header */}
      <header className="relative z-10 w-full py-4 px-4 bg-white/80 backdrop-blur-sm border-b border-pink-100">
        <div className="flex items-center justify-between">
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full"
            onClick={() => router.back()}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-pink-600" />
              <h1 className="text-xl font-bold bg-gradient-to-r from-pink-600 to-orange-500 bg-clip-text text-transparent">
                Love Diary
              </h1>
            </div>
            <p className="text-xs text-gray-500">Our Shared Scrapbook</p>
          </div>
          
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full"
              onClick={() => setShowCalendar(true)}
            >
              <Calendar className="h-5 w-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full"
              onClick={() => setShowAddModal(true)}
            >
              <Plus className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Search and Filter Bar */}
      <div className="relative z-10 px-4 py-3 bg-white/60 backdrop-blur-sm border-b border-pink-100">
        <div className="flex items-center gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search memories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white/80 border border-pink-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-pink-400"
            />
          </div>
          
          <div className="flex items-center gap-2">
            {["all", "love", "funny", "peaceful", "sad"].map((mood) => (
              <Button
                key={mood}
                variant={filterMood === mood ? "default" : "ghost"}
                size="sm"
                onClick={() => setFilterMood(mood)}
                className={`rounded-full px-3 ${
                  filterMood === mood 
                    ? "bg-gradient-to-r from-pink-500 to-orange-400" 
                    : "hover:bg-pink-100"
                }`}
              >
                {mood === "all" ? "All" : getMoodEmoji(mood)}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Diary Content */}
      <div className="relative z-10 flex-1 px-4 py-6">
        {filteredEntries.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-96">
            <BookOpen className="h-16 w-16 text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No entries found</h3>
            <p className="text-gray-500 text-center mb-6">
              {searchQuery || filterMood !== "all" 
                ? "Try adjusting your search or filter" 
                : "Start your love story by adding your first memory"
              }
            </p>
            <Button 
              onClick={() => setShowAddModal(true)}
              className="bg-gradient-to-r from-pink-500 to-orange-400"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add First Entry
            </Button>
          </div>
        ) : (
          <div className="max-w-2xl mx-auto">
            {/* Page Counter */}
            <div className="text-center mb-4">
              <span className="text-sm text-gray-500">
                Page {currentPage + 1} of {filteredEntries.length}
              </span>
            </div>

            {/* Diary Page */}
            <div className="relative">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentPage}
                  initial={{ rotateY: isFlipping ? -90 : 0, opacity: isFlipping ? 0 : 1 }}
                  animate={{ rotateY: 0, opacity: 1 }}
                  exit={{ rotateY: 90, opacity: 0 }}
                  transition={{ duration: 0.6, ease: "easeInOut" }}
                  style={{ transformStyle: "preserve-3d" }}
                >
                  <DiaryPage 
                    entry={filteredEntries[currentPage]}
                    onReaction={handleReaction}
                  />
                </motion.div>
              </AnimatePresence>

              {/* Navigation Buttons */}
              <div className="absolute top-1/2 -translate-y-1/2 -left-16">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handlePageChange("prev")}
                  disabled={currentPage === 0 || isFlipping}
                  className="rounded-full bg-white/80 backdrop-blur-sm shadow-lg hover:bg-white"
                >
                  <ChevronLeft className="h-5 w-5" />
                </Button>
              </div>
              
              <div className="absolute top-1/2 -translate-y-1/2 -right-16">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handlePageChange("next")}
                  disabled={currentPage === filteredEntries.length - 1 || isFlipping}
                  className="rounded-full bg-white/80 backdrop-blur-sm shadow-lg hover:bg-white"
                >
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Page Indicators */}
            <div className="flex justify-center mt-6 gap-2">
              {filteredEntries.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentPage(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-200 ${
                    index === currentPage 
                      ? "bg-pink-500 w-6" 
                      : "bg-pink-200 hover:bg-pink-300"
                  }`}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Floating Action Button */}
      <div className="fixed bottom-24 right-6 z-20">
        <motion.div
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Button
            onClick={() => setShowAddModal(true)}
            size="icon"
            className="w-14 h-14 rounded-full bg-gradient-to-r from-pink-500 to-orange-400 hover:from-pink-600 hover:to-orange-500 shadow-lg shadow-pink-400/30"
          >
            <Plus className="h-6 w-6" />
          </Button>
        </motion.div>
      </div>

      {/* Modals */}
      <AddEntryModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSubmit={handleAddEntry}
      />

      <CalendarView
        isOpen={showCalendar}
        onClose={() => setShowCalendar(false)}
        entries={entries}
        onSelectEntry={(entryId) => {
          const index = filteredEntries.findIndex(e => e.id === entryId);
          if (index !== -1) {
            setCurrentPage(index);
            setShowCalendar(false);
          }
        }}
      />
    </div>
  );
}
