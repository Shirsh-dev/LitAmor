
import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Heart, 
  MessageCircle, 
  Pin, 
  Lock, 
  Star,
  Camera,
  Mic,
  MoreHorizontal
} from "lucide-react";
import { DiaryEntry } from "./LoveDiary";

interface DiaryPageProps {
  entry: DiaryEntry;
  onReaction: (entryId: string, emoji: string) => void;
}

const REACTION_EMOJIS = ["❤️", "😍", "😂", "🥰", "😘", "👏", "🔥", "💯"];

export function DiaryPage({ entry, onReaction }: DiaryPageProps) {
  const [showReactions, setShowReactions] = useState(false);
  const [showComments, setShowComments] = useState(false);

  const getBackgroundStyle = (background: string) => {
    switch (background) {
      case "pastel-pink":
        return "bg-gradient-to-br from-pink-100 to-pink-200";
      case "watercolor-blue":
        return "bg-gradient-to-br from-blue-100 to-cyan-100";
      case "kraft-paper":
        return "bg-gradient-to-br from-amber-100 to-orange-100";
      case "lavender":
        return "bg-gradient-to-br from-purple-100 to-pink-100";
      default:
        return "bg-gradient-to-br from-pink-100 to-orange-100";
    }
  };

  const getMoodColor = (mood: string) => {
    switch (mood) {
      case "love": return "bg-pink-100 text-pink-700 border-pink-200";
      case "funny": return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "peaceful": return "bg-blue-100 text-blue-700 border-blue-200";
      case "sad": return "bg-gray-100 text-gray-700 border-gray-200";
      default: return "bg-pink-100 text-pink-700 border-pink-200";
    }
  };

  const getMoodEmoji = (mood: string) => {
    switch (mood) {
      case "love": return "🥰";
      case "funny": return "😂";
      case "peaceful": return "😌";
      case "sad": return "😢";
      default: return "❤️";
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      className="relative"
    >
      <Card className={`${getBackgroundStyle(entry.background)} border-2 border-white/50 shadow-xl min-h-[600px] relative overflow-hidden`}>
        {/* Decorative Elements */}
        <div className="absolute top-4 right-4 opacity-20">
          <div className="w-16 h-16 border-4 border-pink-300 rounded-full" />
        </div>
        <div className="absolute bottom-4 left-4 opacity-20">
          <div className="w-12 h-12 bg-orange-300 rounded-full" />
        </div>
        
        {/* Washi Tape Effect */}
        <div className="absolute top-0 left-8 w-16 h-6 bg-pink-300/60 -rotate-12 rounded-sm" />
        <div className="absolute bottom-0 right-12 w-20 h-6 bg-orange-300/60 rotate-12 rounded-sm" />

        <CardContent className="p-8 relative z-10">
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                {entry.isPinned && <Pin className="h-4 w-4 text-pink-600" />}
                {entry.isPrivate && <Lock className="h-4 w-4 text-gray-600" />}
                <Badge className={`${getMoodColor(entry.mood)} border`}>
                  {getMoodEmoji(entry.mood)} {entry.mood}
                </Badge>
              </div>
              
              <h2 className="text-2xl font-bold text-gray-800 mb-2 handwriting-font">
                {entry.title}
              </h2>
              
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <span>By {entry.authorName}</span>
                <span>{new Date(entry.date).toLocaleDateString()}</span>
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 text-yellow-500" />
                  <span>{entry.vibeScore}/10</span>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="mb-6">
            <p className="text-gray-700 leading-relaxed text-lg handwriting-font">
              {entry.content}
            </p>
          </div>

          {/* Photos */}
          {entry.photos.length > 0 && (
            <div className="mb-6">
              <div className="grid grid-cols-2 gap-4">
                {entry.photos.map((photo, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.05, rotate: index % 2 === 0 ? 2 : -2 }}
                    className="relative"
                  >
                    <div className="bg-white p-2 shadow-lg transform rotate-1 hover:rotate-0 transition-transform">
                      <img 
                        src={photo} 
                        alt={`Memory ${index + 1}`}
                        className="w-full h-32 object-cover rounded"
                      />
                      <div className="absolute top-1 right-1 w-4 h-4 bg-gray-400 rounded-full opacity-60" />
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Stickers */}
          {entry.stickers.length > 0 && (
            <div className="mb-6">
              <div className="flex flex-wrap gap-2">
                {entry.stickers.map((sticker, index) => (
                  <motion.span
                    key={index}
                    whileHover={{ scale: 1.2, rotate: 10 }}
                    className="text-2xl cursor-pointer"
                  >
                    {sticker}
                  </motion.span>
                ))}
              </div>
            </div>
          )}

          {/* Voice Note */}
          {entry.voiceNote && (
            <div className="mb-6">
              <div className="flex items-center gap-3 p-3 bg-white/60 rounded-lg">
                <Mic className="h-5 w-5 text-pink-600" />
                <div className="flex-1">
                  <div className="w-full h-2 bg-pink-200 rounded-full">
                    <div className="w-1/3 h-full bg-pink-500 rounded-full" />
                  </div>
                </div>
                <Button size="sm" variant="ghost">
                  Play
                </Button>
              </div>
            </div>
          )}

          {/* Reactions */}
          <div className="flex items-center justify-between pt-4 border-t border-white/50">
            <div className="flex items-center gap-3">
              <div className="flex -space-x-1">
                {entry.reactions.map((reaction, index) => (
                  <span key={index} className="text-lg">
                    {reaction.emoji}
                  </span>
                ))}
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowReactions(!showReactions)}
                className="text-gray-600 hover:text-pink-600"
              >
                <Heart className="h-4 w-4 mr-1" />
                React
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowComments(!showComments)}
                className="text-gray-600 hover:text-pink-600"
              >
                <MessageCircle className="h-4 w-4 mr-1" />
                {entry.comments.length}
              </Button>
            </div>
          </div>

          {/* Reaction Picker */}
          {showReactions && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-3 p-3 bg-white/80 rounded-lg"
            >
              <div className="flex gap-2">
                {REACTION_EMOJIS.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => {
                      onReaction(entry.id, emoji);
                      setShowReactions(false);
                    }}
                    className="text-xl hover:scale-125 transition-transform"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Comments */}
          {showComments && entry.comments.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-3 space-y-2"
            >
              {entry.comments.map((comment, index) => (
                <div key={index} className="p-3 bg-white/60 rounded-lg">
                  <p className="text-sm text-gray-700">{comment.text}</p>
                  <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                    <span>{comment.author}</span>
                    <span>•</span>
                    <span>{comment.date}</span>
                  </div>
                </div>
              ))}
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
