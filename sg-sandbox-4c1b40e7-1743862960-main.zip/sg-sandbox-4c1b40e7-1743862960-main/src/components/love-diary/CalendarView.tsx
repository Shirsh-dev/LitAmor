
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Calendar } from "lucide-react";
import { DiaryEntry } from "./LoveDiary";

interface CalendarViewProps {
  isOpen: boolean;
  onClose: () => void;
  entries: DiaryEntry[];
  onSelectEntry: (entryId: string) => void;
}

export function CalendarView({ isOpen, onClose, entries, onSelectEntry }: CalendarViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date());

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const getEntriesForDate = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    return entries.filter(entry => entry.date === dateString);
  };

  const navigateMonth = (direction: "prev" | "next") => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === "prev") {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const getMoodEmoji = (mood: string) => {
    switch (mood) {
      case "love": return "🥰";
      case "funny": return "😂";
      case "peaceful": return "😌";
      case "sad": return "😢";
      default: return "❤️";
    }
  };

  const renderCalendarDays = () => {
    const daysInMonth = getDaysInMonth(currentDate);
    const firstDay = getFirstDayOfMonth(currentDate);
    const days = [];

    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-16" />);
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
      const dayEntries = getEntriesForDate(date);
      const isToday = date.toDateString() === new Date().toDateString();

      days.push(
        <div
          key={day}
          className={`h-16 border border-gray-100 p-1 relative cursor-pointer hover:bg-pink-50 transition-colors ${
            isToday ? "bg-pink-100 border-pink-300" : ""
          }`}
          onClick={() => {
            if (dayEntries.length > 0) {
              onSelectEntry(dayEntries[0].id);
            }
          }}
        >
          <div className="text-sm font-medium text-gray-700">{day}</div>
          {dayEntries.length > 0 && (
            <div className="absolute bottom-1 left-1 right-1">
              <div className="flex gap-1 overflow-hidden">
                {dayEntries.slice(0, 3).map((entry, index) => (
                  <span key={index} className="text-xs">
                    {getMoodEmoji(entry.mood)}
                  </span>
                ))}
                {dayEntries.length > 3 && (
                  <span className="text-xs text-gray-500">+{dayEntries.length - 3}</span>
                )}
              </div>
            </div>
          )}
        </div>
      );
    }

    return days;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-pink-600" />
            Memory Calendar
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Calendar Header */}
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigateMonth("prev")}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            
            <h3 className="text-lg font-semibold">
              {currentDate.toLocaleDateString('en-US', { 
                month: 'long', 
                year: 'numeric' 
              })}
            </h3>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigateMonth("next")}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Days of Week Header */}
          <div className="grid grid-cols-7 gap-0">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="h-8 flex items-center justify-center text-sm font-medium text-gray-600 border-b">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-0 border border-gray-200 rounded-lg overflow-hidden">
            {renderCalendarDays()}
          </div>

          {/* Legend */}
          <div className="flex items-center justify-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <span>🥰</span>
              <span>Love</span>
            </div>
            <div className="flex items-center gap-1">
              <span>😂</span>
              <span>Funny</span>
            </div>
            <div className="flex items-center gap-1">
              <span>😌</span>
              <span>Peaceful</span>
            </div>
            <div className="flex items-center gap-1">
              <span>😢</span>
              <span>Sad</span>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t">
            <div className="text-center">
              <div className="text-2xl font-bold text-pink-600">{entries.length}</div>
              <div className="text-sm text-gray-500">Total Memories</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {entries.filter(e => e.isPinned).length}
              </div>
              <div className="text-sm text-gray-500">Milestones</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {new Set(entries.map(e => e.date.substring(0, 7))).size}
              </div>
              <div className="text-sm text-gray-500">Active Months</div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
