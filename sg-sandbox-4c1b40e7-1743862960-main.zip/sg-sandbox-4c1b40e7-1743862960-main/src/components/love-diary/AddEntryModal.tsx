
import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  X, 
  Camera, 
  Mic, 
  Palette, 
  Star,
  Lock,
  Unlock,
  Pin,
  Send
} from "lucide-react";
import { DiaryEntry } from "./LoveDiary";

interface AddEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (entry: Omit<DiaryEntry, "id" | "date" | "reactions" | "comments">) => void;
}

const MOOD_OPTIONS = [
  { value: "love", emoji: "🥰", label: "Love" },
  { value: "funny", emoji: "😂", label: "Funny" },
  { value: "peaceful", emoji: "😌", label: "Peaceful" },
  { value: "sad", emoji: "😢", label: "Sad" }
];

const BACKGROUND_OPTIONS = [
  { value: "pastel-pink", label: "Pastel Pink", preview: "bg-gradient-to-br from-pink-100 to-pink-200" },
  { value: "watercolor-blue", label: "Watercolor Blue", preview: "bg-gradient-to-br from-blue-100 to-cyan-100" },
  { value: "kraft-paper", label: "Kraft Paper", preview: "bg-gradient-to-br from-amber-100 to-orange-100" },
  { value: "lavender", label: "Lavender", preview: "bg-gradient-to-br from-purple-100 to-pink-100" }
];

const STICKER_OPTIONS = [
  "❤️", "💕", "💖", "💝", "🌟", "⭐", "✨", "🌙", "☀️", "🌈",
  "🦋", "🌸", "🌺", "🌻", "🌹", "💐", "🎈", "🎉", "🎊", "🎁",
  "☕", "🍰", "🍕", "🍔", "🍟", "🍦", "🍓", "🍒", "🍑", "🥰"
];

export function AddEntryModal({ isOpen, onClose, onSubmit }: AddEntryModalProps) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [mood, setMood] = useState<"love" | "funny" | "peaceful" | "sad">("love");
  const [vibeScore, setVibeScore] = useState(8);
  const [selectedStickers, setSelectedStickers] = useState<string[]>([]);
  const [background, setBackground] = useState("pastel-pink");
  const [isPrivate, setIsPrivate] = useState(false);
  const [isPinned, setIsPinned] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);

  const handleSubmit = () => {
    if (!title.trim() || !content.trim()) return;

    const entry = {
      title: title.trim(),
      content: content.trim(),
      author: "user" as const,
      authorName: "You",
      mood,
      vibeScore,
      photos,
      stickers: selectedStickers,
      background,
      isPrivate,
      isPinned
    };

    onSubmit(entry);
    handleReset();
  };

  const handleReset = () => {
    setTitle("");
    setContent("");
    setMood("love");
    setVibeScore(8);
    setSelectedStickers([]);
    setBackground("pastel-pink");
    setIsPrivate(false);
    setIsPinned(false);
    setPhotos([]);
  };

  const handleClose = () => {
    handleReset();
    onClose();
  };

  const toggleSticker = (sticker: string) => {
    setSelectedStickers(prev => 
      prev.includes(sticker) 
        ? prev.filter(s => s !== sticker)
        : [...prev, sticker]
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              📝
            </motion.div>
            Add New Memory
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="content" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="media">Media</TabsTrigger>
            <TabsTrigger value="style">Style</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <div className="max-h-96 overflow-y-auto">
            <TabsContent value="content" className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  placeholder="Give your memory a title..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="content">Your Memory</Label>
                <Textarea
                  id="content"
                  placeholder="Write about this special moment..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="mt-1 min-h-32 resize-none"
                  maxLength={500}
                />
                <p className="text-xs text-gray-500 mt-1">
                  {content.length}/500 characters
                </p>
              </div>

              <div>
                <Label>Mood</Label>
                <div className="grid grid-cols-4 gap-2 mt-2">
                  {MOOD_OPTIONS.map((option) => (
                    <Button
                      key={option.value}
                      variant={mood === option.value ? "default" : "outline"}
                      onClick={() => setMood(option.value as any)}
                      className="flex flex-col items-center gap-1 h-auto py-3"
                    >
                      <span className="text-lg">{option.emoji}</span>
                      <span className="text-xs">{option.label}</span>
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <Label>Relationship Vibe Score: {vibeScore}/10</Label>
                <div className="flex items-center gap-2 mt-2">
                  {[...Array(10)].map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setVibeScore(i + 1)}
                      className={`w-8 h-8 rounded-full transition-all ${
                        i < vibeScore 
                          ? "bg-pink-500 text-white" 
                          : "bg-gray-200 hover:bg-gray-300"
                      }`}
                    >
                      {i + 1}
                    </button>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="media" className="space-y-4">
              <div>
                <Label>Photos</Label>
                <div className="mt-2 p-6 border-2 border-dashed border-gray-300 rounded-lg text-center">
                  <Camera className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                  <p className="text-sm text-gray-500">Click to add photos</p>
                  <p className="text-xs text-gray-400">or drag and drop</p>
                </div>
              </div>

              <div>
                <Label>Voice Note</Label>
                <div className="mt-2 p-4 border border-gray-300 rounded-lg">
                  <div className="flex items-center justify-center gap-3">
                    <Button variant="outline" size="sm">
                      <Mic className="h-4 w-4 mr-2" />
                      Record Voice Note
                    </Button>
                  </div>
                </div>
              </div>

              <div>
                <Label>Stickers</Label>
                <div className="grid grid-cols-10 gap-2 mt-2 max-h-32 overflow-y-auto">
                  {STICKER_OPTIONS.map((sticker) => (
                    <button
                      key={sticker}
                      onClick={() => toggleSticker(sticker)}
                      className={`text-2xl p-2 rounded-lg transition-all hover:scale-110 ${
                        selectedStickers.includes(sticker)
                          ? "bg-pink-100 ring-2 ring-pink-400"
                          : "hover:bg-gray-100"
                      }`}
                    >
                      {sticker}
                    </button>
                  ))}
                </div>
                {selectedStickers.length > 0 && (
                  <div className="mt-2 p-2 bg-gray-50 rounded-lg">
                    <p className="text-xs text-gray-600 mb-1">Selected:</p>
                    <div className="flex gap-1">
                      {selectedStickers.map((sticker, index) => (
                        <span key={index} className="text-lg">{sticker}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="style" className="space-y-4">
              <div>
                <Label>Background Theme</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {BACKGROUND_OPTIONS.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => setBackground(option.value)}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        background === option.value
                          ? "border-pink-400 ring-2 ring-pink-200"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <div className={`w-full h-16 rounded ${option.preview} mb-2`} />
                      <p className="text-xs font-medium">{option.label}</p>
                    </button>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="settings" className="space-y-4">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  {isPrivate ? <Lock className="h-5 w-5" /> : <Unlock className="h-5 w-5" />}
                  <div>
                    <p className="font-medium">Private Entry</p>
                    <p className="text-xs text-gray-500">Only visible to you</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  onClick={() => setIsPrivate(!isPrivate)}
                  className={isPrivate ? "text-orange-600" : "text-gray-600"}
                >
                  {isPrivate ? "Private" : "Shared"}
                </Button>
              </div>

              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Pin className="h-5 w-5" />
                  <div>
                    <p className="font-medium">Pin Entry</p>
                    <p className="text-xs text-gray-500">Mark as milestone</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  onClick={() => setIsPinned(!isPinned)}
                  className={isPinned ? "text-pink-600" : "text-gray-600"}
                >
                  {isPinned ? "Pinned" : "Pin"}
                </Button>
              </div>
            </TabsContent>
          </div>
        </Tabs>

        <div className="flex gap-3 pt-4 border-t">
          <Button variant="outline" onClick={handleClose} className="flex-1">
            <X className="h-4 w-4 mr-2" />
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={!title.trim() || !content.trim()}
            className="flex-1 bg-gradient-to-r from-pink-500 to-orange-400"
          >
            <Send className="h-4 w-4 mr-2" />
            Add Memory
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
