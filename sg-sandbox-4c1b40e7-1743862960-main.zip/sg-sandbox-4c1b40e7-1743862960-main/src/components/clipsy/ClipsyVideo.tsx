import { useState, useEffect } from "react";
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, Music, Play, Pause } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

interface ClipsyVideoProps {
  video: {
    id: number;
    username: string;
    avatar?: string;
    caption: string;
    likes: number;
    comments: number;
    shares: number;
    matchVibe: number;
    duration: string;
    music: string;
    backgroundVideo: string;
  };
  isCoupleMode?: boolean;
  isActive?: boolean;
  onDoubleClick?: () => void;
}

export function ClipsyVideo({ video, isCoupleMode = false, isActive = false, onDoubleClick }: ClipsyVideoProps) {
  const [liked, setLiked] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);
  const [likes, setLikes] = useState(video.likes);
  const [matchVibe, setMatchVibe] = useState(video.matchVibe);
  const [showHeartEffect, setShowHeartEffect] = useState(false);
  const [isPlaying, setIsPlaying] = useState(isActive);
  const [showPlayButton, setShowPlayButton] = useState(false);

  useEffect(() => {
    setIsPlaying(isActive);
  }, [isActive]);

  const handleLike = () => {
    setLiked(!liked);
    setLikes(liked ? likes - 1 : likes + 1);
    if (!liked) {
      setMatchVibe(Math.min(matchVibe + 5, 100));
      triggerHeartEffect();
    }
  };

  const handleDoubleClick = () => {
    if (!liked) {
      handleLike();
    }
    triggerHeartEffect();
    onDoubleClick?.();
  };

  const triggerHeartEffect = () => {
    setShowHeartEffect(true);
    setTimeout(() => setShowHeartEffect(false), 1000);
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
    setShowPlayButton(true);
    setTimeout(() => setShowPlayButton(false), 1000);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <div 
      className="relative w-full h-full bg-black overflow-hidden"
      onDoubleClick={handleDoubleClick}
    >
      {/* Background video/image */}
      <div className="absolute inset-0">
        <div 
          className="w-full h-full bg-cover bg-center"
          style={{ 
            backgroundImage: `url(${video.backgroundVideo})`,
            filter: isPlaying ? "none" : "brightness(0.7)"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30" />
      </div>

      {/* Play/Pause overlay */}
      <div className="absolute inset-0 flex items-center justify-center">
        <AnimatePresence>
          {(!isPlaying || showPlayButton) && (
            <motion.button
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              onClick={togglePlayPause}
              className="w-14 h-14 bg-black/40 backdrop-blur-sm rounded-full flex items-center justify-center"
            >
              {isPlaying ? (
                <Pause className="h-7 w-7 text-white ml-0.5" />
              ) : (
                <Play className="h-7 w-7 text-white ml-1" />
              )}
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      {/* Double-tap heart effect */}
      <AnimatePresence>
        {showHeartEffect && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: [0, 1.2, 1], opacity: [0, 1, 0] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
            className="absolute inset-0 flex items-center justify-center pointer-events-none z-20"
          >
            <Heart className="h-20 w-20 text-white fill-white drop-shadow-lg" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bottom content - mobile optimized */}
      <div className="absolute bottom-0 left-0 right-0 p-3 pb-safe-bottom">
        {/* User info and caption */}
        <div className="mb-3">
          <div className="flex items-center gap-2.5 mb-2">
            <Avatar className="w-10 h-10 border-2 border-white/50">
              <AvatarImage src={video.avatar} alt={video.username} />
              <AvatarFallback className="bg-gradient-to-r from-pink-500 to-purple-500 text-white text-sm">
                {video.username[0]}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-white font-semibold text-base truncate">{video.username}</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <div className="flex items-center gap-1">
                  <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                  <span className="text-white/80 text-xs">Live</span>
                </div>
                <span className="text-white/60 text-xs">•</span>
                <span className="text-white/80 text-xs">{video.duration}</span>
              </div>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="bg-transparent border-white text-white hover:bg-white hover:text-black text-xs px-3 py-1 h-7"
            >
              Follow
            </Button>
          </div>
          
          <p className="text-white text-sm leading-relaxed mb-2 max-w-[75%] line-clamp-2">
            {video.caption}
          </p>
          
          {/* Music info */}
          <div className="flex items-center gap-1.5 text-white/80">
            <Music className="h-3.5 w-3.5" />
            <span className="text-xs truncate max-w-[60%]">♪ {video.music}</span>
          </div>
        </div>
      </div>

      {/* Right side action buttons - mobile optimized */}
      <div className="absolute right-2 bottom-24 flex flex-col gap-4 items-center" style={{ bottom: "calc(6rem + env(safe-area-inset-bottom))" }}>
        {/* Like button */}
        <div className="flex flex-col items-center">
          <motion.button
            whileTap={{ scale: 0.8 }}
            onClick={handleLike}
            className={`w-11 h-11 rounded-full flex items-center justify-center backdrop-blur-sm ${
              liked ? "bg-pink-500/30" : "bg-black/30"
            }`}
          >
            <Heart 
              className={`h-6 w-6 ${liked ? "text-pink-500 fill-pink-500" : "text-white"}`} 
            />
          </motion.button>
          <span className="text-white text-xs font-medium mt-1">
            {formatNumber(likes)}
          </span>
        </div>

        {/* Comment button */}
        <div className="flex flex-col items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            className="w-11 h-11 rounded-full bg-black/30 backdrop-blur-sm text-white hover:bg-white/10 p-0"
          >
            <MessageCircle className="h-6 w-6" />
          </Button>
          <span className="text-white text-xs font-medium mt-1">
            {formatNumber(video.comments)}
          </span>
        </div>

        {/* Share button */}
        <div className="flex flex-col items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            className="w-11 h-11 rounded-full bg-black/30 backdrop-blur-sm text-white hover:bg-white/10 p-0"
          >
            <Share2 className="h-6 w-6" />
          </Button>
          <span className="text-white text-xs font-medium mt-1">
            {formatNumber(video.shares)}
          </span>
        </div>

        {/* Bookmark button */}
        <div className="flex flex-col items-center">
          <motion.button
            whileTap={{ scale: 0.8 }}
            onClick={() => setBookmarked(!bookmarked)}
            className={`w-11 h-11 rounded-full flex items-center justify-center backdrop-blur-sm ${
              bookmarked ? "bg-yellow-500/30" : "bg-black/30"
            }`}
          >
            <Bookmark 
              className={`h-5 w-5 ${bookmarked ? "text-yellow-500 fill-yellow-500" : "text-white"}`} 
            />
          </motion.button>
        </div>

        {/* More options */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="w-11 h-11 rounded-full bg-black/30 backdrop-blur-sm text-white hover:bg-white/10 p-0"
        >
          <MoreHorizontal className="h-5 w-5" />
        </Button>

        {/* Match Vibe meter - mobile optimized */}
        <div className="flex flex-col items-center mt-2">
          <div className="w-6 h-16 bg-black/40 backdrop-blur-sm rounded-full overflow-hidden relative border border-white/30">
            <motion.div 
              className="absolute bottom-0 w-full bg-gradient-to-t from-pink-500 via-purple-500 to-blue-500 rounded-full"
              initial={{ height: "0%" }}
              animate={{ height: `${matchVibe}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.div
                animate={{ 
                  scale: [1, 1.1, 1],
                  opacity: [0.7, 1, 0.7] 
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Heart className="h-3 w-3 text-white" />
              </motion.div>
            </div>
          </div>
          <span className="text-white text-xs font-medium mt-1">
            {matchVibe}%
          </span>
          <span className="text-white/60 text-xs">
            {isCoupleMode ? "Love" : "Match"}
          </span>
        </div>
      </div>

      {/* Progress bar at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-white/20">
        <motion.div
          className="h-full bg-white"
          initial={{ width: "0%" }}
          animate={{ width: isActive && isPlaying ? "100%" : "0%" }}
          transition={{ duration: 15, ease: "linear" }}
        />
      </div>
    </div>
  );
}