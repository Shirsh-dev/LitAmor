import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { ClipsyVideo } from "./ClipsyVideo";
import { ClipsyLogo } from "./ClipsyLogo";
import { Button } from "@/components/ui/button";
import { Search, Plus, Menu, ArrowLeft } from "lucide-react";

interface ClipsyFeedProps {
  isCoupleMode?: boolean;
  onNavigateBack?: () => void;
}

export function ClipsyFeed({ isCoupleMode = false, onNavigateBack }: ClipsyFeedProps) {
  const [activeVideoIndex, setActiveVideoIndex] = useState(0);
  const feedRef = useRef<HTMLDivElement>(null);
  
  // Enhanced mock data with more variety
  const videos = [
    {
      id: 1,
      username: isCoupleMode ? "Sarah & Mike" : "Jessica",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      caption: isCoupleMode ? "Our anniversary dinner date night 💕✨ #CoupleGoals" : "Beach day vibes and sunset magic ✨🌅 #BeachLife",
      likes: 1240,
      comments: 89,
      shares: 45,
      matchVibe: 85,
      duration: "0:15",
      music: isCoupleMode ? "Romantic Dinner Vibes" : "Summer Breeze",
      backgroundVideo: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=700&fit=crop",
    },
    {
      id: 2,
      username: isCoupleMode ? "Emma & John" : "Michael",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      caption: isCoupleMode ? "Couple workout challenge! Who's joining? 💪❤️ #FitCouple" : "Cooking my signature pasta 🍝 First date prep! #CookingSkills",
      likes: 876,
      comments: 156,
      shares: 67,
      matchVibe: 72,
      duration: "0:22",
      music: isCoupleMode ? "Workout Beats" : "Kitchen Vibes",
      backgroundVideo: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=700&fit=crop",
    },
    {
      id: 3,
      username: isCoupleMode ? "Lisa & David" : "Sophie",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      caption: isCoupleMode ? "Morning coffee ritual ☕ Our favorite way to start the day together" : "Daily vibe check: feeling absolutely amazing! ✨ #GoodVibes",
      likes: 2034,
      comments: 234,
      shares: 123,
      matchVibe: 91,
      duration: "0:18",
      music: isCoupleMode ? "Morning Jazz" : "Feel Good Hits",
      backgroundVideo: "https://images.unsplash.com/photo-1501594907352-04cda38ebc29?w=400&h=700&fit=crop",
    },
    {
      id: 4,
      username: isCoupleMode ? "Alex & Jamie" : "Ryan",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      caption: isCoupleMode ? "Date night ideas for the weekend 💡🌟 #DateNight" : "My favorite spot in the city for deep thoughts 🏙️ #CityLife",
      likes: 1567,
      comments: 198,
      shares: 89,
      matchVibe: 78,
      duration: "0:25",
      music: isCoupleMode ? "Date Night Playlist" : "Urban Chill",
      backgroundVideo: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=400&h=700&fit=crop",
    },
    {
      id: 5,
      username: isCoupleMode ? "Taylor & Jordan" : "Emily",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face",
      caption: isCoupleMode ? "Couples hiking adventure! 🥾⛰️ Nature therapy together" : "Adventure seeker looking for hiking partners! 🏔️ #AdventureTime",
      likes: 1789,
      comments: 267,
      shares: 156,
      matchVibe: 88,
      duration: "0:30",
      music: isCoupleMode ? "Nature Sounds" : "Adventure Vibes",
      backgroundVideo: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=700&fit=crop",
    },
    {
      id: 6,
      username: isCoupleMode ? "Maya & Chris" : "Daniel",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face",
      caption: isCoupleMode ? "Sunday brunch vibes 🥞🥂 Our weekly tradition" : "Brunch solo but loving life! 🥐☕ #SelfLove",
      likes: 945,
      comments: 78,
      shares: 34,
      matchVibe: 65,
      duration: "0:12",
      music: isCoupleMode ? "Sunday Chill" : "Brunch Beats",
      backgroundVideo: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400&h=700&fit=crop",
    }
  ];

  // Handle scroll to detect active video with improved precision
  useEffect(() => {
    const handleScroll = () => {
      if (feedRef.current) {
        const scrollPosition = feedRef.current.scrollTop;
        const videoHeight = window.innerHeight;
        const index = Math.round(scrollPosition / videoHeight);
        setActiveVideoIndex(Math.min(Math.max(index, 0), videos.length - 1));
      }
    };

    const feedElement = feedRef.current;
    if (feedElement) {
      feedElement.addEventListener("scroll", handleScroll, { passive: true });
      return () => feedElement.removeEventListener("scroll", handleScroll);
    }
  }, [videos.length]);

  return (
    <div className="relative h-full w-full overflow-hidden bg-black">
      {/* Top header - minimal like Instagram Reels */}
      <div className="fixed top-0 left-0 right-0 z-30 bg-gradient-to-b from-black/60 to-transparent px-3 py-2 pt-safe-top">
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-2">
            {/* Back button */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-white hover:bg-white/10 h-8 w-8"
              onClick={onNavigateBack}
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <ClipsyLogo size="small" />
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-8 w-8">
              <Search className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 h-8 w-8">
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Full-screen video feed */}
      <div 
        ref={feedRef}
        className="h-full overflow-y-auto overflow-x-hidden"
        style={{ 
          scrollSnapType: "y mandatory",
          WebkitOverflowScrolling: "touch",
          scrollbarWidth: "none",
          msOverflowStyle: "none"
        }}
      >
        <style jsx>{`
          div::-webkit-scrollbar {
            display: none;
          }
        `}</style>
        
        {videos.map((video, index) => (
          <div 
            key={video.id} 
            className="snap-start snap-always"
            style={{ 
              height: "100vh",
              scrollSnapAlign: "start"
            }}
          >
            <ClipsyVideo 
              video={video} 
              isCoupleMode={isCoupleMode}
              isActive={index === activeVideoIndex}
              onDoubleClick={() => {}}
            />
          </div>
        ))}
      </div>
      
      {/* Create button - floating like Instagram */}
      <div className="fixed bottom-safe-bottom right-3 z-30" style={{ bottom: "calc(env(safe-area-inset-bottom) + 1rem)" }}>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center shadow-lg"
        >
          <Plus className="h-5 w-5 text-white" />
        </motion.button>
      </div>
      
      {/* Video progress indicators - mobile optimized */}
      <div className="fixed right-1 top-1/2 transform -translate-y-1/2 z-20 flex flex-col gap-1.5">
        {videos.map((_, index) => (
          <div
            key={index}
            className={`w-0.5 h-6 rounded-full transition-all duration-300 ${
              index === activeVideoIndex 
                ? "bg-white" 
                : index < activeVideoIndex 
                  ? "bg-white/50" 
                  : "bg-white/20"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
