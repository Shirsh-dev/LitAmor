
import { Film, Heart } from "lucide-react";
import { motion } from "framer-motion";

interface ClipsyLogoProps {
  size?: "small" | "medium" | "large";
}

export function ClipsyLogo({ size = "medium" }: ClipsyLogoProps) {
  const sizeClasses = {
    small: "text-lg",
    medium: "text-2xl",
    large: "text-3xl",
  };

  const iconSize = {
    small: 16,
    medium: 20,
    large: 24,
  };

  return (
    <div className="flex items-center gap-1">
      <div className="relative">
        <Film size={iconSize[size]} className="text-pink-500" />
        <motion.div
          className="absolute -top-1 -right-1"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [1, 0.8, 1]
          }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <Heart size={iconSize[size] * 0.7} className="fill-pink-500 text-pink-500" />
        </motion.div>
      </div>
      <span className={`font-bold ${sizeClasses[size]} bg-clip-text text-transparent bg-gradient-to-r from-pink-500 to-purple-500`}>
        Clipsy
      </span>
    </div>
  );
}
