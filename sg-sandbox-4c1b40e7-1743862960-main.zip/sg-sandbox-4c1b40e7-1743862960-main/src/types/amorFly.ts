// AmorFly Types and Interfaces

// ============================================
// USER PROFILE TYPES
// ============================================

export interface AmorFlyUser {
  id: string;
  name?: string;
  age?: number;
  profession?: string;
  lifeGoals?: string;
  
  // Interest selection
  majorInterest: string;
  minorInterests: string[]; // 4 secondary interests
  whyILoveIt?: string; // Optional one-liner about major interest
  
  // Matchmaking status
  flyStatus: "ON" | "OFF"; // Ready to Fly toggle
  location?: {
    lat: number;
    lng: number;
    city: string;
    region: string;
  };
  
  // Matching history
  lastMatchTime?: number | null;
  chatExpiryTime?: number | null;
  currentMatchId?: string;
  recentMatchUserIds: string[]; // Track last 7 days of matches
  
  // Metadata
  createdAt: number;
  updatedAt?: string;
  firstAmorFlyOnboardShown: boolean;
}

// ============================================
// MATCH TYPES
// ============================================

export interface AmorFlyMatch {
  id: string;
  user1Id: string;
  user2Id: string;
  
  // Match basis
  sharedMajorInterest: string;
  overlappingMinorInterests: string[];
  
  // Lifecycle
  matchCreatedAt: number;
  matchExpiresAt: number; // Exactly 24 hours from creation
  status: "active" | "expired";
  
  // Chat tracking
  messageCount: number;
  lastMessageAt?: string;
  chatStartedAt?: string;
  
  // Voice call status
  voiceCallActive: boolean;
  
  // Location info (for match scope)
  matchScope: "local" | "regional" | "global";
  
  createdAt: number;
  updatedAt?: string;
}

// ============================================
// CHAT & MESSAGING TYPES
// ============================================

export interface AmorFlyMessage {
  id: string;
  matchId: string;
  senderId: string;
  receiverId: string;
  
  content: string;
  type: "text" | "voice_call_started" | "voice_call_ended" | "system";
  
  timestamp: string;
  read: boolean;
  
  // Ephemeral - auto-delete with match
  expiresAt: string;
}

export interface AmorFlyConversation {
  id: string;
  matchId: string;
  participants: [string, string];
  
  // Chat prompts
  displayedPrompt?: string;
  
  // Status
  isActive: boolean;
  expiresAt: string;
  
  // Voice call
  voiceCallEnabled: boolean;
  
  lastMessage?: string;
  lastMessageAt?: string;
  unreadCount: {
    [userId: string]: number;
  };
  
  createdAt: string;
  updatedAt: string;
}

// ============================================
// INTERESTS & PROMPTS
// ============================================

export const AMOR_FLY_INTERESTS = [
  "Art & Painting",
  "Music & Instruments",
  "Writing & Poetry",
  "Photography",
  "Cooking & Baking",
  "Fitness & Yoga",
  "Technology & Coding",
  "Gaming",
  "Reading & Literature",
  "Travel & Adventure",
  "Dance",
  "Theater & Acting",
  "Gardening",
  "Astronomy",
  "Psychology",
  "Philosophy",
  "Meditation & Mindfulness",
  "Languages",
  "Volunteering & Social Causes",
  "Entrepreneurship",
  "Fashion & Design",
  "Films & Cinema",
  "Board Games & Puzzles",
  "Sports",
  "Nature & Wildlife"
];

export const CHAT_PROMPTS: { [key: string]: string[] } = {
  default: [
    "What inspired you to choose this interest?",
    "What's one thing you want to learn today?",
    "Tell me something fun or weird about this hobby.",
    "How do you practice this in daily life?",
    "What's the best thing you've discovered through this interest?",
    "If you could master one skill in this area, what would it be?"
  ]
};

// ============================================
// MATCHMAKING TYPES
// ============================================

export interface AmorFlyMatchCandidate {
  userId: string;
  user: AmorFlyUser;
  sharedMajorInterest: string;
  overlappingMinorInterests: string[];
  distance: number; // in km
  matchScope: "local" | "regional" | "global";
}

export interface AmorFlyMatchmakingQueue {
  userId: string;
  majorInterest: string;
  flyStatus: "ON" | "OFF";
  lastMatchedAt?: string;
  excludedUserIds: string[]; // Users matched in last 7 days
  location: {
    lat: number;
    lng: number;
    region: string;
  };
  addedToQueueAt: string;
}

// ============================================
// UI DISPLAY TYPES
// ============================================

export interface AmorFlyMatchDisplay {
  id: string;
  name: string;
  age: number;
  profession: string;
  lifeGoals: string;
  majorInterest: string;
  minorInterests: string[];
  whyILoveIt?: string;
  
  // Match metadata
  expiresAt: string;
  isActive: boolean;
  matchScope: "local" | "regional" | "global";
}

// ============================================
// ONBOARDING TYPES
// ============================================

export interface AmorFlyOnboardingState {
  shown: boolean;
  completedAt?: string;
  skipped: boolean;
}

export interface AmorFlySettings {
  flyStatus: "ON" | "OFF";
  majorInterest: string;
  minorInterests: string[];
  notificationsEnabled: boolean;
}

// ============================================
// CONSTANTS
// ============================================

export const MATCH_DURATION_HOURS = 24;
export const REMATCH_COOLDOWN_DAYS = 7;
export const MAX_MINOR_INTERESTS = 4;
export const MIN_MINOR_INTERESTS = 4;
export const LOCAL_MATCH_RADIUS_KM = 50;
export const REGIONAL_MATCH_RADIUS_KM = 500;
export const DAILY_MATCH_REFRESH_HOUR = 0; // Midnight UTC

// ============================================
// VALIDATION TYPES
// ============================================

export interface AmorFlyValidation {
  isValid: boolean;
  errors: string[];
}

export function validateAmorFlySetup(
  majorInterest: string,
  minorInterests: string[],
  name: string,
  age: number,
  profession: string,
  lifeGoals: string
): AmorFlyValidation {
  const errors: string[] = [];

  if (!name || name.trim().length < 2) {
    errors.push("Name must be at least 2 characters");
  }

  if (age < 18 || age > 100) {
    errors.push("Age must be between 18 and 100");
  }

  if (!profession || profession.trim().length < 2) {
    errors.push("Profession is required");
  }

  if (!lifeGoals || lifeGoals.trim().length < 10) {
    errors.push("Life goals must be at least 10 characters");
  }

  if (!majorInterest || !AMOR_FLY_INTERESTS.includes(majorInterest)) {
    errors.push("Please select a valid major interest");
  }

  if (minorInterests.length !== MAX_MINOR_INTERESTS) {
    errors.push(`Please select exactly ${MAX_MINOR_INTERESTS} minor interests`);
  }

  if (minorInterests.includes(majorInterest)) {
    errors.push("Major interest cannot be one of your minor interests");
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}
