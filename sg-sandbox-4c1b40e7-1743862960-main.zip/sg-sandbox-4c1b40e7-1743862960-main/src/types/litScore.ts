export type HeartRating = "red" | "green" | "black";

export interface HeartType {
  type: HeartRating;
  icon: string;
  label: string;
  meaning: string;
  color: string;
  bgColor: string;
}

export interface WeeklyReflection {
  performance: string;
  solution: string;
}

export interface WeeklySubmission {
  userId: string;
  userName: string;
  heartRating: HeartRating;
  reflection: WeeklyReflection;
  submittedAt: Date;
}

export interface WeeklyEntry {
  weekNumber: number;
  weekStartDate: Date;
  weekEndDate: Date;
  partnerA?: WeeklySubmission;
  partnerB?: WeeklySubmission;
  bothSubmitted: boolean;
  revealedAt?: Date;
  status: "pending" | "partial" | "complete";
}

export type MilestoneLevel = 1 | 2 | 3 | 4;

export interface MilestoneRequirements {
  level: MilestoneLevel;
  title: string;
  description: string;
  icon: string;
  requirements: string[];
  color: string;
  bgColor: string;
}

export interface MonthlyMilestone {
  month: number;
  year: number;
  startDate: Date;
  endDate: Date;
  level: MilestoneLevel;
  achieved: boolean;
  achievedAt?: Date;
  weeklyEntries: WeeklyEntry[];
}

export interface CoupleProfile {
  coupleId: string;
  partnerA: {
    userId: string;
    name: string;
  };
  partnerB: {
    userId: string;
    name: string;
  };
  activatedAt: Date;
  premiumStatus: "free" | "trial" | "premium";
  premiumExpiresAt?: Date;
  firstLitScoreDate?: Date;
  currentStreak: number;
  longestStreak: number;
}

export interface LitScoreState {
  couple: CoupleProfile;
  currentWeek: WeeklyEntry;
  timeline: WeeklyEntry[];
  milestones: MonthlyMilestone[];
  canSubmit: boolean;
  needsReminder: boolean;
  isPremiumLocked: boolean;
}

export const HEART_TYPES: Record<HeartRating, HeartType> = {
  red: {
    type: "red",
    icon: "❤️",
    label: "Red Heart",
    meaning: "You really showed up this week. I felt loved and seen.",
    color: "text-red-500",
    bgColor: "bg-red-50"
  },
  green: {
    type: "green",
    icon: "💚",
    label: "Green Heart",
    meaning: "You were present and consistent. I felt balanced and supported.",
    color: "text-green-500",
    bgColor: "bg-green-50"
  },
  black: {
    type: "black",
    icon: "🖤",
    label: "Black Heart",
    meaning: "I didn't feel much effort. Something was missing or off.",
    color: "text-gray-800",
    bgColor: "bg-gray-50"
  }
};

export const MILESTONE_LEVELS: Record<MilestoneLevel, MilestoneRequirements> = {
  1: {
    level: 1,
    title: "The Starters",
    description: "Beginning your journey together",
    icon: "🏹",
    requirements: [
      "Completed 4 consecutive weekly submissions",
      "Reflected on at least one small issue"
    ],
    color: "text-blue-600",
    bgColor: "bg-blue-50"
  },
  2: {
    level: 2,
    title: "The Effort Makers",
    description: "Showing consistent care",
    icon: "🔥",
    requirements: [
      "At least one ❤️ Red Heart received/given",
      "Solution-based reflection included"
    ],
    color: "text-orange-600",
    bgColor: "bg-orange-50"
  },
  3: {
    level: 3,
    title: "The Growth Builders",
    description: "Building emotional consistency",
    icon: "🌱",
    requirements: [
      "Received 💚 or ❤️ hearts for 3 weeks in a row",
      "Shown consistent awareness in feedback"
    ],
    color: "text-green-600",
    bgColor: "bg-green-50"
  },
  4: {
    level: 4,
    title: "The Lit Lovers",
    description: "Masters of emotional connection",
    icon: "👑",
    requirements: [
      "Completed all 4 weeks (no missed weeks)",
      "No 🖤 Black Hearts in past 4 weeks",
      "Documented visible growth in reflections"
    ],
    color: "text-purple-600",
    bgColor: "bg-purple-50"
  }
};

export function getWeekNumber(date: Date): number {
  const startOfYear = new Date(date.getFullYear(), 0, 1);
  const days = Math.floor((date.getTime() - startOfYear.getTime()) / (24 * 60 * 60 * 1000));
  return Math.ceil((days + startOfYear.getDay() + 1) / 7);
}

export function getWeekStartDate(date: Date): Date {
  const day = date.getDay();
  const diff = date.getDate() - day;
  return new Date(date.setDate(diff));
}

export function getWeekEndDate(startDate: Date): Date {
  const endDate = new Date(startDate);
  endDate.setDate(endDate.getDate() + 6);
  return endDate;
}

export function isSunday(date: Date): boolean {
  return date.getDay() === 0;
}

export function getNextSunday(date: Date = new Date()): Date {
  const nextSunday = new Date(date);
  nextSunday.setDate(date.getDate() + (7 - date.getDay()));
  return nextSunday;
}

export function getDaysUntilSunday(date: Date = new Date()): number {
  if (isSunday(date)) return 0;
  return 7 - date.getDay();
}

export function isMonday(date: Date): boolean {
  return date.getDay() === 1;
}

export function hasThreeMonthsPassed(startDate: Date, currentDate: Date = new Date()): boolean {
  const threeMonthsLater = new Date(startDate);
  threeMonthsLater.setMonth(threeMonthsLater.getMonth() + 3);
  return currentDate >= threeMonthsLater;
}

export function calculateMilestoneLevel(entries: WeeklyEntry[]): MilestoneLevel {
  if (entries.length < 4) return 1;

  const completedWeeks = entries.filter(e => e.bothSubmitted);
  const redHearts = entries.filter(e => 
    e.partnerA?.heartRating === "red" || e.partnerB?.heartRating === "red"
  );
  const blackHearts = entries.filter(e => 
    e.partnerA?.heartRating === "black" || e.partnerB?.heartRating === "black"
  );

  let consecutiveGreenOrRed = 0;
  let maxConsecutive = 0;
  for (const entry of entries) {
    if (entry.bothSubmitted) {
      const hasGoodHearts = 
        (entry.partnerA?.heartRating === "red" || entry.partnerA?.heartRating === "green") &&
        (entry.partnerB?.heartRating === "red" || entry.partnerB?.heartRating === "green");
      
      if (hasGoodHearts) {
        consecutiveGreenOrRed++;
        maxConsecutive = Math.max(maxConsecutive, consecutiveGreenOrRed);
      } else {
        consecutiveGreenOrRed = 0;
      }
    }
  }

  if (completedWeeks.length === 4 && blackHearts.length === 0) {
    return 4;
  }

  if (maxConsecutive >= 3) {
    return 3;
  }

  if (redHearts.length > 0) {
    return 2;
  }

  if (completedWeeks.length === 4) {
    return 1;
  }

  return 1;
}
