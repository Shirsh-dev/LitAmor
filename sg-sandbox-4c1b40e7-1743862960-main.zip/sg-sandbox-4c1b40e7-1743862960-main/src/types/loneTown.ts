
// Lone Town Types and Interfaces

// ============================================
// COMPATIBILITY SCORING TYPES
// ============================================

export interface CompatibilityQuestionnaire {
  relationshipTypeSeeking: string; // 10 pts
  smoking: string; // 1 pt
  drinking: string; // 1 pt
  religion: string; // 5 pts (with ethnicity)
  ethnicity: string; // part of religion score
  firstLanguage: string; // 5 pts
  diet: string; // 2 pts
  profession: string; // 5 pts
  politicalViews: string; // 3 pts
  priorities: string[]; // 3 pts (Love, Money, Career)
  sexualAttraction: string; // 5 pts
  pastRelationships: string; // 3 pts
  personalityType: string; // 2 pts
  loveLanguage: string; // 3 pts
  lifestyle: string; // 2 pts
  heightPreference: {
    min: number;
    max: number;
  };
  locationPreference?: {
    maxDistance: number; // in km
  };
}

export interface UserProfile {
  id: string;
  firstName: string;
  age: number;
  gender: string;
  location: {
    lat: number;
    lng: number;
    city: string;
  };
  height: number; // in cm
  
  // Compatibility data
  questionnaire: CompatibilityQuestionnaire;
  basicCompatibilityScore: number; // 0-50 (Phase 1)
  
  // Profile content
  bio: string;
  interests: string[];
  hobbies: string[];
  futureGoal: string;
  
  // Personality questions (3-4 random ones shown)
  personalityAnswers: {
    question: string;
    answer: string;
  }[];
  
  // Photos (locked until profile unlock)
  photos: string[];
  
  // Settings
  matchVisibility: boolean;
  
  // Metadata
  isNew: boolean;
  firstLoneTownOnboardShown: boolean;
  questionnaireLastEditedAt: string;
  questionnaireEditCount: number;
  lastEditWarningShownAt?: string;
  
  createdAt: string;
  updatedAt: string;
}

// ============================================
// MATCH LIFECYCLE TYPES
// ============================================

export type MatchStatus = 
  | "active" // Initial 24h period
  | "pinned" // User pinned, extends beyond 24h
  | "expired" // 24h passed without pin
  | "cooldown" // One user unpinned, both in cooldown
  | "unmatched"; // Permanently ended

export interface Match {
  id: string;
  users: [string, string]; // [userId1, userId2]
  
  // Compatibility
  compatibilityScore: number; // Combined score for both users
  
  // Timestamps (all in UTC)
  matchCreatedAt: string;
  matchExpiresAt: string; // 24h from creation
  
  // Lifecycle states
  status: MatchStatus;
  pinnedAt?: string;
  pinnedBy?: string; // userId who pinned
  unpinnedAt?: string;
  unpinnedBy?: string;
  unmatchedAt?: string;
  unmatchedBy?: string;
  cooldownEndsAt?: string;
  
  // Chat & interaction tracking
  lastMessageAt?: string;
  messageCount: number;
  conversationStartedAt?: string;
  
  // Unlocks
  voiceCallUnlockedAt?: string; // 24h after pinning
  profileUnlockedAt?: string; // After 3 days continuous chat
  
  // Profile unlock calculation
  firstMessageTimestamp?: string;
  lastActivityTimestamp?: string;
  conversationDays: number; // Continuous days count
  maxGapHours: number; // Max allowed gap = 2h
  
  createdAt: string;
  updatedAt: string;
}

// ============================================
// CHAT & MESSAGING TYPES
// ============================================

export interface Conversation {
  id: string;
  matchId: string;
  participants: [string, string];
  
  isPinned: boolean;
  pinnedBy?: string;
  
  lastMessage: string;
  lastMessageAt: string;
  unreadCount: {
    [userId: string]: number;
  };
  
  // Voice call status
  voiceCallEnabled: boolean;
  
  // Profile unlock status
  profileUnlocked: boolean;
  
  status: "active" | "expired" | "cooldown" | "unmatched";
  
  createdAt: string;
  updatedAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  receiverId: string;
  
  content: string;
  type: "text" | "voice_call" | "system";
  
  timestamp: string;
  read: boolean;
}

// ============================================
// LOVE LETTER (RECONNECTION) TYPES
// ============================================

export interface LoveLetter {
  id: string;
  fromUserId: string;
  toUserId: string;
  previousMatchId: string;
  
  message: string; // Max 150 words
  
  status: "pending" | "accepted" | "declined";
  
  sentAt: string;
  respondedAt?: string;
  
  price: number; // ₹79
  paymentId: string;
  
  createdAt: string;
  updatedAt: string;
}

// ============================================
// DAILY MATCHMAKING TYPES
// ============================================

export interface MatchmakingQueue {
  userId: string;
  profile: UserProfile;
  availableForMatching: boolean;
  lastMatchedAt?: string;
  inCooldown: boolean;
  cooldownEndsAt?: string;
}

export interface MatchCandidate {
  userId: string;
  profile: UserProfile;
  compatibilityScore: number;
  distance: number; // in km
  passesHeightFilter: boolean;
}

// ============================================
// UI COMPONENT TYPES
// ============================================

export interface MatchCardDisplay {
  id: string;
  firstName: string;
  age: number;
  profession: string;
  interests: string[];
  hobbies: string[];
  futureGoal: string;
  
  // Expanded view data
  personalityQuestions: {
    question: string;
    answer: string;
  }[];
  
  // Unlock status
  photosUnlocked: boolean;
  profileUnlocked: boolean;
  voiceCallUnlocked: boolean;
  
  // Match metadata
  matchStatus: MatchStatus;
  expiresAt?: string;
  isPinned: boolean;
  conversationDays: number;
}

// ============================================
// ONBOARDING TYPES
// ============================================

export interface OnboardingState {
  shown: boolean;
  completedAt?: string;
  skipped: boolean;
}

export interface LoneTownSettings {
  matchVisibility: boolean;
  heightPreference: {
    min: number;
    max: number;
  };
  maxDistance?: number;
  questionnaireCompleted: boolean;
  compatibilityScore: number;
}

// ============================================
// VALIDATION & WARNINGS
// ============================================

export interface EditWarning {
  show: boolean;
  message: string;
  lastEditDate: string;
  editCount: number;
}

export const EDIT_WARNING_THRESHOLD_DAYS = 7;
export const MAX_EDITS_PER_WEEK = 1;
export const MAX_GAP_HOURS_FOR_CONTINUOUS_CHAT = 2;
export const DAYS_FOR_PROFILE_UNLOCK = 3;
export const HOURS_FOR_MATCH_EXPIRY = 24;
export const HOURS_FOR_VOICE_UNLOCK_AFTER_PIN = 24;
export const COOLDOWN_HOURS = 24;
export const LOVE_LETTER_PRICE = 79;
export const LOVE_LETTER_MAX_WORDS = 150;
