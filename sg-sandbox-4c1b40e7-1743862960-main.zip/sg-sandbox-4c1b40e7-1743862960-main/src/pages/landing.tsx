
import Head from "next/head";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { Heart, Play, Check, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

export default function LandingPage() {
  return (
    <>
      <Head>
        <title>LIT AMOR - Modern Dating App</title>
        <meta name="description" content="Application aimed at singles looking for a relationship" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="flex flex-col min-h-screen bg-gradient-to-b from-[#0e0e16] to-[#1a1a24]">
        {/* Header/Navigation */}
        <header className="container mx-auto py-6 px-4 flex justify-between items-center">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-pink-500 flex items-center justify-center">
              <Heart className="text-white" size={24} />
            </div>
          </div>
          
          <nav className="hidden md:flex space-x-8 text-gray-300">
            <Link href="#" className="hover:text-white">Home</Link>
            <Link href="#" className="hover:text-white">Features</Link>
            <Link href="#" className="hover:text-white">About</Link>
            <Link href="#" className="hover:text-white">Contact</Link>
          </nav>
          
          <div className="flex items-center space-x-2">
            <span className="text-white">Get App</span>
            <Switch />
          </div>
        </header>

        {/* Hero Section */}
        <section className="container mx-auto px-4 py-16 md:py-24 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold text-white leading-tight mb-4">
              When You Would Like<br />To Go On A Dating?
            </h1>
            <p className="text-gray-400 mb-8">
              Application aimed at singles looking for a relationship
            </p>
            
            <div className="flex items-center space-x-4 mb-8">
              <button className="bg-pink-500 rounded-full p-3 flex items-center justify-center">
                <Play className="text-white" size={20} />
              </button>
              <span className="text-white">
                Watch<br />Intro Video
              </span>
            </div>
            
            <div className="flex space-x-4">
              <Link href="#" className="text-gray-400 hover:text-white">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-facebook"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-twitter"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/></svg>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-mail"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
              </Link>
            </div>
          </div>
          
          <div className="md:w-1/2 relative">
            <div className="absolute top-0 right-0 bg-purple-600 rounded-lg p-2 text-white flex items-center">
              <span className="font-bold mr-2">8.6m</span>
              <div className="flex -space-x-2">
                <div className="w-6 h-6 rounded-full bg-gray-300"></div>
                <div className="w-6 h-6 rounded-full bg-gray-400"></div>
                <div className="w-6 h-6 rounded-full bg-gray-500"></div>
              </div>
              <p className="text-xs ml-2">There are 8.6 million user in the world<br />everyone is happy with our services.</p>
            </div>
            
            <div className="flex space-x-4">
              <div className="bg-[#1a1a24] rounded-2xl overflow-hidden shadow-lg">
                <Image src="/couple-dating-1.jpg" alt="Dating couple" width={300} height={400} className="object-cover" />
                <div className="p-2 flex items-center">
                  <span className="bg-pink-500 text-white text-xs px-2 py-1 rounded-full">Liked</span>
                </div>
              </div>
              
              <div className="bg-[#1a1a24] rounded-2xl overflow-hidden shadow-lg mt-10">
                <Image src="/couple-dating-2.jpg" alt="Dating couple" width={300} height={400} className="object-cover" />
                <div className="p-2 flex items-center">
                  <span className="bg-pink-500 text-white text-xs px-2 py-1 rounded-full">Liked</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="bg-[#f8f3f0] py-16">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 mb-10 md:mb-0">
                <div className="relative max-w-xs mx-auto">
                  <Image src="/app-screenshot.png" alt="App Screenshot" width={300} height={600} className="rounded-3xl" />
                  
                  <div className="absolute top-10 right-0 bg-white rounded-lg p-2 shadow-md">
                    <span className="text-xs">Upgrade to Premium</span>
                  </div>
                  
                  <div className="absolute top-1/4 right-0 bg-white rounded-lg p-2 shadow-md">
                    <span className="text-xs">Fashion</span>
                  </div>
                  
                  <div className="absolute bottom-1/4 left-0 bg-white rounded-lg p-2 shadow-md">
                    <span className="text-xs">Match Activity</span>
                    <div className="flex mt-1">
                      <div className="w-5 h-5 rounded-full bg-blue-500"></div>
                      <div className="w-5 h-5 rounded-full bg-green-500 -ml-1"></div>
                      <div className="w-5 h-5 rounded-full bg-red-500 -ml-1"></div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="md:w-1/2">
                <h2 className="text-3xl md:text-4xl font-bold mb-10">How It Works</h2>
                
                <div className="space-y-8">
                  <div className="flex items-start">
                    <div className="bg-white p-4 rounded-full shadow-md mr-4">
                      <Heart className="text-pink-500" size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">Ideal Relationship</h3>
                      <p className="text-gray-600">Set ut perspiciatis unde omnis iste natus error sit voluptatem accusantium</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-white p-4 rounded-full shadow-md mr-4">
                      <Heart className="text-pink-500" size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">Dating With Benefits</h3>
                      <p className="text-gray-600">Set ut perspiciatis unde omnis iste natus error sit voluptatem accusantium</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-white p-4 rounded-full shadow-md mr-4">
                      <Heart className="text-pink-500" size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">Date Beautiful Peoples</h3>
                      <p className="text-gray-600">Set ut perspiciatis unde omnis iste natus error sit voluptatem accusantium</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Smart Match Section */}
        <section className="bg-[#f8f3f0] py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">Chat & Yamo Smart Match</h2>
            <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">
              Set ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.
            </p>
            
            <div className="flex flex-col md:flex-row justify-center items-center gap-8">
              <div className="relative">
                <div className="bg-[#1a1a24] rounded-2xl overflow-hidden shadow-lg p-4">
                  <Image src="/person-phone-1.jpg" alt="Person using phone" width={300} height={400} className="rounded-xl object-cover" />
                </div>
                <div className="absolute top-4 left-0 bg-white rounded-lg p-2 shadow-md">
                  <span className="text-xs">Spotify</span>
                </div>
              </div>
              
              <div className="relative">
                <div className="flex flex-col items-center">
                  <div className="flex space-x-2 mb-4">
                    <Heart className="text-pink-500" size={24} />
                    <Heart className="text-pink-500" size={32} />
                    <Heart className="text-pink-500" size={24} />
                  </div>
                </div>
              </div>
              
              <div className="relative">
                <div className="bg-[#1a1a24] rounded-2xl overflow-hidden shadow-lg p-4">
                  <Image src="/person-phone-2.jpg" alt="Person using phone" width={300} height={400} className="rounded-xl object-cover" />
                </div>
                <div className="absolute top-4 right-0 bg-white rounded-lg p-2 shadow-md">
                  <span className="text-xs">Netflix</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Verified Profiles Section */}
        <section className="bg-[#f8f3f0] py-16">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 mb-10 md:mb-0">
                <h2 className="text-3xl md:text-4xl font-bold mb-4">
                  Only Real Verified Profiles Are Allowed To Join <Check className="inline text-green-500" size={24} />
                </h2>
                <p className="text-gray-600 mb-8">
                  Set ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.
                </p>
                
                <div className="flex space-x-4 mb-4">
                  <button className="flex items-center bg-black text-white px-4 py-2 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-apple mr-2"><path d="M12 20.94c1.5 0 2.75-.67 3.95-1.89a8.8 8.8 0 0 0 2.05-5.55c0-2.84-1.5-4.73-3.55-5.75-1-.5-2-.75-2.45-.75-.33 0-1.33.25-2.45.75-2.05 1.02-3.55 2.91-3.55 5.75 0 2.84 1.5 5.25 2.05 5.55 1.2 1.22 2.45 1.89 3.95 1.89Z"/><path d="M12 4c.56-1.75 2.33-3 4-3 .47 0 .94.15 1.25.4-1.2.69-2 2-2.25 3.6-.25 1.65.15 3.4 1 4.8-.7-.33-1.33-.8-1.75-1.4-.33-.5-.5-1.05-.5-1.6V6c0-.5-.33-.75-.75-.75S12 5.5 12 6v.8c0 .55-.17 1.1-.5 1.6-.42.6-1.05 1.07-1.75 1.4.85-1.4 1.25-3.15 1-4.8C10.5 3 9.7 1.69 8.5 1c.31-.25.78-.4 1.25-.4 1.67 0 3.44 1.25 4 3Z"/></svg>
                    iOS
                  </button>
                  <button className="flex items-center bg-black text-white px-4 py-2 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-smartphone mr-2"><rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/></svg>
                    Android
                  </button>
                </div>
              </div>
              
              <div className="md:w-1/2 relative">
                <div className="bg-pink-100 rounded-full w-full h-72 flex justify-center items-center">
                  <Image src="/group-people.jpg" alt="Group of people using phones" width={500} height={300} className="object-cover" />
                </div>
                
                <div className="absolute top-0 right-0 bg-white rounded-lg p-3 shadow-md">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-pink-500 mr-2"></div>
                    <div>
                      <p className="font-bold text-sm">Hello, How Are You?/Sweet</p>
                      <p className="text-xs text-gray-500">Kelly Sargent</p>
                      <p className="text-xs text-gray-500">2min Ago</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Reviews Section */}
        <section className="bg-[#1a1a24] py-16 text-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Reviews From Users</h2>
            
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/3 mb-8 md:mb-0">
                <Image src="/review-person.jpg" alt="Person giving review" width={300} height={400} className="rounded-xl mx-auto" />
              </div>
              
              <div className="md:w-2/3">
                <div className="mb-8">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 rounded-full bg-pink-500 mr-4"></div>
                    <div>
                      <p className="font-bold">Kelly Sargent</p>
                      <p className="text-gray-400">@Kelly</p>
                    </div>
                  </div>
                  
                  <div className="text-gray-300">
                    <p className="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                    <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div>
                    <p className="text-3xl font-bold">15k+</p>
                    <p className="text-gray-400">Daily Active Users</p>
                  </div>
                  
                  <div>
                    <p className="text-3xl font-bold">1458</p>
                    <p className="text-gray-400">New Members Today</p>
                  </div>
                  
                  <div>
                    <p className="text-3xl font-bold">30k+</p>
                    <p className="text-gray-400">Members from around the world</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-[#1a1a24] py-8 border-t border-gray-800">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="flex items-center mb-4 md:mb-0">
                <div className="w-10 h-10 rounded-full bg-pink-500 flex items-center justify-center mr-2">
                  <Heart className="text-white" size={20} />
                </div>
              </div>
              
              <nav className="flex space-x-8 text-gray-300 mb-4 md:mb-0">
                <Link href="#" className="hover:text-white">Home</Link>
                <Link href="#" className="hover:text-white">Features</Link>
                <Link href="#" className="hover:text-white">About</Link>
                <Link href="#" className="hover:text-white">Contact</Link>
              </nav>
              
              <div className="flex space-x-4">
                <Link href="#" className="text-gray-400 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-facebook"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                </Link>
                <Link href="#" className="text-gray-400 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-twitter"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/></svg>
                </Link>
                <Link href="#" className="text-gray-400 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-mail"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                </Link>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}
