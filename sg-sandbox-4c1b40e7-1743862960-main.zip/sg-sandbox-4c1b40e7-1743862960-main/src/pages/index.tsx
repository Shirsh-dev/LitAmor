import Head from "next/head";
import { motion } from "framer-motion";
import { Heart, Sparkles, Users, MessageCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import { useRouter } from "next/router";

export default function Home() {
  const router = useRouter();

  return (
    <>
      <Head>
        <title>LIT AMOR - Love but little more</title>
        <meta name="description" content="LIT AMOR - Where connections become something more" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <main className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-purple-50 relative overflow-hidden">
        {/* Decorative floating elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div 
            className="absolute top-20 left-[10%] text-pink-300/20"
            animate={{ 
              y: [0, 15, 0],
              rotate: [0, 5, 0]
            }}
            transition={{ 
              duration: 6,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Heart size={48} />
          </motion.div>
          
          <motion.div 
            className="absolute top-40 right-[15%] text-purple-300/20"
            animate={{ 
              y: [0, -20, 0],
              rotate: [0, -5, 0]
            }}
            transition={{ 
              duration: 7,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1
            }}
          >
            <Sparkles size={36} />
          </motion.div>
          
          <motion.div 
            className="absolute bottom-[20%] left-[20%] text-pink-300/20"
            animate={{ 
              y: [0, 10, 0],
              rotate: [0, 10, 0]
            }}
            transition={{ 
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.5
            }}
          >
            <Heart size={24} />
          </motion.div>
        </div>

        {/* Hero Section */}
        <div className="relative z-10 pt-16 pb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex flex-col items-center px-4"
          >
            <LitAmorLogo size="large" />
            <h1 className="text-5xl md:text-6xl font-bold mt-6 bg-gradient-to-r from-pink-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              LIT AMOR
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mt-4 text-center max-w-2xl">
              Love, but a little more
            </p>
            <p className="text-base text-muted-foreground/80 mt-2 text-center max-w-xl">
              Where genuine connections flourish and meaningful relationships begin
            </p>
          </motion.div>
        </div>

        {/* Main CTA Section */}
        <div className="relative z-10 px-4 pb-16">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="max-w-md mx-auto"
          >
            <Card className="border-0 shadow-2xl bg-white/80 backdrop-blur-sm overflow-hidden">
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold mb-3">Get Started</h2>
                  <p className="text-muted-foreground">
                    Join thousands finding meaningful connections
                  </p>
                </div>

                <div className="space-y-4">
                  <Button 
                    onClick={() => router.push("/auth/signup")}
                    className="w-full h-12 bg-gradient-to-r from-pink-500 via-purple-500 to-pink-500 hover:from-pink-600 hover:via-purple-600 hover:to-pink-600 text-white rounded-full text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    Create Account
                    <ArrowRight className="h-5 w-5 ml-2" />
                  </Button>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-gray-300"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="px-4 bg-white text-muted-foreground">
                        Already have an account?
                      </span>
                    </div>
                  </div>

                  <Button 
                    onClick={() => router.push("/auth/signin")}
                    variant="outline"
                    className="w-full h-12 rounded-full text-lg font-semibold border-2 border-purple-200 hover:bg-purple-50 hover:border-purple-300 transition-all duration-300"
                  >
                    Sign In
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Feature Highlights */}
        <div className="relative z-10 px-4 pb-16">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="max-w-4xl mx-auto"
          >
            <h3 className="text-2xl font-bold text-center mb-8">
              Why LIT AMOR?
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <motion.div
                whileHover={{ y: -5 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm h-full">
                  <CardContent className="p-6 text-center">
                    <div className="w-14 h-14 bg-gradient-to-br from-pink-400 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Heart className="h-7 w-7 text-white" />
                    </div>
                    <h4 className="font-bold text-lg mb-2">Smart Matching</h4>
                    <p className="text-sm text-muted-foreground">
                      Find compatible partners through intelligent compatibility scoring
                    </p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                whileHover={{ y: -5 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm h-full">
                  <CardContent className="p-6 text-center">
                    <div className="w-14 h-14 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Users className="h-7 w-7 text-white" />
                    </div>
                    <h4 className="font-bold text-lg mb-2">Verified Profiles</h4>
                    <p className="text-sm text-muted-foreground">
                      Connect with real people in a safe, authentic environment
                    </p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                whileHover={{ y: -5 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm h-full">
                  <CardContent className="p-6 text-center">
                    <div className="w-14 h-14 bg-gradient-to-br from-pink-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <MessageCircle className="h-7 w-7 text-white" />
                    </div>
                    <h4 className="font-bold text-lg mb-2">Meaningful Connections</h4>
                    <p className="text-sm text-muted-foreground">
                      Build deeper relationships through thoughtful features
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </motion.div>
        </div>

        {/* Footer */}
        <footer className="relative z-10 py-8 border-t border-gray-200 bg-white/50 backdrop-blur-sm">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} LIT AMOR. All rights reserved.
            </p>
            <div className="mt-4 flex justify-center space-x-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-pink-600 transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-pink-600 transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-pink-600 transition-colors">Contact Us</a>
            </div>
          </div>
        </footer>
      </main>
    </>
  );
}
