import Head from "next/head";
import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ArrowLeft, Search, Plus } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function MessagesPage() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  const [isCoupleUser, setIsCoupleUser] = useState(false);
  
  // Determine if user is a couple or single user
  // In a real app, this would come from your auth context or user profile
  useEffect(() => {
    // Mock check - in a real app, this would be based on the user's profile
    const path = router.asPath;
    setIsCoupleUser(path.includes('/couple') || localStorage.getItem('userType') === 'couple');
  }, [router.asPath]);
  
  // Mock data - in a real app, this would come from your backend
  const conversations = [
    {
      id: "1",
      name: "Emma Wilson",
      avatar: "",
      lastMessage: "Looking forward to our date tonight!",
      time: "10:30 AM",
      unread: 2,
      type: "partner"
    },
    {
      id: "2",
      name: "Michael Brown",
      avatar: "",
      lastMessage: "That movie was amazing!",
      time: "Yesterday",
      unread: 0,
      type: "match"
    },
    {
      id: "3",
      name: "Adventure Seekers",
      avatar: "",
      lastMessage: "Sarah: Who's joining the hike this weekend?",
      time: "2 days ago",
      unread: 5,
      type: "group"
    },
    {
      id: "4",
      name: "Jessica Taylor",
      avatar: "",
      lastMessage: "Thanks for the recommendation!",
      time: "3 days ago",
      unread: 0,
      type: "friend"
    }
  ];
  
  const filteredConversations = conversations.filter(convo => {
    // Filter by search query
    if (searchQuery && !convo.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Filter by tab
    if (activeTab === "all") return true;
    
    // Different tabs for couples vs singles
    if (isCoupleUser) {
      if (activeTab === "partners" && convo.type === "partner") return true;
      if (activeTab === "groups" && convo.type === "group") return true;
      if (activeTab === "friends" && convo.type === "friend") return true;
    } else {
      if (activeTab === "matches" && convo.type === "match") return true;
      if (activeTab === "groups" && convo.type === "group") return true;
      if (activeTab === "friends" && convo.type === "friend") return true;
    }
    
    return false;
  });
  
  const handleConversationClick = (id: string) => {
    router.push(`/messages/${id}`);
  };

  const handleGoBack = () => {
    // Navigate to the appropriate home page based on user type
    if (isCoupleUser) {
      router.push('/couple/home');
    } else {
      router.push('/singles/home');
    }
  };

  return (
    <>
      <Head>
        <title>Messages | LIT AMOR</title>
        <meta name="description" content="Your messages on LIT AMOR" />
      </Head>
      
      <main className="min-h-screen bg-gradient-to-br from-pink-100/50 via-background to-blue-50/50">
        {/* Top Bar */}
        <div className="fixed top-0 left-0 right-0 h-16 bg-background/80 backdrop-blur-md border-b border-border/30 flex items-center justify-between px-4 z-30">
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full"
            onClick={handleGoBack}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          
          <div className="flex items-center gap-2">
            <LitAmorLogo size="small" />
            <span className="font-bold text-lg">Messages</span>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-full">
            <Plus className="h-5 w-5" />
          </Button>
        </div>
        
        {/* Search Bar */}
        <div className="pt-20 px-4 pb-4 sticky top-16 bg-background/80 backdrop-blur-md z-20">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search conversations..."
              className="pl-10 rounded-full"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          {isCoupleUser ? (
            <Tabs defaultValue="all" className="mt-4" onValueChange={setActiveTab}>
              <TabsList className="w-full grid grid-cols-3">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="groups">Groups</TabsTrigger>
                <TabsTrigger value="friends">Friends</TabsTrigger>
              </TabsList>
            </Tabs>
          ) : (
            <Tabs defaultValue="all" className="mt-4" onValueChange={setActiveTab}>
              <TabsList className="w-full grid grid-cols-3">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="matches">Matches</TabsTrigger>
                <TabsTrigger value="groups">Groups</TabsTrigger>
              </TabsList>
            </Tabs>
          )}
        </div>
        
        {/* Conversations List */}
        <div className="px-4 pb-20">
          {filteredConversations.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No conversations found</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredConversations.map((convo) => (
                <Card 
                  key={convo.id} 
                  className="border-primary/10 cursor-pointer hover:bg-primary/5 transition-colors"
                  onClick={() => handleConversationClick(convo.id)}
                >
                  <CardContent className="p-4 flex items-center gap-3">
                    <Avatar className="h-12 w-12 border border-primary/20">
                      <AvatarFallback>{convo.name.charAt(0)}</AvatarFallback>
                      {convo.avatar && <AvatarImage src={convo.avatar} alt={convo.name} />}
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <h3 className="font-medium truncate">{convo.name}</h3>
                        <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">{convo.time}</span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{convo.lastMessage}</p>
                    </div>
                    
                    {convo.unread > 0 && (
                      <div className="bg-primary text-primary-foreground rounded-full h-5 min-w-5 flex items-center justify-center text-xs px-1.5">
                        {convo.unread}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </>
  );
}