
import Head from "next/head";
import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  ArrowLeft, 
  Phone, 
  Video, 
  Image as ImageIcon, 
  Mic, 
  Send, 
  MoreVertical,
  Lock, 
  Flame, 
  Search,
  HelpCircle,
  MessageSquare,
  Lightbulb
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Conversation prompts for singles
const CONVERSATION_PROMPTS = {
  questions: [
    "What's your favorite way to spend a weekend?",
    "If you could travel anywhere right now, where would you go?",
    "What's something you're passionate about?",
    "What's the best book you've read recently?",
    "Do you have any hidden talents?",
    "What's your idea of a perfect date?"
  ],
  answers: [
    "That sounds really interesting!",
    "I've never thought about it that way before.",
    "I completely agree with you on that.",
    "That's a great point!",
    "I'd love to hear more about that."
  ],
  icebreakers: [
    "I noticed you like hiking. Any favorite trails?",
    "Your profile mentioned cooking. What's your signature dish?",
    "I see we both enjoy photography. What do you like to photograph?",
    "We seem to have similar taste in music. Been to any good concerts lately?",
    "I'm curious about your travel photos. What was your favorite destination?"
  ]
};

export default function ConversationPage() {
  const router = useRouter();
  const { id } = router.query;
  const [message, setMessage] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [messages, setMessages] = useState<any[]>([]);
  const [contact, setContact] = useState<any>(null);
  const [isPartner, setIsPartner] = useState(false);
  const [isSingle, setIsSingle] = useState(false);
  const [promptType, setPromptType] = useState("questions");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  // Load conversation data
  useEffect(() => {
    if (!id) return;
    
    // Mock data - in a real app, this would come from your backend
    const mockContacts = {
      "1": {
        id: "1",
        name: "Khushi",
        avatar: "",
        status: "online",
        type: "partner"
      },
      "match_001": {
        id: "match_001",
        name: "Khushi",
        avatar: "",
        status: "online",
        type: "match"
      },
      "2": {
        id: "2",
        name: "Michael Brown",
        avatar: "",
        status: "last seen 2h ago",
        type: "match"
      }
    };
    
    const mockMessages = [
      {
        id: "m1",
        senderId: "1",
        text: "Hey! How's your day going?",
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        status: "read"
      },
      {
        id: "m2",
        senderId: "user",
        text: "It's going well! Just finished work. How about you?",
        timestamp: new Date(Date.now() - 3500000).toISOString(),
        status: "read"
      },
      {
        id: "m3",
        senderId: "1",
        text: "Pretty good! I was thinking about our connection.",
        timestamp: new Date(Date.now() - 3400000).toISOString(),
        status: "read"
      },
      {
        id: "m4",
        senderId: "user",
        text: "I'm excited to get to know you better!",
        timestamp: new Date(Date.now() - 3300000).toISOString(),
        status: "read"
      }
    ];
    
    // @ts-ignore - id is a string when defined
    const selectedContact = mockContacts[id] || mockContacts["1"];
    setContact(selectedContact);
    setMessages(mockMessages);
    
    // Determine if this is a partner conversation (for couples interface)
    setIsPartner(selectedContact?.type === "partner");
    
    // Determine if this is a singles match conversation
    setIsSingle(selectedContact?.type === "match");
    
  }, [id]);
  
  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    const newMessage = {
      id: `m${messages.length + 1}`,
      senderId: "user",
      text: message,
      timestamp: new Date().toISOString(),
      status: "sent"
    };
    
    setMessages([...messages, newMessage]);
    setMessage("");
    
    // Simulate response after 1 second
    setTimeout(() => {
      const responses = [
        "That's really interesting!",
        "I'd love to hear more about that.",
        "That sounds amazing!",
        "I completely agree with you.",
        "Tell me more!"
      ];
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      
      const responseMessage = {
        id: `m${messages.length + 2}`,
        senderId: contact?.id || "1",
        text: randomResponse,
        timestamp: new Date().toISOString(),
        status: "read"
      };
      
      setMessages(prev => [...prev, responseMessage]);
    }, 1000);
  };
  
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  const handleConversationPrompt = (prompt: string) => {
    setMessage(prompt);
  };

  const handleGoBack = () => {
    router.back();
  };
  
  return (
    <>
      <Head>
        <title>{contact ? `Chat with ${contact.name}` : "Conversation"} | LIT AMOR</title>
        <meta name="description" content="Your conversation on LIT AMOR" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
      </Head>
      
      <main className="min-h-screen bg-gradient-to-br from-pink-50/50 via-white to-blue-50/50 flex flex-col">
        {/* Top Bar - Mobile Optimized */}
        <div className="fixed top-0 left-0 right-0 h-14 md:h-16 bg-white/95 backdrop-blur-md border-b border-gray-200 flex items-center justify-between px-3 md:px-4 z-30 shadow-sm">
          <div className="flex items-center gap-2 md:gap-3 min-w-0 flex-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full h-9 w-9 md:h-10 md:w-10 flex-shrink-0"
              onClick={handleGoBack}
            >
              <ArrowLeft className="h-4 w-4 md:h-5 md:w-5" />
            </Button>
            
            {contact && (
              <div className="flex items-center gap-2 cursor-pointer min-w-0 flex-1" onClick={() => {}}>
                <Avatar className="h-8 w-8 md:h-9 md:w-9 border border-pink-200 flex-shrink-0">
                  <AvatarFallback className="bg-gradient-to-br from-pink-100 to-rose-100 text-pink-600 font-semibold">
                    {contact.name.charAt(0)}
                  </AvatarFallback>
                  {contact.avatar && <AvatarImage src={contact.avatar} alt={contact.name} />}
                </Avatar>
                <div className="min-w-0 flex-1">
                  <h3 className="font-semibold text-sm md:text-base leading-tight truncate">{contact.name}</h3>
                  <p className="text-xs text-gray-600 leading-tight truncate">{contact.status}</p>
                </div>
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-1 flex-shrink-0">
            {/* Show different options based on user type */}
            {isPartner && (
              <>
                <Button variant="ghost" size="icon" className="rounded-full h-9 w-9 md:h-10 md:w-10">
                  <Phone className="h-4 w-4 md:h-5 md:w-5" />
                </Button>
                <Button variant="ghost" size="icon" className="rounded-full h-9 w-9 md:h-10 md:w-10">
                  <Video className="h-4 w-4 md:h-5 md:w-5" />
                </Button>
              </>
            )}
            
            {isSingle && (
              <Button variant="ghost" size="icon" className="rounded-full h-9 w-9 md:h-10 md:w-10">
                <Phone className="h-4 w-4 md:h-5 md:w-5" />
              </Button>
            )}
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full h-9 w-9 md:h-10 md:w-10">
                  <MoreVertical className="h-4 w-4 md:h-5 md:w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem>
                  <Search className="h-4 w-4 mr-2" />
                  Search messages
                </DropdownMenuItem>
                
                {isPartner && (
                  <>
                    <DropdownMenuItem>
                      <Flame className="h-4 w-4 mr-2" />
                      View Streaks
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <ImageIcon className="h-4 w-4 mr-2" />
                      Shared media
                    </DropdownMenuItem>
                  </>
                )}
                
                <DropdownMenuSeparator />
                
                <DropdownMenuItem>
                  Change wallpaper
                </DropdownMenuItem>
                <DropdownMenuItem className="text-red-600">
                  Block chat
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        
        {/* Messages - Mobile Optimized */}
        <div className="flex-1 pt-14 md:pt-16 pb-32 md:pb-36 px-3 md:px-4 overflow-y-auto">
          <div className="space-y-3 md:space-y-4 max-w-3xl mx-auto">
            {messages.map((msg) => (
              <motion.div 
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className={`flex ${msg.senderId === "user" ? "justify-end" : "justify-start"}`}
              >
                <div 
                  className={`max-w-[85%] md:max-w-[75%] rounded-2xl px-3 md:px-4 py-2 md:py-2.5 shadow-sm ${
                    msg.senderId === "user" 
                      ? "bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-br-none" 
                      : "bg-white text-gray-800 rounded-bl-none border border-gray-100"
                  }`}
                >
                  <p className="text-sm md:text-base leading-relaxed break-words">{msg.text}</p>
                  <div 
                    className={`text-xs mt-1 ${
                      msg.senderId === "user" 
                        ? "text-white/80" 
                        : "text-gray-500"
                    } text-right`}
                  >
                    {formatTime(msg.timestamp)}
                  </div>
                </div>
              </motion.div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </div>
        
        {/* Message Input - Mobile Optimized */}
        <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-gray-200 p-3 md:p-4 z-30 shadow-lg">
          {/* Conversation prompts for singles only */}
          {isSingle && !isRecording && (
            <div className="mb-2 md:mb-3">
              <Tabs defaultValue="questions" onValueChange={setPromptType} className="w-full">
                <TabsList className="w-full grid grid-cols-3 mb-2 h-8 md:h-9">
                  <TabsTrigger value="questions" className="text-xs md:text-sm">
                    <HelpCircle className="h-3 w-3 mr-1" />
                    <span className="hidden sm:inline">Questions</span>
                  </TabsTrigger>
                  <TabsTrigger value="answers" className="text-xs md:text-sm">
                    <MessageSquare className="h-3 w-3 mr-1" />
                    <span className="hidden sm:inline">Responses</span>
                  </TabsTrigger>
                  <TabsTrigger value="icebreakers" className="text-xs md:text-sm">
                    <Lightbulb className="h-3 w-3 mr-1" />
                    <span className="hidden sm:inline">Icebreakers</span>
                  </TabsTrigger>
                </TabsList>
                <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                  {CONVERSATION_PROMPTS[promptType as keyof typeof CONVERSATION_PROMPTS].slice(0, 4).map((prompt, index) => (
                    <Button 
                      key={index} 
                      variant="outline" 
                      size="sm" 
                      className="whitespace-nowrap rounded-full text-xs h-7 md:h-8 border-pink-200 hover:bg-pink-50 flex-shrink-0"
                      onClick={() => handleConversationPrompt(prompt)}
                    >
                      {prompt.length > 35 ? `${prompt.substring(0, 35)}...` : prompt}
                    </Button>
                  ))}
                </div>
              </Tabs>
            </div>
          )}
          
          <div className="flex items-center gap-2">
            {/* Only show media button for couples */}
            {isPartner && (
              <Button variant="ghost" size="icon" className="rounded-full h-9 w-9 md:h-10 md:w-10 flex-shrink-0">
                <ImageIcon className="h-4 w-4 md:h-5 md:w-5" />
              </Button>
            )}
            
            {isRecording ? (
              <div className="flex-1 flex items-center justify-between bg-gray-100 rounded-full px-4 py-2 md:py-2.5">
                <div className="flex items-center gap-2">
                  <motion.div 
                    animate={{ scale: [1, 1.2, 1] }} 
                    transition={{ repeat: Infinity, duration: 1.5 }}
                    className="h-2.5 w-2.5 md:h-3 md:w-3 bg-red-500 rounded-full"
                  />
                  <span className="text-xs md:text-sm font-medium">Recording...</span>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setIsRecording(false)}
                  className="text-xs md:text-sm h-7 md:h-8"
                >
                  Cancel
                </Button>
              </div>
            ) : (
              <Input
                placeholder="Type a message..."
                className="flex-1 rounded-full border-gray-200 focus-visible:ring-pink-400 h-9 md:h-10 text-sm md:text-base"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
              />
            )}
            
            {message ? (
              <Button 
                variant="default" 
                size="icon" 
                className="rounded-full bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 h-9 w-9 md:h-10 md:w-10 flex-shrink-0 shadow-md"
                onClick={handleSendMessage}
              >
                <Send className="h-4 w-4 md:h-5 md:w-5" />
              </Button>
            ) : (
              <Button 
                variant="default" 
                size="icon" 
                className="rounded-full bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 h-9 w-9 md:h-10 md:w-10 flex-shrink-0 shadow-md"
                onClick={() => setIsRecording(!isRecording)}
              >
                <Mic className="h-4 w-4 md:h-5 md:w-5" />
              </Button>
            )}
          </div>
        </div>
      </main>
    </>
  );
}
