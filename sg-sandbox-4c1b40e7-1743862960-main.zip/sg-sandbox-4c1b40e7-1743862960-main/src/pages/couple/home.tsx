
import Head from "next/head";
import { useState } from "react";
import { 
  Heart, 
  BookOpen, 
  Sparkles, 
  Calendar,
  Gift,
  MapPin,
  Camera,
  Flame,
  Plus,
  ChevronRight,
  Star,
  User,
  ArrowRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import BottomNav from "@/components/navigation/BottomNav";
import { motion } from "framer-motion";
import { useRouter } from 'next/router';
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function CoupleHomePage() {
  const router = useRouter();

  const daysTogetherData = {
    partner1: "Khushi",
    partner2: "Shirsh",
    daysTogether: 412,
    relationshipStart: "2024-01-15",
    nextBirthday: { name: "Khushi", days: 3, age: 25 },
    anniversary: { months: 1, years: 2 }
  };

  const featureProgress = {
    litScore: { streak: 3, color: "red", percentage: 75 },
    amorStreak: { days: 12, percentage: 85 }
  };

  const reminders = [
    { icon: "💌", text: "This week's LitScore is due", link: "/couple/lit-score", urgent: true },
    { icon: "🕯️", text: "Your Love Diary awaits a new reflection", link: "/couple/love-diary", urgent: false },
    { icon: "🎂", text: "Khushi's birthday in 3 days!", link: "#birthday", urgent: true },
    { icon: "🔥", text: "Keep your Amor Streak alive — send a note today", link: "/couple/amore-streak", urgent: false }
  ];

  const memories = [
    { title: "Goa Trip 🌊", date: "Jan 2025", image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400" },
    { title: "First Movie Night 🍿", date: "6 months ago", image: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400" },
    { title: "A letter from Love Diary 💌", date: "Last week", image: "https://images.unsplash.com/photo-1516279754229-2d1783dc4e04?w=400" }
  ];

  const insights = [
    { icon: "🧠", text: "You write more reflections on Sundays — beautiful habit." },
    { icon: "💫", text: "You both express gratitude more than complaints — healthy love pattern." }
  ];

  const featureShortcuts = [
    { icon: BookOpen, label: "Love Diary", description: "Emotional journal", href: "/couple/love-diary", color: "from-pink-400 to-rose-500", featured: true },
    { icon: Heart, label: "LitScore", description: "Weekly reflections", href: "/couple/lit-score", color: "from-red-400 to-pink-500" },
    { icon: Flame, label: "Amor Streak", description: "Daily connection", href: "/couple/amore-streak", color: "from-orange-400 to-red-500" },
    { icon: Gift, label: "Gift Galaxy", description: "Send tokens", href: "/couple/planet#gift-galaxy", color: "from-purple-400 to-pink-500" },
    { icon: Camera, label: "Memory Capsule", description: "Save moments", href: "/couple/planet#memory-capsule", color: "from-blue-400 to-cyan-500" },
    { icon: MapPin, label: "DateVerse", description: "Plan outings", href: "/couple/planet#dateverse", color: "from-indigo-400 to-purple-500" }
  ];

  const diaryEntries = [
    { date: "Today", mood: "💖", preview: "Today I felt so grateful for the way you listened to me when I needed someone..." },
    { date: "Yesterday", mood: "🌸", preview: "The sunset reminded me of our first date, when everything felt new and magical..." },
    { date: "3 days ago", mood: "✨", preview: "I love how you make ordinary moments feel special, just by being there..." }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50">
      <Head>
        <title>Our Love Space | LIT AMOR</title>
        <meta name="description" content="Your emotional hub - Khushi ❤️ Shirsh" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
      </Head>
      
      <main className="min-h-screen pb-24">
        {/* Header - Couple Identity Card */}
        <div className="relative overflow-hidden bg-gradient-to-br from-pink-100/60 via-rose-100/40 to-orange-100/50">
          <motion.div 
            className="absolute top-4 md:top-8 right-4 md:right-8 w-16 md:w-24 h-16 md:h-24"
            animate={{ 
              scale: [1, 1.15, 1],
              opacity: [0.3, 0.6, 0.3]
            }}
            transition={{ 
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Heart className="w-full h-full text-pink-300" fill="currentColor" />
          </motion.div>

          <motion.div 
            className="absolute bottom-6 md:bottom-12 left-4 md:left-8 w-12 md:w-16 h-12 md:h-16"
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.2, 0.5, 0.2]
            }}
            transition={{ 
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1
            }}
          >
            <Sparkles className="w-full h-full text-rose-300" />
          </motion.div>
          
          <div className="relative px-4 md:px-6 pt-4 md:pt-6 pb-6 md:pb-8">
            <div className="flex items-center justify-between mb-6 md:mb-8">
              <LitAmorLogo size="small" />
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => router.push('/couple/profile')}
                className="text-rose-600 hover:bg-rose-100 h-9 w-9 md:h-10 md:w-10"
              >
                <User className="h-4 w-4 md:h-5 md:w-5" />
              </Button>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center"
            >
              <h1 className="text-2xl md:text-4xl font-bold mb-2 md:mb-3 bg-gradient-to-r from-pink-600 via-rose-600 to-orange-600 bg-clip-text text-transparent px-2">
                {daysTogetherData.partner1} ❤️ {daysTogetherData.partner2}
              </h1>
              <div className="inline-block bg-white/80 backdrop-blur rounded-full px-4 md:px-6 py-1.5 md:py-2 mb-2">
                <p className="text-base md:text-xl text-rose-600 font-semibold">
                  {daysTogetherData.daysTogether} Days of Love
                </p>
              </div>
              <p className="text-xs md:text-sm text-gray-700 italic mt-2 max-w-xs mx-auto px-4">
                "Still learning new ways to love."
              </p>
            </motion.div>
          </div>
        </div>

        {/* Quick Stats - Horizontal Scroll */}
        <div className="px-4 md:px-5 py-4 md:py-6">
          <div className="flex gap-3 md:gap-4 overflow-x-auto pb-2 md:pb-3 scrollbar-hide snap-x snap-mandatory -mx-4 px-4 md:mx-0 md:px-0">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="snap-start"
            >
              <Card className="min-w-[200px] md:min-w-[220px] bg-gradient-to-br from-pink-100/80 to-rose-100/60 border-pink-200/50 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-4 md:p-5">
                  <div className="flex items-center gap-2 md:gap-3 mb-2 md:mb-3">
                    <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white/80 flex items-center justify-center flex-shrink-0">
                      <span className="text-2xl md:text-3xl">🎂</span>
                    </div>
                    <span className="text-xs font-semibold text-rose-700 uppercase tracking-wide">Next Birthday</span>
                  </div>
                  <p className="text-sm md:text-base font-bold text-gray-900 mb-1">
                    {daysTogetherData.nextBirthday.name} turns {daysTogetherData.nextBirthday.age}
                  </p>
                  <p className="text-xs md:text-sm text-gray-700">in {daysTogetherData.nextBirthday.days} days 🎉</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="snap-start"
            >
              <Card className="min-w-[220px] bg-gradient-to-br from-purple-100/80 to-pink-100/60 border-purple-200/50 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-5">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 rounded-full bg-white/80 flex items-center justify-center">
                      <span className="text-3xl">💍</span>
                    </div>
                    <span className="text-xs font-semibold text-purple-700 uppercase tracking-wide">Anniversary</span>
                  </div>
                  <p className="text-base font-bold text-gray-900 mb-1">
                    {daysTogetherData.anniversary.months} Month to
                  </p>
                  <p className="text-sm text-gray-700">{daysTogetherData.anniversary.years} Years Together</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="snap-start"
            >
              <Card className="min-w-[220px] bg-gradient-to-br from-red-100/80 to-pink-100/60 border-red-200/50 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-5">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 rounded-full bg-white/80 flex items-center justify-center">
                      <span className="text-3xl">💞</span>
                    </div>
                    <span className="text-xs font-semibold text-red-700 uppercase tracking-wide">LitScore</span>
                  </div>
                  <p className="text-base font-bold text-gray-900 mb-1">
                    Red Heart Streak 💖
                  </p>
                  <p className="text-sm text-gray-700">{featureProgress.litScore.streak} Weeks Strong</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="snap-start"
            >
              <Card className="min-w-[220px] bg-gradient-to-br from-orange-100/80 to-red-100/60 border-orange-200/50 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-5">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 rounded-full bg-white/80 flex items-center justify-center">
                      <span className="text-3xl">🔥</span>
                    </div>
                    <span className="text-xs font-semibold text-orange-700 uppercase tracking-wide">Amor Streak</span>
                  </div>
                  <p className="text-base font-bold text-gray-900 mb-1">
                    {featureProgress.amorStreak.days} Days
                  </p>
                  <p className="text-sm text-gray-700">Connected Daily</p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>

        {/* Feature Progress Panel */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="px-5 mb-6"
        >
          <Card className="bg-white/90 backdrop-blur-sm shadow-lg border-rose-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-bold text-gray-800">Your Emotional Journey</h2>
                <Sparkles className="h-5 w-5 text-pink-400" />
              </div>
              
              <div className="space-y-5">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center">
                        <Heart className="h-4 w-4 text-red-600" fill="currentColor" />
                      </div>
                      <span className="text-sm font-semibold text-gray-800">LitScore</span>
                    </div>
                    <span className="text-sm font-bold text-gray-700">{featureProgress.litScore.percentage}%</span>
                  </div>
                  <Progress value={featureProgress.litScore.percentage} className="h-3 bg-red-50" />
                  <p className="text-xs text-gray-600 mt-2">Weekly emotional connection</p>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center">
                        <Flame className="h-4 w-4 text-orange-600" />
                      </div>
                      <span className="text-sm font-semibold text-gray-800">Amor Streak</span>
                    </div>
                    <span className="text-sm font-bold text-gray-700">{featureProgress.amorStreak.percentage}%</span>
                  </div>
                  <Progress value={featureProgress.amorStreak.percentage} className="h-3 bg-orange-50" />
                  <p className="text-xs text-gray-600 mt-2">Daily consistency</p>
                </div>
              </div>

              <div className="mt-6 pt-5 border-t border-gray-100">
                <p className="text-sm text-center text-gray-700 italic font-medium">
                  "It's the small moments that grow your forever."
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Love Diary - The Centerpiece */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
          className="px-5 mb-6"
        >
          <Card className="bg-gradient-to-br from-pink-100 via-rose-100 to-orange-100 border-2 border-pink-300/50 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-pink-200/30 to-transparent rounded-full -mr-20 -mt-20" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tl from-rose-200/30 to-transparent rounded-full -ml-16 -mb-16" />
            
            <CardContent className="p-7 relative">
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-pink-400 to-rose-500 flex items-center justify-center shadow-lg">
                      <BookOpen className="h-7 w-7 text-white" />
                    </div>
                    <motion.div
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="absolute -top-1 -right-1 w-4 h-4 bg-pink-400 rounded-full shadow-lg"
                    />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-1">Our Love Diary</h2>
                    <p className="text-sm text-gray-700">Your emotional journal together</p>
                  </div>
                </div>
                <Badge variant="secondary" className="bg-white/80 text-pink-700 font-semibold px-3 py-1">
                  {diaryEntries.length} entries
                </Badge>
              </div>

              <div className="space-y-3 mb-5">
                {diaryEntries.slice(0, 2).map((entry, index) => (
                  <motion.div 
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 + index * 0.1 }}
                    className="bg-white/90 backdrop-blur rounded-xl p-4 border border-pink-200/50 shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-2xl">{entry.mood}</span>
                      <span className="text-xs font-semibold text-gray-600 uppercase tracking-wide">{entry.date}</span>
                    </div>
                    <p className="text-sm text-gray-800 leading-relaxed line-clamp-2">{entry.preview}</p>
                  </motion.div>
                ))}
              </div>

              <div className="flex gap-3">
                <Button 
                  onClick={() => router.push('/couple/love-diary')}
                  className="flex-1 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 shadow-lg text-white font-semibold h-12"
                >
                  <Plus className="h-5 w-5 mr-2" />
                  Write Together
                </Button>
                <Button 
                  onClick={() => router.push('/couple/love-diary')}
                  variant="outline"
                  className="border-2 border-pink-400 text-pink-600 hover:bg-pink-50 h-12 px-5"
                >
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </div>

              <div className="mt-5 pt-5 border-t border-white/50">
                <p className="text-sm text-center text-gray-700 italic font-medium">
                  "Love isn't loud — it's written in small moments."
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Reminders & To-Dos */}
        {reminders.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="px-5 mb-6"
          >
            <h2 className="text-xl font-bold mb-4 text-gray-800">Gentle Reminders</h2>
            <div className="space-y-3">
              {reminders.map((reminder, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                >
                  <Card 
                    className={`cursor-pointer transition-all hover:shadow-lg active:scale-98 ${
                      reminder.urgent 
                        ? 'border-l-4 border-l-pink-500 bg-gradient-to-r from-pink-50/80 to-white' 
                        : 'bg-white/90 border-gray-200'
                    }`}
                    onClick={() => router.push(reminder.link)}
                  >
                    <CardContent className="p-5 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-100 to-rose-100 flex items-center justify-center">
                          <span className="text-2xl">{reminder.icon}</span>
                        </div>
                        <p className="text-sm font-medium text-gray-800">{reminder.text}</p>
                      </div>
                      <ChevronRight className="h-6 w-6 text-gray-400" />
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Memory Highlights */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="px-5 mb-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">Memory Highlights</h2>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => router.push('/couple/planet#memory-capsule')}
              className="text-pink-600 hover:bg-pink-50 font-semibold"
            >
              View All
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
          
          <div className="flex gap-4 overflow-x-auto pb-3 scrollbar-hide snap-x snap-mandatory">
            {memories.map((memory, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.7 + index * 0.1 }}
                className="snap-start flex-shrink-0"
              >
                <Card className="w-56 overflow-hidden cursor-pointer hover:shadow-xl transition-all active:scale-95">
                  <div className="h-36 bg-gradient-to-br from-pink-200 to-orange-200 relative overflow-hidden">
                    <img 
                      src={memory.image} 
                      alt={memory.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-4 bg-white">
                    <p className="font-bold text-sm text-gray-900 mb-1">{memory.title}</p>
                    <p className="text-xs text-gray-600">{memory.date}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1 }}
              className="snap-start flex-shrink-0"
            >
              <Card 
                className="w-56 h-full cursor-pointer hover:shadow-xl transition-all active:scale-95 border-2 border-dashed border-pink-300 bg-gradient-to-br from-pink-50 to-rose-50"
                onClick={() => router.push('/couple/planet#memory-capsule')}
              >
                <CardContent className="h-full flex flex-col items-center justify-center p-6 gap-3">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-pink-200 to-rose-200 flex items-center justify-center">
                    <Plus className="h-7 w-7 text-pink-600" />
                  </div>
                  <p className="text-sm font-semibold text-pink-700">Add New Memory</p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </motion.div>

        {/* Emotional Insights */}
        {insights.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="px-5 mb-6"
          >
            <h2 className="text-xl font-bold mb-4 text-gray-800">Emotional Insights</h2>
            <div className="space-y-3">
              {insights.map((insight, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.8 + index * 0.1 }}
                >
                  <Card className="bg-gradient-to-r from-purple-50 via-pink-50 to-rose-50 border-purple-200/50 shadow-sm">
                    <CardContent className="p-5 flex items-start gap-4">
                      <div className="w-12 h-12 rounded-full bg-white/80 flex items-center justify-center flex-shrink-0">
                        <span className="text-2xl">{insight.icon}</span>
                      </div>
                      <p className="text-sm text-gray-800 leading-relaxed font-medium pt-2">{insight.text}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Navigation Shortcuts - Feature Hub Grid */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="px-5 mb-8"
        >
          <h2 className="text-xl font-bold mb-4 text-gray-800">Explore Features</h2>
          <div className="grid grid-cols-2 gap-4">
            {featureShortcuts.map((shortcut, index) => {
              const Icon = shortcut.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.9 + index * 0.05 }}
                >
                  <Card 
                    className={`cursor-pointer transition-all hover:shadow-lg active:scale-95 ${
                      shortcut.featured 
                        ? 'col-span-2 border-2 border-pink-400 bg-gradient-to-br from-pink-50 to-rose-50' 
                        : 'bg-white border-gray-200'
                    }`}
                    onClick={() => router.push(shortcut.href)}
                  >
                    <CardContent className={`${shortcut.featured ? 'p-6' : 'p-5'}`}>
                      <div className="flex items-center gap-4">
                        <div className={`${shortcut.featured ? 'w-14 h-14' : 'w-12 h-12'} rounded-xl bg-gradient-to-br ${shortcut.color} flex items-center justify-center shadow-md flex-shrink-0`}>
                          <Icon className={`${shortcut.featured ? 'h-7 w-7' : 'h-6 w-6'} text-white`} />
                        </div>
                        <div className="flex-1">
                          <p className={`${shortcut.featured ? 'text-base' : 'text-sm'} font-bold text-gray-900 mb-1`}>{shortcut.label}</p>
                          <p className="text-xs text-gray-600">{shortcut.description}</p>
                        </div>
                        {shortcut.featured && (
                          <motion.div
                            animate={{ scale: [1, 1.2, 1] }}
                            transition={{ duration: 2, repeat: Infinity }}
                          >
                            <Star className="h-6 w-6 text-pink-500" fill="currentColor" />
                          </motion.div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <p className="text-sm text-center text-gray-700 italic font-medium">
              "The heart remembers what effort plants."
            </p>
          </div>
        </motion.div>
      </main>
      
      <BottomNav />
    </div>
  );
}
