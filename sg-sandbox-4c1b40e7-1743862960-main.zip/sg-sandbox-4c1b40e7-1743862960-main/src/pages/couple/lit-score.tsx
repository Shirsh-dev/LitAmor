import Head from "next/head";
import { LitScoreMain } from "@/components/lit-score/LitScoreMain";
import BottomNav from "@/components/navigation/BottomNav";

export default function LitScorePage() {
  return (
    <>
      <Head>
        <title>LitScore - Weekly Emotional Check-in | LIT AMOR</title>
        <meta name="description" content="Your weekly emotional ritual - reflect on your relationship every Sunday with heart ratings and thoughtful reflections" />
        <meta name="keywords" content="relationship check-in, emotional reflection, weekly ritual, couple growth, relationship mindfulness" />
      </Head>
      
      <div className="min-h-screen pb-20">
        <LitScoreMain />
        <BottomNav />
      </div>
    </>
  );
}
