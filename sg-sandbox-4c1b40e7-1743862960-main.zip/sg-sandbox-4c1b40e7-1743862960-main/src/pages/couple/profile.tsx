import Head from "next/head";
import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Heart, 
  Star, 
  Camera, 
  Trophy, 
  Pencil, 
  Upload,
  Calendar,
  MapPin,
  Target,
  BookOpen,
  Gift,
  Settings,
  Shield,
  Crown,
  Users,
  MessageCircle,
  TreePine,
  Sparkles,
  CheckCircle,
  AlertTriangle,
  LogOut,
  Bell,
  Lock,
  CreditCard,
  HelpCircle,
  Mail,
  Palette,
  UserX,
  ChevronRight,
  Plus,
  Eye,
  Archive
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import BottomNav from "@/components/navigation/BottomNav";
import { AmoreStreakCounter } from "@/components/AmoreStreakCounter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

// Mock data for couple profile
const COUPLE_DATA = {
  firstName: "Shirsh",
  secondName: "Khushi",
  firstInitial: "S",
  secondInitial: "K",
  relationshipType: "Dating",
  startDate: "January 1, 2025",
  daysTogether: 248,
  firstBirthday: "October 11, 2002",
  secondBirthday: "September 1, 2001",
  bio: "Two hearts, one journey. Creating memories one day at a time ❤️",
  isVerified: true,
  isPremium: false,
  backgroundImage: null
};

const RELATIONSHIP_STATS = {
  currentStreak: 36,
  totalStreaks: 127,
  daysTogether: 248,
  dateSpotsExplored: 15,
  questsCompleted: 8,
  memoriesSaved: 42,
  compatibilityScore: 87,
  loveLetters: 152,
  gratitudeMessages: 89
};

const COMPATIBILITY_DATA = {
  score: 87,
  johnType: "The Romantic",
  sarahType: "The Adventurer",
  bestTrait: "Communication",
  growthZone: "Quality Time"
};

const MEMORIES_DATA = [
  { id: 1, type: "Love Tree", title: "Our First Date Album", date: "2 days ago", count: 12 },
  { id: 2, type: "Streak", title: "7-Day Communication Streak", date: "Today", count: 7 },
  { id: 3, type: "Memory", title: "Beach Sunset Memory", date: "1 week ago", count: 1 },
  { id: 4, type: "Journal", title: "Monthly Reflection", date: "2 weeks ago", count: 3 }
];

export default function CoupleProfilePage() {
  const router = useRouter();
  const [coupleData, setCoupleData] = useState(COUPLE_DATA);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showCompatibilityDialog, setShowCompatibilityDialog] = useState(false);
  const [showSettingsDialog, setShowSettingsDialog] = useState(false);
  const [showVerificationDialog, setShowVerificationDialog] = useState(false);
  const [showUnpairDialog, setShowUnpairDialog] = useState(false);
  const [activeMemoryFilter, setActiveMemoryFilter] = useState("all");
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  // Calculate days until next anniversary
  const calculateDaysToAnniversary = () => {
    const startDate = new Date(coupleData.startDate);
    const today = new Date();
    const thisYear = today.getFullYear();
    let anniversary = new Date(thisYear, startDate.getMonth(), startDate.getDate());
    
    if (anniversary < today) {
      anniversary = new Date(thisYear + 1, startDate.getMonth(), startDate.getDate());
    }
    
    const diffTime = anniversary.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const daysToAnniversary = calculateDaysToAnniversary();

  // Floating hearts animation - only render on client side
  const FloatingHearts = () => {
    if (!isClient) return null;
    
    return (
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute text-pink-300/20"
            initial={{ 
              x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 400),
              y: (typeof window !== 'undefined' ? window.innerHeight : 800) + 50,
              scale: 0.5 + Math.random() * 0.5
            }}
            animate={{
              y: -50,
              x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 400),
              rotate: 360
            }}
            transition={{
              duration: 8 + Math.random() * 4,
              repeat: Infinity,
              delay: i * 2,
              ease: "linear"
            }}
          >
            <Heart size={16 + Math.random() * 8} />
          </motion.div>
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-blue-50 pb-20">
      <Head>
        <title>Shirsh & Khushi | LIT AMOR</title>
        <meta name="description" content="Couple profile on LIT AMOR" />
      </Head>

      <main className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-orange-50 pb-20 relative">
        <FloatingHearts />
        
        {/* Top Bar */}
        <div className="fixed top-0 left-0 right-0 h-16 bg-white/90 backdrop-blur-md border-b border-pink-100 flex items-center justify-between px-4 z-30">
          <AmoreStreakCounter count={RELATIONSHIP_STATS.currentStreak} />
          
          <div className="flex items-center gap-2">
            <LitAmorLogo size="small" />
            <span className="font-bold text-lg bg-gradient-to-r from-pink-500 to-orange-400 bg-clip-text text-transparent">
              LIT AMOR
            </span>
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full hover:bg-pink-100"
            onClick={() => router.push("/messages")}
          >
            <MessageCircle className="h-5 w-5 text-pink-500" />
          </Button>
        </div>

        {/* Main Content */}
        <div className="pt-20 px-4 pb-16 space-y-6">
          {/* Profile Header Section */}
          <motion.div 
            className="relative"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            {/* Background Banner */}
            <div className="relative h-48 bg-gradient-to-r from-pink-400 via-pink-500 to-orange-400 rounded-2xl overflow-hidden">
              {coupleData.backgroundImage ? (
                <img 
                  src={coupleData.backgroundImage} 
                  alt="Couple background" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="absolute inset-0 bg-gradient-to-r from-pink-400 via-pink-500 to-orange-400" />
              )}
              
              {/* Upload overlay */}
              <div className="absolute top-4 right-4">
                <Button 
                  size="sm" 
                  variant="secondary" 
                  className="bg-white/20 backdrop-blur-sm border-white/30 text-white hover:bg-white/30"
                >
                  <Camera className="h-4 w-4 mr-2" />
                  Change Photo
                </Button>
              </div>

              {/* Verification Badge */}
              {coupleData.isVerified && (
                <div className="absolute top-4 left-4">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger>
                        <Badge className="bg-blue-500 text-white border-0">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Verified
                        </Badge>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>This couple is verified by Lit Amor</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              )}
            </div>

            {/* Couple Avatars */}
            <div className="flex justify-center -mt-16">
              <div className="flex -space-x-6">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Avatar className="h-24 w-24 border-4 border-white shadow-lg bg-gradient-to-br from-pink-200 to-pink-300">
                    <AvatarFallback className="text-pink-700 text-2xl font-bold">
                      {coupleData.firstInitial}
                    </AvatarFallback>
                  </Avatar>
                </motion.div>
                
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Avatar className="h-24 w-24 border-4 border-white shadow-lg bg-gradient-to-br from-orange-200 to-orange-300">
                    <AvatarFallback className="text-orange-700 text-2xl font-bold">
                      {coupleData.secondInitial}
                    </AvatarFallback>
                  </Avatar>
                </motion.div>
              </div>
            </div>

            {/* Couple Info */}
            <div className="text-center mt-6 space-y-3">
              <div className="flex items-center justify-center gap-2">
                <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-600 to-orange-500 bg-clip-text text-transparent">
                  {coupleData.firstName} & {coupleData.secondName}
                </h1>
                {coupleData.isPremium && (
                  <Crown className="h-6 w-6 text-yellow-500" />
                )}
              </div>
              
              <div className="flex items-center justify-center gap-1 text-gray-600">
                <Heart className="h-4 w-4 text-pink-500" />
                <span>Together since {coupleData.startDate}</span>
              </div>
              
              <div className="flex items-center justify-center gap-4 text-sm text-gray-500">
                <span className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  {RELATIONSHIP_STATS.daysTogether} days
                </span>
                <span className="flex items-center gap-1">
                  <Star className="h-4 w-4" />
                  {daysToAnniversary} days to anniversary
                </span>
              </div>

              <p className="text-gray-600 max-w-sm mx-auto italic">
                "{coupleData.bio}"
              </p>

              <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
                <DialogTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-4 rounded-full border-pink-200 text-pink-600 hover:bg-pink-50"
                  >
                    <Pencil className="h-4 w-4 mr-2" />
                    Edit Relationship Details
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Edit Relationship Details</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="relationshipType">Relationship Type</Label>
                      <Select defaultValue={coupleData.relationshipType}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Dating">Dating</SelectItem>
                          <SelectItem value="Engaged">Engaged</SelectItem>
                          <SelectItem value="Married">Married</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="startDate">Relationship Start Date</Label>
                      <Input type="date" defaultValue="2023-07-15" />
                    </div>
                    <div>
                      <Label htmlFor="bio">Love Letter Bio</Label>
                      <Textarea 
                        placeholder="Our journey in one line..."
                        defaultValue={coupleData.bio}
                        maxLength={100}
                      />
                    </div>
                    <Button className="w-full bg-gradient-to-r from-pink-500 to-orange-400">
                      Save Changes
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </motion.div>

          {/* Relationship Summary Cards */}
          <motion.div 
            className="grid grid-cols-3 gap-3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="text-center border-pink-100 shadow-sm">
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-pink-600">
                  {RELATIONSHIP_STATS.currentStreak}
                </div>
                <div className="text-xs text-gray-500 flex items-center justify-center gap-1">
                  <Heart className="h-3 w-3" />
                  Current Streak
                </div>
              </CardContent>
            </Card>
            
            <Card className="text-center border-pink-100 shadow-sm">
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-orange-600">
                  {RELATIONSHIP_STATS.totalStreaks}
                </div>
                <div className="text-xs text-gray-500 flex items-center justify-center gap-1">
                  <MessageCircle className="h-3 w-3" />
                  Total Streaks
                </div>
              </CardContent>
            </Card>
            
            <Card className="text-center border-pink-100 shadow-sm">
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-pink-600">
                  {RELATIONSHIP_STATS.daysTogether}
                </div>
                <div className="text-xs text-gray-500 flex items-center justify-center gap-1">
                  <Calendar className="h-3 w-3" />
                  Days Together
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Additional Stats Grid */}
          <motion.div 
            className="grid grid-cols-2 gap-3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Card className="border-pink-100 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <div className="text-lg font-bold text-gray-800">
                    {RELATIONSHIP_STATS.dateSpotsExplored}
                  </div>
                  <div className="text-xs text-gray-500">Date Spots</div>
                </div>
                <MapPin className="h-5 w-5 text-pink-500" />
              </CardContent>
            </Card>
            
            <Card className="border-pink-100 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <div className="text-lg font-bold text-gray-800">
                    {RELATIONSHIP_STATS.questsCompleted}
                  </div>
                  <div className="text-xs text-gray-500">Quests Done</div>
                </div>
                <Target className="h-5 w-5 text-orange-500" />
              </CardContent>
            </Card>
            
            <Card className="border-pink-100 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <div className="text-lg font-bold text-gray-800">
                    {RELATIONSHIP_STATS.memoriesSaved}
                  </div>
                  <div className="text-xs text-gray-500">Memories</div>
                </div>
                <Camera className="h-5 w-5 text-pink-500" />
              </CardContent>
            </Card>
            
            <Card className="border-pink-100 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <div className="text-lg font-bold text-gray-800">
                    {RELATIONSHIP_STATS.compatibilityScore}%
                  </div>
                  <div className="text-xs text-gray-500">Compatible</div>
                </div>
                <Sparkles className="h-5 w-5 text-orange-500" />
              </CardContent>
            </Card>
          </motion.div>

          {/* Compatibility Test Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Card className="border-pink-100 shadow-sm">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-gradient-to-r from-pink-100 to-orange-100 rounded-full p-3">
                      <Sparkles className="h-6 w-6 text-pink-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">Compatibility Score</h3>
                      <p className="text-sm text-gray-500">Based on your personality quiz</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-pink-600">
                      {COMPATIBILITY_DATA.score}%
                    </div>
                    <div className="text-xs text-gray-500">Highly Compatible</div>
                  </div>
                </div>
                
                <Progress 
                  value={COMPATIBILITY_DATA.score} 
                  className="h-3 mb-4 bg-pink-100"
                />
                
                <Dialog open={showCompatibilityDialog} onOpenChange={setShowCompatibilityDialog}>
                  <DialogTrigger asChild>
                    <Button 
                      variant="outline" 
                      className="w-full border-pink-200 text-pink-600 hover:bg-pink-50"
                    >
                      View Our Compatibility
                      <ChevronRight className="h-4 w-4 ml-2" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>Compatibility Results</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-6">
                      <div className="text-center">
                        <div className="text-4xl font-bold text-pink-600 mb-2">
                          {COMPATIBILITY_DATA.score}%
                        </div>
                        <p className="text-gray-600">Highly Compatible</p>
                      </div>
                      
                      <div className="space-y-4">
                        <div className="flex justify-between items-center p-3 bg-pink-50 rounded-lg">
                          <span className="font-medium">{coupleData.firstName}</span>
                          <span className="text-pink-600">{COMPATIBILITY_DATA.johnType}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                          <span className="font-medium">{coupleData.secondName}</span>
                          <span className="text-orange-600">{COMPATIBILITY_DATA.sarahType}</span>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex items-center gap-3">
                          <CheckCircle className="h-5 w-5 text-green-500" />
                          <div>
                            <div className="font-medium">Best Shared Trait</div>
                            <div className="text-sm text-gray-500">{COMPATIBILITY_DATA.bestTrait}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Target className="h-5 w-5 text-orange-500" />
                          <div>
                            <div className="font-medium">Growth Zone</div>
                            <div className="text-sm text-gray-500">{COMPATIBILITY_DATA.growthZone}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>
          </motion.div>

          {/* Memories & Activities Log */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
          >
            <Card className="border-pink-100 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-pink-600" />
                  Memories & Activities
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Filter buttons */}
                <div className="flex gap-2 overflow-x-auto pb-2">
                  {["all", "Love Tree", "Streak", "Memory", "Journal"].map((filter) => (
                    <Button
                      key={filter}
                      variant={activeMemoryFilter === filter ? "default" : "outline"}
                      size="sm"
                      className={`whitespace-nowrap ${
                        activeMemoryFilter === filter 
                          ? "bg-gradient-to-r from-pink-500 to-orange-400" 
                          : "border-pink-200 text-pink-600 hover:bg-pink-50"
                      }`}
                      onClick={() => setActiveMemoryFilter(filter)}
                    >
                      {filter === "all" ? "All" : filter}
                    </Button>
                  ))}
                </div>

                {/* Memory items */}
                <div className="space-y-3">
                  {MEMORIES_DATA
                    .filter(memory => activeMemoryFilter === "all" || memory.type === activeMemoryFilter)
                    .map((memory) => (
                      <div key={memory.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="bg-white rounded-full p-2">
                            {memory.type === "Love Tree" && <TreePine className="h-4 w-4 text-green-600" />}
                            {memory.type === "Streak" && <Heart className="h-4 w-4 text-pink-600" />}
                            {memory.type === "Memory" && <Camera className="h-4 w-4 text-blue-600" />}
                            {memory.type === "Journal" && <BookOpen className="h-4 w-4 text-purple-600" />}
                          </div>
                          <div>
                            <div className="font-medium text-sm">{memory.title}</div>
                            <div className="text-xs text-gray-500">{memory.date}</div>
                          </div>
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {memory.count}
                        </Badge>
                      </div>
                    ))}
                </div>

                {/* Action buttons */}
                <div className="grid grid-cols-2 gap-3 pt-4">
                  <Button 
                    variant="outline" 
                    className="border-green-200 text-green-600 hover:bg-green-50"
                    onClick={() => router.push("/couple/love-tree")}
                  >
                    <TreePine className="h-4 w-4 mr-2" />
                    View Love Tree
                  </Button>
                  <Button 
                    variant="outline" 
                    className="border-pink-200 text-pink-600 hover:bg-pink-50"
                  >
                    <Heart className="h-4 w-4 mr-2" />
                    Browse Streaks
                  </Button>
                  <Button 
                    variant="outline" 
                    className="border-blue-200 text-blue-600 hover:bg-blue-50"
                  >
                    <Camera className="h-4 w-4 mr-2" />
                    Memory Capsules
                  </Button>
                  <Button 
                    variant="outline" 
                    className="border-purple-200 text-purple-600 hover:bg-purple-50"
                  >
                    <Archive className="h-4 w-4 mr-2" />
                    View Archive
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Premium Access Card */}
          {!coupleData.isPremium && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              <Card className="border-yellow-200 bg-gradient-to-r from-yellow-50 to-orange-50 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <Crown className="h-6 w-6 text-yellow-600" />
                    <div>
                      <h3 className="font-semibold text-lg">Upgrade to Premium</h3>
                      <p className="text-sm text-gray-600">Unlock exclusive couple features</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mb-4 text-sm">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Unlimited Memory Capsules</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Premium compatibility insights</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Exclusive date & gift ideas</span>
                    </div>
                  </div>
                  
                  <Button className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                    <Crown className="h-4 w-4 mr-2" />
                    Upgrade Now
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Verification Section */}
          {!coupleData.isVerified && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.7 }}
            >
              <Card className="border-blue-200 bg-blue-50 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <Shield className="h-6 w-6 text-blue-600" />
                    <div>
                      <h3 className="font-semibold text-lg">Get Verified</h3>
                      <p className="text-sm text-gray-600">Verify your couple profile for trust</p>
                    </div>
                  </div>
                  
                  <Dialog open={showVerificationDialog} onOpenChange={setShowVerificationDialog}>
                    <DialogTrigger asChild>
                      <Button 
                        variant="outline" 
                        className="w-full border-blue-200 text-blue-600 hover:bg-blue-100"
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Verification Documents
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md">
                      <DialogHeader>
                        <DialogTitle>Couple Verification</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <p className="text-sm text-gray-600">
                          Upload ID documents from both partners to get your blue verification checkmark.
                        </p>
                        
                        <div className="space-y-3">
                          <div>
                            <Label>{coupleData.firstName}'s ID Document</Label>
                            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                              <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                              <p className="text-sm text-gray-500">Click to upload or drag and drop</p>
                            </div>
                          </div>
                          
                          <div>
                            <Label>{coupleData.secondName}'s ID Document</Label>
                            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                              <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                              <p className="text-sm text-gray-500">Click to upload or drag and drop</p>
                            </div>
                          </div>
                        </div>
                        
                        <Button className="w-full bg-blue-600 hover:bg-blue-700">
                          Submit for Verification
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Settings Panel */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            <Card className="border-pink-100 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5 text-pink-600" />
                  Couple Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  variant="ghost" 
                  className="w-full justify-between h-auto py-3 px-4 hover:bg-pink-50"
                >
                  <div className="flex items-center gap-3">
                    <Users className="h-5 w-5 text-gray-500" />
                    <span>Account Information</span>
                  </div>
                  <ChevronRight className="h-4 w-4" />
                </Button>
                
                <Button 
                  variant="ghost" 
                  className="w-full justify-between h-auto py-3 px-4 hover:bg-pink-50"
                >
                  <div className="flex items-center gap-3">
                    <Bell className="h-5 w-5 text-gray-500" />
                    <span>Notifications</span>
                  </div>
                  <ChevronRight className="h-4 w-4" />
                </Button>
                
                <Button 
                  variant="ghost" 
                  className="w-full justify-between h-auto py-3 px-4 hover:bg-pink-50"
                >
                  <div className="flex items-center gap-3">
                    <Lock className="h-5 w-5 text-gray-500" />
                    <span>Privacy Settings</span>
                  </div>
                  <ChevronRight className="h-4 w-4" />
                </Button>
                
                <Button 
                  variant="ghost" 
                  className="w-full justify-between h-auto py-3 px-4 hover:bg-pink-50"
                >
                  <div className="flex items-center gap-3">
                    <Palette className="h-5 w-5 text-gray-500" />
                    <span>Theme & Appearance</span>
                  </div>
                  <ChevronRight className="h-4 w-4" />
                </Button>
                
                <Button 
                  variant="ghost" 
                  className="w-full justify-between h-auto py-3 px-4 hover:bg-pink-50"
                >
                  <div className="flex items-center gap-3">
                    <CreditCard className="h-5 w-5 text-gray-500" />
                    <span>Subscription & Billing</span>
                  </div>
                  <ChevronRight className="h-4 w-4" />
                </Button>
                
                <Separator className="my-4" />
                
                <Button 
                  variant="ghost" 
                  className="w-full justify-between h-auto py-3 px-4 hover:bg-pink-50"
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className="h-5 w-5 text-gray-500" />
                    <span>Help & Support</span>
                  </div>
                  <ChevronRight className="h-4 w-4" />
                </Button>
                
                <Button 
                  variant="ghost" 
                  className="w-full justify-between h-auto py-3 px-4 hover:bg-pink-50"
                >
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-gray-500" />
                    <span>Contact Us</span>
                  </div>
                  <ChevronRight className="h-4 w-4" />
                </Button>
                
                <Separator className="my-4" />
                
                {/* Unpair Profile Option */}
                <Dialog open={showUnpairDialog} onOpenChange={setShowUnpairDialog}>
                  <DialogTrigger asChild>
                    <Button 
                      variant="ghost" 
                      className="w-full justify-between h-auto py-3 px-4 hover:bg-red-50 text-red-600"
                    >
                      <div className="flex items-center gap-3">
                        <UserX className="h-5 w-5" />
                        <span>Unpair Profile</span>
                      </div>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2 text-red-600">
                        <AlertTriangle className="h-5 w-5" />
                        Unpair Profile
                      </DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <p className="text-gray-600">
                        Are you sure you want to unpair your profile? This action will:
                      </p>
                      
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2 text-red-600">
                          <AlertTriangle className="h-4 w-4" />
                          <span>Send both users back to single interface</span>
                        </div>
                        <div className="flex items-center gap-2 text-red-600">
                          <AlertTriangle className="h-4 w-4" />
                          <span>Archive all shared memories</span>
                        </div>
                        <div className="flex items-center gap-2 text-red-600">
                          <AlertTriangle className="h-4 w-4" />
                          <span>Reset relationship statistics</span>
                        </div>
                      </div>
                      
                      <div className="flex gap-3">
                        <Button 
                          variant="outline" 
                          className="flex-1"
                          onClick={() => setShowUnpairDialog(false)}
                        >
                          Cancel
                        </Button>
                        <Button 
                          variant="destructive" 
                          className="flex-1"
                          onClick={() => {
                            // Handle unpair logic
                            router.push("/singles/profile");
                          }}
                        >
                          Unpair
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
                
                <Button 
                  variant="ghost" 
                  className="w-full justify-start h-auto py-3 px-4 hover:bg-gray-50 text-gray-600"
                  onClick={() => {
                    localStorage.clear();
                    sessionStorage.clear();
                    router.push("/auth/signin");
                  }}
                >
                  <LogOut className="h-5 w-5 mr-3" />
                  Log Out
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Add BottomNav component */}
        <BottomNav />
      </main>
    </div>
  );
}
