import Head from "next/head";
import { useState, useEffect } from "react";
import { Heart, Users, Calendar, Target, Activity, User, ArrowLeft, MapPin, Gift, Package, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import BottomNav from "@/components/navigation/BottomNav";
import { PlanetDiscoveryHub } from "@/components/planet/PlanetDiscoveryHub";
import { DateverseView } from "@/components/planet/features/DateverseView";
import { CoupleQuestsView } from "@/components/planet/features/CoupleQuestsView";
import { PulseOfPlanetView } from "@/components/planet/features/PulseOfPlanetView";
import { SoloSparksView } from "@/components/planet/features/SoloSparksView";
import { MoodTrailsView } from "@/components/planet/features/MoodTrailsView";
import { ThoughtDropsView } from "@/components/planet/features/ThoughtDropsView";
import { HiddenSpotsView } from "@/components/planet/features/HiddenSpotsView";
import { GiftGalaxyView } from "@/components/planet/features/GiftGalaxyView";
import { MemoryCapsulesView } from "@/components/planet/features/MemoryCapsulesView";
import { EventHorizonView } from "@/components/planet/features/EventHorizonView";
import { motion } from "framer-motion";
import { useRouter } from "next/router";

function AnimatedStars({ count = 50 }: { count?: number }) {
  const [mounted, setMounted] = useState(false);
  const [stars, setStars] = useState<Array<{ left: number; top: number; duration: number; delay: number }>>([]);

  useEffect(() => {
    setMounted(true);
    const generatedStars = [...Array(count)].map(() => ({
      left: Math.random() * 100,
      top: Math.random() * 100,
      duration: 2 + Math.random() * 3,
      delay: Math.random() * 2
    }));
    setStars(generatedStars);
  }, [count]);

  if (!mounted || stars.length === 0) {
    return null;
  }

  return (
    <div className="absolute inset-0 overflow-hidden">
      {stars.map((star, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-white rounded-full opacity-60"
          style={{
            left: `${star.left}%`,
            top: `${star.top}%`,
          }}
          animate={{
            opacity: [0.3, 1, 0.3],
            scale: [0.5, 1, 0.5],
          }}
          transition={{
            duration: star.duration,
            repeat: Infinity,
            delay: star.delay,
          }}
        />
      ))}
    </div>
  );
}

export default function CouplePlanetPage() {
  const [activeView, setActiveView] = useState<"main" | "couple" | "self">("main");
  const [activeFeature, setActiveFeature] = useState<string | null>(null);
  const [savedItems, setSavedItems] = useState<string[]>([]);
  const router = useRouter();

  const handleSaveItem = (itemId: string) => {
    if (savedItems.includes(itemId)) {
      setSavedItems(savedItems.filter(id => id !== itemId));
    } else {
      setSavedItems([...savedItems, itemId]);
    }
  };

  const coupleFeatures = [
    {
      id: "dateverse",
      title: "Dateverse",
      icon: "🌌",
      component: <DateverseView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "couple-quests",
      title: "Couple Quests",
      icon: "🎯",
      component: <CoupleQuestsView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "pulse-of-planet",
      title: "Pulse of the Planet",
      icon: "🌍",
      component: <PulseOfPlanetView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    }
  ];

  const selfFeatures = [
    {
      id: "solo-sparks",
      title: "Solo Sparks",
      icon: "💎",
      component: <SoloSparksView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "mood-trails",
      title: "Mood Trails",
      icon: "🎭",
      component: <MoodTrailsView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "thought-drops",
      title: "Thought Drops",
      icon: "💭",
      component: <ThoughtDropsView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    }
  ];

  const exploreFeatures = [
    {
      id: "hidden-spots",
      title: "Hidden Spots",
      icon: "🗺️",
      gradient: "from-emerald-500 to-teal-500",
      component: <HiddenSpotsView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "gift-galaxy",
      title: "Gift Galaxy",
      icon: "🎁",
      gradient: "from-purple-500 to-pink-500",
      component: <GiftGalaxyView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "memory-capsules",
      title: "Memory Capsules",
      icon: "📦",
      gradient: "from-orange-500 to-red-500",
      component: <MemoryCapsulesView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "event-horizon",
      title: "Event Horizon",
      icon: "📅",
      gradient: "from-blue-500 to-indigo-500",
      component: <EventHorizonView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    }
  ];

  if (activeFeature) {
    const allFeatures = [...coupleFeatures, ...selfFeatures, ...exploreFeatures];
    const feature = allFeatures.find(f => f.id === activeFeature);
    if (feature) {
      return (
        <>
          <Head>
            <title>{feature.title} | LIT AMOR</title>
            <meta name="description" content={`Explore ${feature.title} together`} />
          </Head>
          <div className="min-h-screen">
            {feature.component}
          </div>
        </>
      );
    }
  }

  if (activeView === "main") {
    return (
      <>
        <Head>
          <title>Planet Discovery | LIT AMOR</title>
          <meta name="description" content="Explore your shared universe together" />
        </Head>
        
        <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 relative overflow-hidden">
          <AnimatedStars count={100} />

          <div className="fixed top-0 left-0 right-0 h-16 bg-slate-900/80 backdrop-blur-md border-b border-slate-700/30 flex items-center justify-between px-4 z-30">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => router.push('/couple/home')}
              className="text-slate-300 hover:text-white"
            >
              ← Back
            </Button>
            
            <div className="flex items-center gap-2">
              <LitAmorLogo size="small" />
              <span className="font-bold text-lg text-white">Lit Amor</span>
            </div>
            
            <div className="w-16" />
          </div>

          <div className="pt-20 pb-20 px-4 relative z-10">
            <div className="flex gap-3 mb-8 max-w-sm mx-auto">
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1"
              >
                <Card 
                  className="cursor-pointer transition-all duration-300 bg-slate-800/40 border-slate-600/30 hover:bg-slate-700/40 backdrop-blur-sm"
                  onClick={() => setActiveView("couple")}
                >
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl mb-2">💕</div>
                    <h3 className="text-white font-bold text-sm mb-1">Couple</h3>
                    <p className="text-slate-400 text-xs">Together</p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1"
              >
                <Card 
                  className="cursor-pointer transition-all duration-300 bg-slate-800/40 border-slate-600/30 hover:bg-slate-700/40 backdrop-blur-sm"
                  onClick={() => setActiveView("self")}
                >
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl mb-2">☀️</div>
                    <h3 className="text-white font-bold text-sm mb-1">Self</h3>
                    <p className="text-slate-400 text-xs">Growth</p>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            <div className="text-center mb-6">
              <h2 className="text-white text-xl font-bold mb-2">Explore More</h2>
              <p className="text-slate-400 text-sm">Discover new dimensions of your relationship</p>
            </div>

            <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
              {exploreFeatures.map((feature, index) => (
                <motion.div
                  key={feature.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Card 
                    className="aspect-square cursor-pointer transition-all duration-300 bg-slate-800/40 border-slate-600/30 hover:bg-slate-700/40 backdrop-blur-sm rounded-2xl overflow-hidden"
                    onClick={() => setActiveFeature(feature.id)}
                  >
                    <CardContent className="p-0 h-full relative">
                      <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-20`} />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent" />
                      
                      <div className="relative z-10 h-full flex flex-col items-center justify-center text-center p-4">
                        <motion.div
                          className="text-4xl mb-3 filter drop-shadow-lg"
                          animate={{
                            rotateY: [0, 5, 0, -5, 0],
                          }}
                          transition={{
                            duration: 4,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                        >
                          {feature.icon}
                        </motion.div>
                        
                        <h4 className="text-white text-sm font-bold leading-tight">
                          {feature.title}
                        </h4>
                        
                        <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 hover:opacity-10 transition-opacity duration-300 rounded-2xl`} />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="mt-8 text-center"
            >
              <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-4 max-w-sm mx-auto border border-slate-600/30">
                <div className="flex items-center justify-center gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">12</div>
                    <div className="text-xs text-slate-400">Activities</div>
                  </div>
                  <div className="w-px h-8 bg-slate-600/50" />
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">8</div>
                    <div className="text-xs text-slate-400">Day Streak</div>
                  </div>
                  <div className="w-px h-8 bg-slate-600/50" />
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">65%</div>
                    <div className="text-xs text-slate-400">Planet Growth</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          <BottomNav />
        </div>
      </>
    );
  }

  if (activeView === "couple") {
    return (
      <>
        <Head>
          <title>Couple Features | LIT AMOR</title>
          <meta name="description" content="Strengthen your bond and create magical moments together" />
        </Head>
        
        <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 relative overflow-hidden">
          <AnimatedStars count={50} />

          <div className="fixed top-0 left-0 right-0 h-16 bg-slate-900/80 backdrop-blur-md border-b border-slate-700/30 flex items-center justify-center px-4 z-30">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setActiveView("main")}
              className="absolute left-4 text-slate-300 hover:text-white"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
            </Button>
            
            <div className="flex items-center gap-2">
              <span className="text-2xl">💕</span>
              <span className="font-bold text-xl text-white">Couple</span>
            </div>
          </div>

          <div className="pt-20 pb-20 px-4 relative z-10 flex flex-col items-center justify-center min-h-screen">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-12"
            >
              <h2 className="text-white text-lg mb-2 max-w-sm mx-auto leading-relaxed">
                Strengthen your bond and create magical moments together
              </h2>
            </motion.div>

            <div className="relative w-72 h-72 mx-auto">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="absolute top-0 left-1/2 transform -translate-x-1/2"
              >
                <Card 
                  className="w-20 h-20 bg-slate-800/40 border-slate-600/30 hover:bg-slate-700/40 transition-all duration-300 cursor-pointer rounded-full"
                  onClick={() => setActiveFeature("dateverse")}
                >
                  <CardContent className="p-0 flex flex-col items-center justify-center h-full text-center">
                    <div className="text-xl mb-1">🌌</div>
                    <h4 className="text-white text-xs font-medium">Dateverse</h4>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="absolute bottom-0 left-0"
              >
                <Card 
                  className="w-20 h-20 bg-slate-800/40 border-slate-600/30 hover:bg-slate-700/40 transition-all duration-300 cursor-pointer rounded-full"
                  onClick={() => setActiveFeature("couple-quests")}
                >
                  <CardContent className="p-0 flex flex-col items-center justify-center h-full text-center">
                    <div className="text-xl mb-1">🎯</div>
                    <h4 className="text-white text-xs font-medium leading-tight">Couple Quests</h4>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="absolute bottom-0 right-0"
              >
                <Card 
                  className="w-20 h-20 bg-slate-800/40 border-slate-600/30 hover:bg-slate-700/40 transition-all duration-300 cursor-pointer rounded-full"
                  onClick={() => setActiveFeature("pulse-of-planet")}
                >
                  <CardContent className="p-0 flex flex-col items-center justify-center h-full text-center">
                    <div className="text-xl mb-1">🌍</div>
                    <h4 className="text-white text-xs font-medium leading-tight">Pulse of the Planet</h4>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>

          <BottomNav />
        </div>
      </>
    );
  }

  if (activeView === "self") {
    return (
      <>
        <Head>
          <title>Self Discovery | LIT AMOR</title>
          <meta name="description" content="Discover yourself and nurture your inner growth" />
        </Head>
        
        <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 relative overflow-hidden">
          <AnimatedStars count={50} />

          <div className="fixed top-0 left-0 right-0 h-16 bg-slate-900/80 backdrop-blur-md border-b border-slate-700/30 flex items-center justify-center px-4 z-30">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setActiveView("main")}
              className="absolute left-4 text-slate-300 hover:text-white"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
            </Button>
            
            <div className="flex items-center gap-2">
              <span className="text-2xl">☀️</span>
              <span className="font-bold text-xl text-white">Self</span>
            </div>
          </div>

          <div className="pt-20 pb-20 px-4 relative z-10 flex flex-col items-center justify-center min-h-screen">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-12"
            >
              <h2 className="text-white text-lg mb-2 max-w-sm mx-auto leading-relaxed">
                Discover yourself and nurture your inner growth
              </h2>
            </motion.div>

            <div className="relative w-72 h-72 mx-auto">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="absolute top-0 left-1/2 transform -translate-x-1/2"
              >
                <Card 
                  className="w-20 h-20 bg-slate-800/40 border-slate-600/30 hover:bg-slate-700/40 transition-all duration-300 cursor-pointer rounded-full"
                  onClick={() => setActiveFeature("solo-sparks")}
                >
                  <CardContent className="p-0 flex flex-col items-center justify-center h-full text-center">
                    <div className="text-xl mb-1">💎</div>
                    <h4 className="text-white text-xs font-medium">Solo Sparks</h4>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="absolute bottom-0 left-0"
              >
                <Card 
                  className="w-20 h-20 bg-slate-800/40 border-slate-600/30 hover:bg-slate-700/40 transition-all duration-300 cursor-pointer rounded-full"
                  onClick={() => setActiveFeature("mood-trails")}
                >
                  <CardContent className="p-0 flex flex-col items-center justify-center h-full text-center">
                    <div className="text-xl mb-1">🎭</div>
                    <h4 className="text-white text-xs font-medium">Mood Trails</h4>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="absolute bottom-0 right-0"
              >
                <Card 
                  className="w-20 h-20 bg-slate-800/40 border-slate-600/30 hover:bg-slate-700/40 transition-all duration-300 cursor-pointer rounded-full"
                  onClick={() => setActiveFeature("thought-drops")}
                >
                  <CardContent className="p-0 flex flex-col items-center justify-center h-full text-center">
                    <div className="text-xl mb-1">💭</div>
                    <h4 className="text-white text-xs font-medium leading-tight">Thought Drops</h4>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>

          <BottomNav />
        </div>
      </>
    );
  }

  return null;
}
