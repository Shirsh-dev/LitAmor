import Head from "next/head";
import { LoveTree } from "@/components/love-tree/LoveTree";
import BottomNav from "@/components/navigation/BottomNav";

export default function LoveTreePage() {
  return (
    <>
      <Head>
        <title>Love Tree | LIT AMOR</title>
        <meta name="description" content="Grow your relationship memories together" />
      </Head>
      
      <div className="min-h-screen pb-20">
        <LoveTree />
        <BottomNav />
      </div>
    </>
  );
}
