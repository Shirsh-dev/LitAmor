
import Head from "next/head";
import { LoveDiary } from "@/components/love-diary/LoveDiary";
import BottomNav from "@/components/navigation/BottomNav";

export default function LoveDiaryPage() {
  return (
    <>
      <Head>
        <title>Love Diary | LIT AMOR</title>
        <meta name="description" content="Your shared scrapbook of memories and moments together" />
        <meta name="keywords" content="love diary, couple memories, relationship scrapbook, shared journal" />
      </Head>
      
      <div className="min-h-screen pb-20">
        <LoveDiary />
        <BottomNav />
      </div>
    </>
  );
}
