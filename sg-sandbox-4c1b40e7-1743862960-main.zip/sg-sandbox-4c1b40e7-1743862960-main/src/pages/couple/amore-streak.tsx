import Head from "next/head";
import { AmoreStreakMain } from "@/components/amore-streak/AmoreStreakMain";
import BottomNav from "@/components/navigation/BottomNav";

export default function AmoreStreakPage() {
  return (
    <>
      <Head>
        <title>Amore Streak | LIT AMOR</title>
        <meta name="description" content="Send daily love messages to keep your streak alive" />
      </Head>
      
      <AmoreStreakMain />
      <BottomNav />
    </>
  );
}
