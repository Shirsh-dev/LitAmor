import Head from "next/head";
import { SinglesProfile } from "@/components/singles/SinglesProfile";
import SinglesBottomNav from "@/components/navigation/SinglesBottomNav";

export default function SinglesProfilePage() {
  return (
    <>
      <Head>
        <title>My Profile - LIT AMOR</title>
        <meta name="description" content="Manage your profile, track your journey, and enhance your dating experience on Lit Amor" />
        <meta name="keywords" content="dating profile, compatibility test, verification, premium features" />
      </Head>
      
      <div className="min-h-screen pb-20">
        <SinglesProfile />
        <SinglesBottomNav />
      </div>
    </>
  );
}
