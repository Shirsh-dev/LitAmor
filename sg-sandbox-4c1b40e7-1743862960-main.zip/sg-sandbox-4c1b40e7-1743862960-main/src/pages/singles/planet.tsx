import Head from "next/head";
import { useState, useEffect } from "react";
import { ArrowLeft, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import SinglesBottomNav from "@/components/navigation/SinglesBottomNav";
import { SoloSparksView } from "@/components/planet/features/SoloSparksView";
import { MoodTrailsView } from "@/components/planet/features/MoodTrailsView";
import { ThoughtDropsView } from "@/components/planet/features/ThoughtDropsView";
import { HiddenSpotsView } from "@/components/planet/features/HiddenSpotsView";
import { GiftGalaxyView } from "@/components/planet/features/GiftGalaxyView";
import { MemoryCapsulesView } from "@/components/planet/features/MemoryCapsulesView";
import { EventHorizonView } from "@/components/planet/features/EventHorizonView";
import { motion } from "framer-motion";
import { useRouter } from "next/router";

function AnimatedStars({ count = 50 }: { count?: number }) {
  const [mounted, setMounted] = useState(false);
  const [stars, setStars] = useState<Array<{ left: number; top: number; duration: number; delay: number }>>([]);

  useEffect(() => {
    setMounted(true);
    const generatedStars = [...Array(count)].map(() => ({
      left: Math.random() * 100,
      top: Math.random() * 100,
      duration: 2 + Math.random() * 3,
      delay: Math.random() * 2
    }));
    setStars(generatedStars);
  }, [count]);

  if (!mounted || stars.length === 0) {
    return null;
  }

  return (
    <div className="absolute inset-0 overflow-hidden">
      {stars.map((star, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-white rounded-full opacity-60"
          style={{
            left: `${star.left}%`,
            top: `${star.top}%`,
          }}
          animate={{
            opacity: [0.3, 1, 0.3],
            scale: [0.5, 1, 0.5],
          }}
          transition={{
            duration: star.duration,
            repeat: Infinity,
            delay: star.delay,
          }}
        />
      ))}
    </div>
  );
}

export default function SinglesPlanetPage() {
  const [activeFeature, setActiveFeature] = useState<string | null>(null);
  const [savedItems, setSavedItems] = useState<string[]>([]);
  const router = useRouter();

  const handleSaveItem = (itemId: string) => {
    if (savedItems.includes(itemId)) {
      setSavedItems(savedItems.filter(id => id !== itemId));
    } else {
      setSavedItems([...savedItems, itemId]);
    }
  };

  const selfGrowthFeatures = [
    {
      id: "solo-sparks",
      title: "Solo Sparks",
      icon: "💎",
      description: "Daily self-discovery challenges",
      gradient: "from-amber-500 to-orange-500",
      component: <SoloSparksView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "mood-trails",
      title: "Mood Trails",
      icon: "🎭",
      description: "Track your emotional journey",
      gradient: "from-purple-500 to-pink-500",
      component: <MoodTrailsView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "thought-drops",
      title: "Thought Drops",
      icon: "💭",
      description: "Capture fleeting thoughts",
      gradient: "from-blue-500 to-cyan-500",
      component: <ThoughtDropsView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    }
  ];

  const exploreFeatures = [
    {
      id: "hidden-spots",
      title: "Hidden Spots",
      icon: "🗺️",
      description: "Discover local treasures",
      gradient: "from-emerald-500 to-teal-500",
      component: <HiddenSpotsView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "gift-galaxy",
      title: "Gift Galaxy",
      icon: "🎁",
      description: "Thoughtful gift ideas",
      gradient: "from-rose-500 to-pink-500",
      component: <GiftGalaxyView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "memory-capsules",
      title: "Memory Capsules",
      icon: "📦",
      description: "Preserve special moments",
      gradient: "from-orange-500 to-red-500",
      component: <MemoryCapsulesView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    },
    {
      id: "event-horizon",
      title: "Event Horizon",
      icon: "📅",
      description: "Plan your adventures",
      gradient: "from-indigo-500 to-purple-500",
      component: <EventHorizonView onBack={() => setActiveFeature(null)} onSave={handleSaveItem} />
    }
  ];

  if (activeFeature) {
    const allFeatures = [...selfGrowthFeatures, ...exploreFeatures];
    const feature = allFeatures.find(f => f.id === activeFeature);
    if (feature) {
      return (
        <>
          <Head>
            <title>{feature.title} | LIT AMOR</title>
            <meta name="description" content={feature.description} />
          </Head>
          <div className="min-h-screen">
            {feature.component}
          </div>
        </>
      );
    }
  }

  return (
    <>
      <Head>
        <title>Planet - Explore & Grow | LIT AMOR</title>
        <meta name="description" content="Your personal universe of growth and discovery" />
      </Head>
      
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 relative overflow-hidden pb-20">
        <AnimatedStars count={100} />

        {/* Header */}
        <div className="fixed top-0 left-0 right-0 h-16 bg-slate-900/80 backdrop-blur-md border-b border-slate-700/30 flex items-center justify-between px-4 z-30">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.push('/singles/home')}
            className="text-slate-300 hover:text-white"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          
          <div className="flex items-center gap-2">
            <LitAmorLogo size="small" />
            <span className="font-bold text-lg text-white">Planet</span>
          </div>
          
          <div className="w-16" />
        </div>

        {/* Main Content */}
        <div className="pt-20 px-4 relative z-10">
          {/* Hero Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-8"
          >
            <motion.div
              animate={{
                scale: [1, 1.1, 1],
                rotate: [0, 5, 0, -5, 0]
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="text-6xl mb-4"
            >
              🌍
            </motion.div>
            <h1 className="text-white text-2xl font-bold mb-2">Your Planet</h1>
            <p className="text-slate-400 text-sm max-w-sm mx-auto">
              Explore your universe of growth, discovery, and self-love
            </p>
          </motion.div>

          {/* Self Growth Section */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="h-5 w-5 text-amber-400" />
              <h2 className="text-white text-lg font-bold">Self Growth</h2>
            </div>
            
            <div className="grid grid-cols-1 gap-4 max-w-sm mx-auto">
              {selfGrowthFeatures.map((feature, index) => (
                <motion.div
                  key={feature.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Card 
                    className="cursor-pointer transition-all duration-300 bg-slate-800/40 border-slate-600/30 hover:bg-slate-700/40 backdrop-blur-sm overflow-hidden"
                    onClick={() => setActiveFeature(feature.id)}
                  >
                    <CardContent className="p-0 relative">
                      <div className={`absolute inset-0 bg-gradient-to-r ${feature.gradient} opacity-10`} />
                      
                      <div className="relative z-10 p-4 flex items-center gap-4">
                        <motion.div
                          className="text-3xl filter drop-shadow-lg"
                          animate={{
                            rotateY: [0, 10, 0, -10, 0],
                          }}
                          transition={{
                            duration: 3,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                        >
                          {feature.icon}
                        </motion.div>
                        
                        <div className="flex-1">
                          <h3 className="text-white font-bold mb-1">{feature.title}</h3>
                          <p className="text-slate-400 text-sm">{feature.description}</p>
                        </div>
                        
                        <ArrowLeft className="h-5 w-5 text-slate-400 transform rotate-180" />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Explore More Section */}
          <div className="mb-8">
            <h2 className="text-white text-lg font-bold mb-4 text-center">Explore More</h2>
            
            <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
              {exploreFeatures.map((feature, index) => (
                <motion.div
                  key={feature.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Card 
                    className="aspect-square cursor-pointer transition-all duration-300 bg-slate-800/40 border-slate-600/30 hover:bg-slate-700/40 backdrop-blur-sm rounded-2xl overflow-hidden"
                    onClick={() => setActiveFeature(feature.id)}
                  >
                    <CardContent className="p-0 h-full relative">
                      <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-20`} />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent" />
                      
                      <div className="relative z-10 h-full flex flex-col items-center justify-center text-center p-4">
                        <motion.div
                          className="text-4xl mb-3 filter drop-shadow-lg"
                          animate={{
                            rotateY: [0, 5, 0, -5, 0],
                          }}
                          transition={{
                            duration: 4,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                        >
                          {feature.icon}
                        </motion.div>
                        
                        <h4 className="text-white text-sm font-bold leading-tight mb-1">
                          {feature.title}
                        </h4>
                        
                        <p className="text-slate-400 text-xs leading-tight">
                          {feature.description}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Stats Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="mb-8"
          >
            <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-4 max-w-sm mx-auto border border-slate-600/30">
              <div className="flex items-center justify-center gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">7</div>
                  <div className="text-xs text-slate-400">Sparks</div>
                </div>
                <div className="w-px h-8 bg-slate-600/50" />
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">5</div>
                  <div className="text-xs text-slate-400">Day Streak</div>
                </div>
                <div className="w-px h-8 bg-slate-600/50" />
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">42%</div>
                  <div className="text-xs text-slate-400">Growth</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        <SinglesBottomNav />
      </div>
    </>
  );
}
