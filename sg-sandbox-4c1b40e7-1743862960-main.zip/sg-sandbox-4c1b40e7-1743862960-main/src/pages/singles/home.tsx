
import Head from "next/head";
import { useState } from "react";
import { 
  Heart, 
  Plane, 
  Zap, 
  Archive,
  Clock,
  CheckCircle,
  RefreshCw,
  Plus,
  Sparkles,
  User,
  TrendingUp
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import SinglesBottomNav from "@/components/navigation/SinglesBottomNav";
import { motion } from "framer-motion";
import { useRouter } from 'next/router';

export default function SinglesHomePage() {
  const router = useRouter();
  const [sparkCompleted, setSparkCompleted] = useState(false);
  const [showMemoryModal, setShowMemoryModal] = useState(false);

  // Mock user data
  const userData = {
    name: "Shirsh",
    weeklyActivity: {
      matches: 2,
      growth: 7,
      reflections: 3
    }
  };

  // Mock LoneTown match data
  const loneTownMatch = {
    hasMatch: true,
    name: "Khushi",
    age: 24,
    tagline: "Curious Soul",
    compatibilityScore: 83,
    expiresIn: "7h"
  };

  // Mock AmorFly data
  const amorFlyData = {
    hasMatch: false,
    todayInterest: "Photography & Travel Stories",
    expiresIn: "20h"
  };

  // Solo Sparks data
  const soloSparks = {
    currentChallenge: "Say something kind to yourself out loud.",
    progress: 7,
    total: 30
  };

  // Memory Capsule data
  const memoryCapsule = {
    recentMemories: [
      { text: "I learned patience is also love.", mood: "💖" },
      { text: "Felt calm watching rain today 🌧️.", mood: "🌙" }
    ]
  };

  const handleSparkComplete = () => {
    setSparkCompleted(true);
    setTimeout(() => setSparkCompleted(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50/30 via-orange-50/20 to-pink-50/30">
      <Head>
        <title>Your Journey | LIT AMOR</title>
        <meta name="description" content="Your personal space for connection, growth, and reflection" />
      </Head>
      
      <main className="min-h-screen pb-24">
        {/* 1️⃣ HEADER – Personal Greeting */}
        <div className="relative overflow-hidden bg-gradient-to-br from-pink-100/40 via-rose-50/30 to-orange-50/30 border-b border-pink-100/50">
          {/* Floating heart animation */}
          <motion.div 
            className="absolute top-12 right-12 w-16 h-16 opacity-20"
            animate={{ 
              y: [0, -20, 0],
              scale: [1, 1.1, 1],
              opacity: [0.2, 0.3, 0.2]
            }}
            transition={{ 
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Heart className="w-full h-full text-pink-400" fill="currentColor" />
          </motion.div>

          <motion.div 
            className="absolute bottom-8 left-8 w-12 h-12 opacity-15"
            animate={{ 
              scale: [1, 1.2, 1],
              rotate: [0, 10, 0],
              opacity: [0.15, 0.25, 0.15]
            }}
            transition={{ 
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1
            }}
          >
            <Sparkles className="w-full h-full text-orange-400" />
          </motion.div>
          
          <div className="relative px-6 pt-6 pb-8">
            <div className="flex items-center justify-between mb-6">
              <LitAmorLogo size="small" />
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => router.push('/singles/profile')}
                className="text-rose-600 hover:bg-rose-100/50"
              >
                <User className="h-5 w-5" />
              </Button>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-4"
            >
              <div className="relative">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-pink-200 to-rose-300 flex items-center justify-center shadow-md">
                  <span className="text-2xl">🌷</span>
                </div>
                {/* Progress ring */}
                <svg className="absolute -inset-1 w-[72px] h-[72px] -rotate-90">
                  <circle
                    cx="36"
                    cy="36"
                    r="34"
                    stroke="#fecdd3"
                    strokeWidth="2"
                    fill="none"
                    opacity="0.3"
                  />
                  <circle
                    cx="36"
                    cy="36"
                    r="34"
                    stroke="#fb7185"
                    strokeWidth="2"
                    fill="none"
                    strokeDasharray="213.6"
                    strokeDashoffset="53.4"
                    strokeLinecap="round"
                  />
                </svg>
              </div>
              
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-gray-800 mb-1">
                  Hi {userData.name} 🌷
                </h1>
                <p className="text-sm text-gray-600 leading-relaxed">
                  New day. New story waiting in LoneTown.
                </p>
              </div>
            </motion.div>
          </div>
        </div>

        <div className="px-5 py-6 space-y-6">
          {/* 2️⃣ LONETOWN CARD – Meaningful Match of the Day */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="bg-white/90 backdrop-blur-sm shadow-lg border-pink-200/50 overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-gray-800">Your LoneTown Connection</h2>
                  <Heart className="h-5 w-5 text-pink-500" />
                </div>

                {loneTownMatch.hasMatch ? (
                  <div className="space-y-4">
                    <div className="flex items-start gap-4">
                      <div className="w-14 h-14 rounded-full bg-gradient-to-br from-pink-300 to-rose-400 flex items-center justify-center text-white text-xl font-bold shadow-md flex-shrink-0">
                        {loneTownMatch.name[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-base font-bold text-gray-900">
                            {loneTownMatch.name}, {loneTownMatch.age}
                          </h3>
                          <span className="text-sm text-gray-600">— {loneTownMatch.tagline}</span>
                        </div>
                        <div className="flex items-center gap-2 mb-3">
                          <Badge variant="secondary" className="bg-pink-100 text-pink-700 font-semibold">
                            {loneTownMatch.compatibilityScore}% Harmony Match 💞
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Clock className="h-4 w-4" />
                          <span>Chat expires in {loneTownMatch.expiresIn} ⏳</span>
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      onClick={() => router.push('/singles/lone-town')}
                      className="w-full bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white shadow-md h-11 font-semibold"
                    >
                      Open Chat
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <motion.div
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="inline-block mb-4"
                    >
                      <div className="w-16 h-16 rounded-full bg-gradient-to-br from-pink-100 to-rose-100 flex items-center justify-center mx-auto">
                        <span className="text-3xl">💫</span>
                      </div>
                    </motion.div>
                    <p className="text-base font-semibold text-gray-800 mb-2">
                      No match yet — refreshing soon 💫
                    </p>
                    <p className="text-sm text-gray-600">
                      Your compatibility is recalibrating today.
                    </p>
                  </div>
                )}

                <div className="mt-5 pt-5 border-t border-gray-100">
                  <p className="text-xs text-center text-gray-600 italic leading-relaxed">
                    "You don't chase connections — you attract them by being aligned."
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* 3️⃣ AMORFLY CARD – Shared Hobby Connection */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gradient-to-br from-orange-50/80 via-pink-50/60 to-purple-50/70 border-orange-200/50 shadow-md overflow-hidden relative">
              {/* Floating interest icons */}
              <div className="absolute top-4 right-4 opacity-10">
                <Plane className="h-12 w-12 text-orange-600" />
              </div>
              
              <CardContent className="p-6 relative">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-white/80 flex items-center justify-center shadow-sm">
                    <Plane className="h-6 w-6 text-orange-500" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-gray-800">AmorFly ✈️</h2>
                    <p className="text-xs text-gray-600">Fly Through Shared Interests</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="bg-white/70 backdrop-blur rounded-lg p-4">
                    <p className="text-sm font-semibold text-gray-800 mb-1">
                      Today's flight: {amorFlyData.todayInterest}
                    </p>
                    <p className="text-xs text-gray-600">
                      Meet one curious soul who shares your major interest.
                    </p>
                  </div>

                  <Button 
                    onClick={() => router.push('/singles/amor-fly')}
                    className="w-full bg-gradient-to-r from-orange-400 to-pink-500 hover:from-orange-500 hover:to-pink-600 text-white shadow-md h-11 font-semibold"
                  >
                    {amorFlyData.hasMatch ? `Chat ends in ${amorFlyData.expiresIn} ⏳` : "Join Today's Flight"}
                  </Button>
                </div>

                <div className="mt-4 pt-4 border-t border-white/50">
                  <p className="text-xs text-center text-gray-600 italic">
                    "Discovery, not swiping."
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* 4️⃣ SOLO SPARKS – Self Growth Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-white/90 backdrop-blur-sm shadow-lg border-yellow-200/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-300 to-orange-400 flex items-center justify-center shadow-md">
                      <Zap className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h2 className="text-base font-bold text-gray-800">Solo Sparks ⚡</h2>
                      <p className="text-xs text-gray-600">Today's Challenge</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="bg-orange-100 text-orange-700 font-semibold">
                    {soloSparks.progress}/{soloSparks.total}
                  </Badge>
                </div>

                <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-lg p-5 mb-4">
                  <p className="text-sm text-gray-800 leading-relaxed font-medium text-center">
                    "{soloSparks.currentChallenge}"
                  </p>
                </div>

                <div className="mb-4">
                  <div className="flex items-center justify-between text-xs text-gray-600 mb-2">
                    <span>Progress</span>
                    <span>{Math.round((soloSparks.progress / soloSparks.total) * 100)}%</span>
                  </div>
                  <Progress 
                    value={(soloSparks.progress / soloSparks.total) * 100} 
                    className="h-2 bg-orange-100"
                  />
                </div>

                <div className="flex gap-3">
                  <Button 
                    onClick={handleSparkComplete}
                    className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-md h-11 font-semibold"
                    disabled={sparkCompleted}
                  >
                    {sparkCompleted ? (
                      <>
                        <CheckCircle className="h-5 w-5 mr-2" />
                        Done!
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-5 w-5 mr-2" />
                        Mark as Done
                      </>
                    )}
                  </Button>
                  <Button 
                    variant="outline"
                    className="border-2 border-orange-300 text-orange-600 hover:bg-orange-50 h-11 px-5"
                  >
                    <RefreshCw className="h-5 w-5" />
                  </Button>
                </div>

                {sparkCompleted && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="mt-4 text-center"
                  >
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0] }}
                      transition={{ duration: 0.5 }}
                      className="inline-block"
                    >
                      <Sparkles className="h-8 w-8 text-yellow-500 mx-auto" />
                    </motion.div>
                  </motion.div>
                )}

                <div className="mt-5 pt-5 border-t border-gray-100">
                  <p className="text-xs text-center text-gray-600 italic leading-relaxed">
                    "Small sparks of self-growth light the path to love."
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* 5️⃣ MEMORY CAPSULE – Personal Reflection Zone */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="bg-gradient-to-br from-purple-50/80 via-pink-50/60 to-blue-50/70 border-purple-200/50 shadow-md">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-12 h-12 rounded-full bg-white/80 flex items-center justify-center shadow-sm">
                    <span className="text-2xl">🕯️</span>
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-gray-800">Memory Capsule</h2>
                    <p className="text-xs text-gray-600">Your emotional archive</p>
                  </div>
                </div>

                <div className="space-y-3 mb-5">
                  {memoryCapsule.recentMemories.map((memory, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.5 + index * 0.1 }}
                      className="bg-white/80 backdrop-blur rounded-lg p-4 border border-purple-200/50 shadow-sm"
                    >
                      <div className="flex items-start gap-3">
                        <span className="text-xl flex-shrink-0">{memory.mood}</span>
                        <p className="text-sm text-gray-800 leading-relaxed flex-1">
                          "{memory.text}"
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <Button 
                  onClick={() => router.push('/singles/planet')}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-md h-11 font-semibold"
                >
                  <Plus className="h-5 w-5 mr-2" />
                  Add New Memory
                </Button>

                <div className="mt-5 pt-5 border-t border-white/50">
                  <p className="text-xs text-center text-gray-600 italic leading-relaxed">
                    "Love grows in awareness 🌱"
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* 6️⃣ FOOTER – Soft Stats & Encouragement */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="pt-4 pb-2"
          >
            <Card className="bg-white/60 backdrop-blur-sm border-gray-200/50 shadow-sm">
              <CardContent className="p-5 text-center">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <TrendingUp className="h-4 w-4 text-pink-500" />
                  <p className="text-sm text-gray-700 font-medium">
                    You've completed {userData.weeklyActivity.growth} Sparks and connected with {userData.weeklyActivity.matches} people this week 💫
                  </p>
                </div>
                <p className="text-xs text-gray-600 italic leading-relaxed">
                  "Keep showing up — the right energy finds you."
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>
      
      <SinglesBottomNav />
    </div>
  );
}
