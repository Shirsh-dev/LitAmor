import Head from "next/head";
import LoneTown from "@/components/lone-town/LoneTown";
import SinglesBottomNav from "@/components/navigation/SinglesBottomNav";

export default function LoneTownPage() {
  return (
    <>
      <Head>
        <title>Lone Town - LIT AMOR</title>
        <meta name="description" content="Find your daily meaningful connection" />
      </Head>
      
      <div className="min-h-screen">
        <LoneTown />
        <SinglesBottomNav />
      </div>
    </>
  );
}
