import { useState, useEffect } from "react";
import Head from "next/head";
import { AmorFlyOnboarding } from "@/components/amor-fly/AmorFlyOnboarding";
import { AmorFlyApp } from "@/components/amor-fly/AmorFlyApp";
import { AmorFlyLanding } from "@/components/amor-fly/AmorFlyLanding";
import SinglesBottomNav from "@/components/navigation/SinglesBottomNav";
import { AmorFlyUser, AmorFlyMatch } from "@/types/amorFly";
import { findAmorFlyMatch } from "@/lib/amorFlyMatching";

export default function AmorFlyPage() {
  const [currentUser, setCurrentUser] = useState<AmorFlyUser | null>(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showLanding, setShowLanding] = useState(false);
  const [currentMatch, setCurrentMatch] = useState<AmorFlyMatch | null>(null);
  const [matchedUser, setMatchedUser] = useState<AmorFlyUser | null>(null);

  useEffect(() => {
    const userData = localStorage.getItem("amorFlyUser");
    
    if (userData) {
      const user: AmorFlyUser = JSON.parse(userData);
      setCurrentUser(user);
      
      if (!user.firstAmorFlyOnboardShown) {
        setShowOnboarding(true);
      }
      
      const matchData = localStorage.getItem("amorFlyCurrentMatch");
      if (matchData) {
        const match: AmorFlyMatch = JSON.parse(matchData);
        setCurrentMatch(match);
        
        const allUsersData = localStorage.getItem("amorFlyAllUsers");
        if (allUsersData) {
          const allUsers: AmorFlyUser[] = JSON.parse(allUsersData);
          const otherUserId = match.user1Id === user.id ? match.user2Id : match.user1Id;
          const matched = allUsers.find(u => u.id === otherUserId);
          if (matched) {
            setMatchedUser(matched);
          }
        }
      }
    } else {
      setShowLanding(true);
    }
  }, []);

  const handleGetStarted = () => {
    setShowLanding(false);
    setShowOnboarding(true);
  };

  const handleOnboardingComplete = (userData: Partial<AmorFlyUser>) => {
    const newUser: AmorFlyUser = {
      id: `user_${Date.now()}`,
      ...userData,
      flyStatus: "OFF",
      recentMatchUserIds: [],
      firstAmorFlyOnboardShown: true,
      createdAt: Date.now(),
      lastMatchTime: null,
      majorInterest: userData.majorInterest || "",
      minorInterests: userData.minorInterests || [],
    };

    localStorage.setItem("amorFlyUser", JSON.stringify(newUser));
    
    const allUsersData = localStorage.getItem("amorFlyAllUsers");
    const allUsers: AmorFlyUser[] = allUsersData ? JSON.parse(allUsersData) : [];
    allUsers.push(newUser);
    localStorage.setItem("amorFlyAllUsers", JSON.stringify(allUsers));
    
    setCurrentUser(newUser);
    setShowOnboarding(false);
  };

  const handleSkipOnboarding = () => {
    // When user skips onboarding, go back to landing page
    setShowOnboarding(false);
    setShowLanding(true);
  };

  const handleToggleFlyStatus = (status: "ON" | "OFF") => {
    if (!currentUser) return;

    const updatedUser = { ...currentUser, flyStatus: status };
    setCurrentUser(updatedUser);
    localStorage.setItem("amorFlyUser", JSON.stringify(updatedUser));

    const allUsersData = localStorage.getItem("amorFlyAllUsers");
    if (allUsersData) {
      const allUsers: AmorFlyUser[] = JSON.parse(allUsersData);
      const updatedUsers = allUsers.map(u => u.id === updatedUser.id ? updatedUser : u);
      localStorage.setItem("amorFlyAllUsers", JSON.stringify(updatedUsers));
    }

    if (status === "ON") {
      setTimeout(() => {
        tryToFindMatch(updatedUser);
      }, 1000);
    }
  };

  const tryToFindMatch = (user: AmorFlyUser) => {
    const allUsersData = localStorage.getItem("amorFlyAllUsers");
    if (!allUsersData) return;

    const allUsers: AmorFlyUser[] = JSON.parse(allUsersData);
    const result = findAmorFlyMatch(user, allUsers);

    if (result.match && result.matchedUser) {
      setCurrentMatch(result.match);
      setMatchedUser(result.matchedUser);
      localStorage.setItem("amorFlyCurrentMatch", JSON.stringify(result.match));

      const updatedUser = {
        ...user,
        lastMatchTime: Date.now(),
        recentMatchUserIds: [...user.recentMatchUserIds, result.matchedUser.id]
      };
      setCurrentUser(updatedUser);
      localStorage.setItem("amorFlyUser", JSON.stringify(updatedUser));
    }
  };

  const handleOpenChat = (matchId: string) => {
    console.log("Opening chat for match:", matchId);
  };

  const handleOpenSettings = () => {
    setShowOnboarding(true);
  };

  if (showLanding) {
    return (
      <>
        <Head>
          <title>AmorFly - Connect through Interests | LIT AMOR</title>
          <meta name="description" content="Photo-free, hobby-based daily matchmaking for curiosity-driven connections" />
        </Head>
        <div className="min-h-screen">
          <AmorFlyLanding onGetStarted={handleGetStarted} />
          <SinglesBottomNav />
        </div>
      </>
    );
  }

  if (showOnboarding) {
    return (
      <>
        <Head>
          <title>AmorFly Setup | LIT AMOR</title>
          <meta name="description" content="Complete your AmorFly profile to start connecting" />
        </Head>
        <div className="min-h-screen">
          <AmorFlyOnboarding 
            onComplete={handleOnboardingComplete}
            onSkip={handleSkipOnboarding}
          />
          <SinglesBottomNav />
        </div>
      </>
    );
  }

  if (!currentUser) {
    // If no user and not showing onboarding/landing, show landing
    return (
      <>
        <Head>
          <title>AmorFly - Connect through Interests | LIT AMOR</title>
          <meta name="description" content="Photo-free, hobby-based daily matchmaking for curiosity-driven connections" />
        </Head>
        <div className="min-h-screen">
          <AmorFlyLanding onGetStarted={handleGetStarted} />
          <SinglesBottomNav />
        </div>
      </>
    );
  }

  return (
    <>
      <Head>
        <title>AmorFly - Your Matches | LIT AMOR</title>
        <meta name="description" content="Connect through shared interests and grow together" />
      </Head>
      
      <div className="min-h-screen pb-20">
        <AmorFlyApp 
          user={currentUser}
          currentMatch={currentMatch || undefined}
          matchedUser={matchedUser || undefined}
          onToggleFlyStatus={handleToggleFlyStatus}
          onOpenChat={handleOpenChat}
          onOpenSettings={handleOpenSettings}
        />
        <SinglesBottomNav />
      </div>
    </>
  );
}
