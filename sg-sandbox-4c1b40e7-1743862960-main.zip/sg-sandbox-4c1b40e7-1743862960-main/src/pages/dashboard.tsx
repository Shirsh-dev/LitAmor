
import Head from "next/head";
import { Button } from "@/components/ui/button";
import { LitAmorLogo } from "@/components/LitAmorLogo";

export default function Dashboard() {
  return (
    <>
      <Head>
        <title>Dashboard | LIT AMOR</title>
        <meta name="description" content="Your LIT AMOR dashboard" />
      </Head>
      
      <main className="min-h-screen bg-gradient-to-br from-secondary/30 via-background to-primary/10">
        <div className="container py-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <LitAmorLogo size="default" />
              <h1 className="text-2xl font-bold">LIT AMOR</h1>
            </div>
            <Button variant="outline">Sign Out</Button>
          </div>
          
          <div className="bg-card/80 backdrop-blur-sm rounded-xl p-8 border border-border/30 shadow-lg">
            <h2 className="text-2xl font-bold mb-4">Welcome to LIT AMOR!</h2>
            <p className="text-muted-foreground">
              Your account has been created successfully. This is a placeholder dashboard.
            </p>
          </div>
        </div>
      </main>
    </>
  );
}
