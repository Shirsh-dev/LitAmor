import Head from "next/head";
import { useRouter } from "next/router";
import { RelationshipTypeSelector } from "@/components/RelationshipTypeSelector";

export default function RelationshipTypePage() {
  const router = useRouter();
  
  const handleRelationshipSelect = (type: "single" | "couple") => {
    // In a real implementation, you would save this to the user's profile
    console.log("Selected relationship type:", type);
    
    // Redirect based on selection
    if (type === "couple") {
      router.push("/couple/home");
    } else {
      router.push("/singles/home");
    }
  };

  return (
    <>
      <Head>
        <title>Choose Relationship Type | LIT AMOR</title>
        <meta name="description" content="Choose how you will use LIT AMOR" />
      </Head>
      
      <main className="min-h-screen bg-gradient-to-br from-secondary/30 via-background to-primary/10 flex items-center justify-center p-4">
        <div className="w-full max-w-md relative">
          {/* Background decorative elements */}
          <div className="absolute inset-0 -z-10 overflow-hidden">
            <div className="absolute top-10 left-10 text-primary/20">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
            </div>
            <div className="absolute top-40 right-10 text-primary/20">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
              </svg>
            </div>
            <div className="absolute bottom-20 left-20 text-primary/20">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
              </svg>
            </div>
            <div className="absolute bottom-40 right-20 text-primary/20">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
            </div>
          </div>
          
          <RelationshipTypeSelector onSelect={handleRelationshipSelect} />
        </div>
      </main>
    </>
  );
}