
import Head from "next/head";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LitAmorLogo } from "@/components/LitAmorLogo";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle password reset logic here
    console.log("Reset password for:", email);
    setIsSubmitted(true);
  };

  return (
    <>
      <Head>
        <title>Forgot Password | LIT AMOR</title>
        <meta name="description" content="Reset your LIT AMOR password" />
      </Head>
      
      <main className="min-h-screen bg-gradient-to-br from-secondary/30 via-background to-primary/10 flex items-center justify-center p-4">
        <Card className="w-full max-w-md border border-border/30 shadow-lg bg-card/80 backdrop-blur-sm">
          <CardHeader className="space-y-1 flex flex-col items-center">
            <Link href="/auth/signin" className="mb-2">
              <Button variant="ghost" size="icon" className="absolute left-4 top-4">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <LitAmorLogo size="default" />
            <CardTitle className="text-2xl font-bold text-center mt-4">Forgot Password</CardTitle>
            <p className="text-muted-foreground text-center">
              {isSubmitted 
                ? "Check your email for a reset link" 
                : "Enter your email to receive a password reset link"}
            </p>
          </CardHeader>
          <CardContent>
            {isSubmitted ? (
              <div className="space-y-4 text-center">
                <p className="text-sm">
                  We've sent a password reset link to <span className="font-medium">{email}</span>
                </p>
                <p className="text-sm text-muted-foreground">
                  Didn't receive an email? Check your spam folder or try again.
                </p>
                <Button 
                  className="w-full mt-4"
                  onClick={() => setIsSubmitted(false)}
                >
                  Try Again
                </Button>
                <div className="mt-4">
                  <Link href="/auth/signin" className="text-primary hover:underline text-sm">
                    Back to Sign In
                  </Link>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="your.email@example.com" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                  Send Reset Link
                </Button>
                <div className="text-center mt-4">
                  <Link href="/auth/signin" className="text-primary hover:underline text-sm">
                    Back to Sign In
                  </Link>
                </div>
              </form>
            )}
          </CardContent>
        </Card>
      </main>
    </>
  );
}
